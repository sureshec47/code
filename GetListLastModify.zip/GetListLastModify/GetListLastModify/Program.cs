﻿using GetListLastModify.nJLibrarys;
using GetListLastModify.nJListLibraryModified;
using GetListLastModify.nJSubwebs;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace GetListLastModify
{
    public class Program
    {

        static DataTable dtmdfy = new DataTable();
        StringBuilder stringBuilder = new StringBuilder();
        static string CutOverDate = string.Empty;
        public static string inputfile = string.Empty;
        static void Main(string[] args)
        {
            string url = string.Empty;
            string siteName = string.Empty;
            UtliClass util = new UtliClass();

            try
            {
                util.UserName = System.Configuration.ConfigurationManager.AppSettings["UserName"].ToString();
                util.Password = System.Configuration.ConfigurationManager.AppSettings["Password"].ToString();
                CutOverDate = System.Configuration.ConfigurationManager.AppSettings["CutOverDate"].ToString();

                dtmdfy = new DataTable();
                dtmdfy.Columns.Add("SiteUrl", typeof(string));
                dtmdfy.Columns.Add("ListName", typeof(string));
                dtmdfy.Columns.Add("ItemID", typeof(string));
                dtmdfy.Columns.Add("Modified", typeof(string));
                dtmdfy.Columns.Add("FileDirRef", typeof(string));
                dtmdfy.Columns.Add("Title", typeof(string));
                dtmdfy.Columns.Add("CutOverDate", typeof(string));
                dtmdfy.Columns.Add("ListType", typeof(string));

                //string sourceUrl = System.Configuration.ConfigurationManager.AppSettings["SourceUrl"].ToString();
                string ListModified = System.Configuration.ConfigurationManager.AppSettings["ReportPath"].ToString();
                inputfile = System.Configuration.ConfigurationManager.AppSettings["SiteCollectionUrls"].ToString();

                string[] sitecollections = System.IO.File.ReadAllLines(inputfile);
                foreach (string site in sitecollections)
                {
                    if (!string.IsNullOrEmpty(site))
                    {

                        url = "{0}/_api/web?&$select=Title";
                        string jsonResponse = GetRestResult(string.Format(url, site), util.SourcehttpClientHandler).Result;
                        Newtonsoft.Json.Linq.JObject o = Newtonsoft.Json.Linq.JObject.Parse(jsonResponse);
                        siteName = Convert.ToString(o.SelectToken("d").SelectToken("Title"));
                        Console.ForegroundColor = ConsoleColor.White;
                        Console.WriteLine("======Started=========", site);
                        getAllListNames(util, site);
                        SubwebsDiffReporter(util, site);
                        if (dtmdfy.Rows.Count > 0)
                        {
                            ToCSV(dtmdfy, ListModified + siteName + ".csv");
                            dtmdfy = new DataTable();
                            dtmdfy.Columns.Add("SiteUrl", typeof(string));
                            dtmdfy.Columns.Add("ListName", typeof(string));
                            dtmdfy.Columns.Add("ItemID", typeof(string));
                            dtmdfy.Columns.Add("Modified", typeof(string));
                            dtmdfy.Columns.Add("FileDirRef", typeof(string));
                            dtmdfy.Columns.Add("Title", typeof(string));
                            dtmdfy.Columns.Add("CutOverDate", typeof(string));
                            dtmdfy.Columns.Add("ListType", typeof(string));
                        }
                        Console.WriteLine("======Completed=========\n");
                    }

                }



                Console.WriteLine("Sucessfull generated ListLastModifed Items!!!");
                Console.WriteLine("Press ENTER to exit!");
                Console.ReadKey();
            }
            catch (Exception ex)
            {
                using (StreamWriter w = System.IO.File.AppendText(@ConfigurationSettings.AppSettings["log"]))
                {
                    logFile(DateTime.Now + ":" + " Error on Main Method : \tErrors Message:" + ex.Message, w);
                }
            }
        }
        public static void ToCSV(DataTable dtDataTable, string strFilePath)
        {
            StreamWriter sw = new StreamWriter(strFilePath, false);
            try
            {
                //headers  
                for (int i = 0; i < dtDataTable.Columns.Count; i++)
                {
                    sw.Write(dtDataTable.Columns[i]);
                    if (i < dtDataTable.Columns.Count - 1)
                    {
                        sw.Write(",");
                    }
                }
                sw.Write(sw.NewLine);
                foreach (DataRow dr in dtDataTable.Rows)
                {
                    for (int i = 0; i < dtDataTable.Columns.Count; i++)
                    {
                        if (!Convert.IsDBNull(dr[i]))
                        {
                            string value = dr[i].ToString();
                            if (value.Contains(','))
                            {
                                value = String.Format("\"{0}\"", value);
                                sw.Write(value);
                            }
                            else
                            {
                                sw.Write(dr[i].ToString());
                            }
                        }
                        if (i < dtDataTable.Columns.Count - 1)
                        {
                            sw.Write(",");
                        }
                    }
                    sw.Write(sw.NewLine);
                }
                sw.Close();
            }
            catch (Exception ex)
            {
                using (StreamWriter w = System.IO.File.AppendText(@ConfigurationSettings.AppSettings["log"]))
                {
                    logFile(DateTime.Now + ":" + "  Error on TOCSV Method Errors Message:" + ex.Message, w);
                }
            }



        }
        public static void getAllListNames(UtliClass util, string sourceUrl)
        {
            try
            {
                string url = "{0}/_api/web/lists?$select=BaseTemplate,Title,EntityTypeName,ItemCount,id&$filter=Hidden eq false";
                string jsonResponse = GetRestResult(string.Format(url, sourceUrl), util.SourcehttpClientHandler).Result;
                JLibrarys jLibs = JsonConvert.DeserializeObject<JLibrarys>(jsonResponse);
                JLibrarys jLibsd = JsonConvert.DeserializeObject<JLibrarys>(jsonResponse);
                IEnumerable<nJLibrarys.Result> diffdocLib = jLibs.d.results.Where(s => !jLibsd.d.results.Any(des => s.EntityTypeName == des.EntityTypeName));
                diffdocLib = jLibsd.d.results.Where(s => !jLibs.d.results.Any(des => s.EntityTypeName == des.EntityTypeName));
                diffdocLib = jLibsd.d.results.Where(s => jLibs.d.results.Any(des => s.EntityTypeName == des.EntityTypeName));
                foreach (nJLibrarys.Result result in diffdocLib.ToArray())
                {
                    // Console.WriteLine(string.Format("{0} , {1}, {2}", result.Title, jLibs.d.results.Where(des => des.EntityTypeName == result.EntityTypeName).First().Title, result.ItemCount));
                    if (result.ItemCount > 0)
                    {
                        GetLastItemModified(util, sourceUrl, result, jLibs.d.results.Where(des => des.EntityTypeName == result.EntityTypeName).First());
                    }
                }
            }
            catch (Exception ex)
            {
                using (StreamWriter w = System.IO.File.AppendText(@ConfigurationSettings.AppSettings["log"]))
                {
                    logFile(DateTime.Now + ":" + "  Error on getAllListNames Method Errors Message:" + ex.Message, w);
                }
            }


        }
        private static void SubwebsDiffReporter(UtliClass util, string sourceUrl)
        {
            try
            {
                string url = "{0}/_api/web/Webs?$select=Title,Url,ServerRelativeUrl";
                string temp = string.Empty;
                string jsonResponse = GetRestResult(string.Format(url, sourceUrl), util.SourcehttpClientHandler).Result;
                JSubwebs subwebsS = JsonConvert.DeserializeObject<JSubwebs>(jsonResponse);
                JSubwebs subwebsD = JsonConvert.DeserializeObject<JSubwebs>(jsonResponse);
                IEnumerable<nJSubwebs.Result> diffsubwebs = subwebsS.d.results.Where(s => !subwebsD.d.results.Any(d => s.Title == d.Title));
                diffsubwebs = subwebsD.d.results.Where(s => !subwebsS.d.results.Any(d => s.Title == d.Title));
                diffsubwebs = subwebsS.d.results.Where(s => subwebsD.d.results.Any(d => s.Title == d.Title));
                foreach (nJSubwebs.Result result in diffsubwebs.ToArray())
                {
                    temp = result.ServerRelativeUrl.Split('/')[result.ServerRelativeUrl.Split('/').Length - 1];
                    getAllListNames(util, string.Format("{0}/{1}", sourceUrl, temp));
                    SubwebsDiffReporter(util, string.Format("{0}/{1}", sourceUrl, temp));
                }
            }
            catch (Exception ex)
            {
                using (StreamWriter w = System.IO.File.AppendText(@ConfigurationSettings.AppSettings["log"]))
                {
                    logFile(DateTime.Now + ":" + " Error on SubWebsDiffReporter Method Errors Message:" + ex.Message, w);
                }
            }

        }
        private static void GetLastItemModified(UtliClass util, string sourceUrl, nJLibrarys.Result result, nJLibrarys.Result socresult)
        {
            try
            {

                int PAGESIZE = 5000;
                string temp = string.Empty;
                string jsonResponse = string.Empty;
                string url = string.Empty;
                if (result.Title == "Site Pages")
                {
                    url = @"{0}/_api/web/lists/getbyid('{1}')/items?&$skiptoken=Paged=TRUE&$top={2}&$filter=Modified gt datetime'" + CutOverDate.Trim() + "'" +
                                "&$Select=Id,Modified,FileDirRef,File/Name,File/ServerRelativeUrl";
                }
                else
                {
                    url = @"{0}/_api/web/lists/getbyid('{1}')/items?&$skiptoken=Paged=TRUE&$top={2}&$filter=Modified gt datetime'" + CutOverDate.Trim() + "'" +
                                                    "&$Select=Id,Title,Modified,FileDirRef,File/Name,File/ServerRelativeUrl";
                }


                jsonResponse = GetRestResult(string.Format(url, sourceUrl, socresult.Id, PAGESIZE), util.SourcehttpClientHandler).Result;
                JListLibraryModified jDocS = JsonConvert.DeserializeObject<JListLibraryModified>(jsonResponse);
                jDocS.d.results = jDocS.d.results.Where(s => s.Id > 0).ToArray();
                try
                {
                    foreach (var items in jDocS.d.results)
                    {
                        Console.ForegroundColor = ConsoleColor.Green;

                        Console.WriteLine(string.Format("{0} , {1}", sourceUrl, result.Title));

                        DataRow row = dtmdfy.NewRow();
                        row["SiteUrl"] = sourceUrl;
                        row["ListName"] = result.Title;
                        row["ItemID"] = items.ID.ToString();
                        row["Modified"] = items.Modified.ToString();
                        row["FileDirRef"] = items.FileDirRef.ToString();
                        row["Title"] = items.Title;
                        row["CutOverDate"] = CutOverDate;
                        row["ListType"] = result.BaseTemplate;
                        dtmdfy.Rows.Add(row);

                    }
                }
                catch (Exception ex)
                {
                    using (StreamWriter w = System.IO.File.AppendText(@ConfigurationSettings.AppSettings["log"]))
                    {
                        logFile(DateTime.Now + ":" + "  Error on Foreach - GetLastItemModified Method Errors Message:" + ex.Message, w);
                    }
                }

            }
            catch (Exception ex)
            {
                using (StreamWriter w = System.IO.File.AppendText(@ConfigurationSettings.AppSettings["log"]))
                {
                    logFile(DateTime.Now + ":" + "  Error on GetLastItemModified Method Errors Message:" + ex.Message, w);
                }
            }

        }
        public static void logFile(string logMessage, TextWriter w)
        {
            Console.WriteLine("Error: \n" + logMessage);
            w.WriteLine(logMessage);
        }
        private static async Task<string> GetRestResult(string webUrl, HttpClientHandler handler)
        {
            string jsonData = null;
            try
            {
                using (var cts = new CancellationTokenSource())
                using (var client = new HttpClient(handler))
                {
                    client.Timeout = TimeSpan.FromSeconds(1000);

                    client.DefaultRequestHeaders.Clear();
                    client.DefaultRequestHeaders.Add("Accept", "application/json;odata=verbose");
                    client.DefaultRequestHeaders.Add("ContentType", "application/json");
                    Uri webUri = new Uri(webUrl);
                    using (HttpResponseMessage response = await client.GetAsync(webUri))
                    {
                        try
                        {
                            response.EnsureSuccessStatusCode();
                            jsonData = await response.Content.ReadAsStringAsync();
                        }
                        catch (Exception ex)
                        {
                            using (StreamWriter w = System.IO.File.AppendText(@ConfigurationSettings.AppSettings["log"]))
                            {
                                logFile(DateTime.Now + ":" + "Error on http - GerREstResult method Errors Message:" + ex.Message, w);
                            }
                        }


                    }

                }
            }
            catch (Exception ex)
            {
                using (StreamWriter w = System.IO.File.AppendText(@ConfigurationSettings.AppSettings["log"]))
                {
                    logFile(DateTime.Now + ":" + " Error on http - GerREstResult method Errors Message:" + ex.Message, w);
                }
            }

            return jsonData;
        }

    }
    public class UtliClass
    {
        public string UserName { get; set; }
        public string Password { get; set; }
        public StringBuilder stringBuilder { get; set; }
        public HttpClientHandler SourcehttpClientHandler
        {
            get
            {
                var credential = new System.Net.NetworkCredential(UserName, Password);
                HttpClientHandler handler = new HttpClientHandler() { Credentials = credential };
                return handler;
            }
        }
    }
}
