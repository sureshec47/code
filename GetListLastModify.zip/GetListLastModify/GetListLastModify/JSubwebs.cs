﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GetListLastModify.nJSubwebs
{
    public class JSubwebs
    {
        public D d { get; set; }
    }

    public class D
    {
        public Result[] results { get; set; }
    }

    public class Result
    {
        public string Title { get; set; }
        public string Url { get; set; }
        public string ServerRelativeUrl { get; set; }
    }
}
