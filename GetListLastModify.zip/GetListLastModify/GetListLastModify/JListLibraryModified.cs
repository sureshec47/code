﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GetListLastModify.nJListLibraryModified
{

    public class JListLibraryModified
    {
        public D d { get; set; }
    }

    public class D
    {
        public Result[] results { get; set; }
    }

    public class Result
    {
        //public __Metadata __metadata { get; set; }
        //public File File { get; set; }
        public int Id { get; set; }
        public string Title { get; set; }
        public int ID { get; set; }
        public DateTime Modified { get; set; }
        public string FileDirRef { get; set; }
    }

    public class __Metadata
    {
        public string id { get; set; }
        public string uri { get; set; }
        public string etag { get; set; }
        public string type { get; set; }
    }

    public class File
    {
        public __Deferred __deferred { get; set; }
    }

    public class __Deferred
    {
        public string uri { get; set; }
    }

}
