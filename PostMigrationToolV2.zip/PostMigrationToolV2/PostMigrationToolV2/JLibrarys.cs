﻿namespace PostMigrationToolV2.nJLibrarys
{
    public class JLibrarys
    {
        public D d { get; set; }
    }

    public class D
    {
        public Result[] results { get; set; }
    }

    public class Result
    {
        public string Title { get; set; }
        public string EntityTypeName { get; set; }
        public string ItemCount { get; set; }
        public string Id { get; set; }
    }
}
