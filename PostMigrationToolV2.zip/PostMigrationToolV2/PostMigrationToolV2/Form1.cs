﻿using Microsoft.VisualBasic.FileIO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.IO;
using System.Linq;
using System.Threading;
using System.Windows.Forms;


namespace PostMigrationToolV2
{
    public partial class Form1 : System.Windows.Forms.Form
    {
        private static readonly log4net.ILog _logger = log4net.LogManager.GetLogger(typeof(Program));
        GetSiteInfo objGetSiteInfo = new GetSiteInfo();
        ExporttoExcel objExporttoExcel = new ExporttoExcel();
        GetDataTable objdt = new GetDataTable();
        Get_Item_Level_Permissions_For_All_List_ItemsSource objitemperm = new Get_Item_Level_Permissions_For_All_List_ItemsSource();
        Get_Folder_Level_Permissions objfld = new Get_Folder_Level_Permissions();
        GetContentTypes objcntyp = new GetContentTypes();
        string outputFilePath = "";

        string cntypesfilepath = string.Empty;
        string wrkflfilepath = string.Empty;
        string webpartfilepath = string.Empty;
        string grpfilepath = string.Empty;
        string userfilepath = string.Empty;
        string floderfilepath = string.Empty;
        string featurefileapth = string.Empty;
        string documentfilepath = string.Empty;
        string siteuserfilepath = string.Empty;
        string logPath = "";
        public bool IsrootSite = false;
        string ListName = string.Empty;
        public Form1()
        {
            InitializeComponent();

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
        private void btnGenerate_Click(object sender, EventArgs e)
        {
            if (chkRootWeb.Checked)
            {
                IsrootSite = true;
            }
            else
            {
                IsrootSite = false;
            }
            Console.BackgroundColor = ConsoleColor.Blue;
            Console.ForegroundColor = ConsoleColor.White;
            try
            {
                string srcURL = "";
                string destURL = "";

                outputFilePath = this.txtExport.Text;
                if (chkListFields.Checked == false && chkListPerm.Checked == false && chkWrkflw.Checked == false && chkfldlevel.Checked == false  && chkContentType.Checked == false && chkWebpart.Checked == false && chkgrpper.Checked == false && chkItemLevelPermission.Checked == false && chkDocument.Checked == false && chkFeatureComparsion.Checked == false)
                {
                    MessageBox.Show("please select any one of checkbox Types");
                    return;
                }
                if (btnMultipleSites.Checked == true)
                {
                    if (txtURLFile.Text != "")
                    {
                        if (txtExport.Text == "")
                        {
                            MessageBox.Show("Please select a path for Report");
                        }
                        else
                        {
                            try
                            {
                                if (!string.IsNullOrEmpty(txtURLFile.Text))
                                {
                                    string inputfile = txtURLFile.Text;
                                    string[] sitecollections = System.IO.File.ReadAllLines(inputfile);
                                    foreach (string SiteUrl in sitecollections)
                                    {
                                        if (!string.IsNullOrEmpty(SiteUrl))
                                        {

                                           // logPath = @txtExport.Text + " / " + "log" + "_" + "Report_" + srcURL.Split('/').Last() + "_" + destURL.Split('/').Last() + ".txt";
                                            try
                                            {

                                                var values = SiteUrl.Split(',');
                                                srcURL = values[0];
                                                destURL = values[1];
                                                if (chkContentType.Checked == true)
                                                {
                                                    _logger.InfoFormat("=====================================ContentType Comparison Started=====started Time==={0}", System.DateTime.Now.ToString());
                                                    Console.WriteLine("=====================================ContentType Comparison Started=====started Time==={0}", System.DateTime.Now.ToString());


                                                    cntypesfilepath = "Post_Migration_ContentTypeComparison_" + srcURL.Split('/').Last() + ".xlsx";
                                                    objcntyp.getContentTypes(srcURL, destURL, outputFilePath + "\\" + cntypesfilepath, IsrootSite);

                                                    _logger.InfoFormat("=====================================ContentType Comparison Completed=====Completed Time==={0}", System.DateTime.Now.ToString(), "====================================================");
                                                    Console.WriteLine("=====================================ContentType Comparison Completed=====Completed Time==={0}", System.DateTime.Now.ToString(), "====================================================");
                                                    Console.WriteLine("\n");
                                                }
                                                if (chkWebpart.Checked == true)
                                                {
                                                    _logger.InfoFormat("=====================================Web parts Comparison Started=====started Time==={0}", System.DateTime.Now.ToString(), "====================================================");
                                                    Console.WriteLine("=====================================Web parts Comparison Started=====started Time==={0}", System.DateTime.Now.ToString(), "====================================================");

                                                    webpartfilepath = " Post_Migration_WebPartComparison_" + srcURL.Split('/').Last() + ".xlsx";


                                                    DataTable dtsrc = new DataTable();
                                                    dtsrc = objdt.getwebpartsrc();
                                                    objGetSiteInfo.getsrcwebpart(srcURL, dtsrc, IsrootSite);

                                                    DataTable dtdes = new DataTable();
                                                    dtdes = objdt.getwebpartDes();
                                                    objGetSiteInfo.getdeswebpart(destURL, dtdes, IsrootSite);
                                                    try
                                                    {
                                                        List<DataRow> rowsToDelete = new List<DataRow>();
                                                        foreach (DataRow DR in dtsrc.Rows)
                                                        {
                                                            if (DR["srcWebpartName"].ToString() == "FDMigrationBanner".ToString())
                                                                rowsToDelete.Add(DR);
                                                        }
                                                        foreach (var r in rowsToDelete)
                                                            dtsrc.Rows.Remove(r);
                                                    }
                                                    catch (Exception ex)
                                                    {

                                                        _logger.ErrorFormat("Error Message: {0}", ex.Message.ToString());
                                                    }

                                                    DataTable dtwebpartSum = new DataTable();
                                                    dtwebpartSum = objGetSiteInfo.CompareWeparts(dtsrc, dtdes);
                                                    objExporttoExcel.CreateExcelDocumentFormatingWebparts(dtsrc, dtdes, dtwebpartSum, outputFilePath + "\\" + webpartfilepath);
                                                    _logger.InfoFormat("=====================================Web parts Comparison Completed=====Completed Time==={0}", System.DateTime.Now.ToString(), "====================================================");
                                                    Console.WriteLine("=====================================Web parts Comparison Completed=====Completed Time==={0}", System.DateTime.Now.ToString(), "====================================================");
                                                    Console.WriteLine("\n");

                                                }
                                                if (chkgrpper.Checked == true)
                                                {
                                                    _logger.InfoFormat("=====================================groups Comparison Started=====Started Time==={0}", System.DateTime.Now.ToString(), "====================================================");
                                                    Console.WriteLine("=====================================groups Comparison Started=====Started Time==={0}", System.DateTime.Now.ToString(), "====================================================");

                                                    grpfilepath = "Post_Migration_GroupPermissionComparison_" + srcURL.Split('/').Last() + ".xlsx";
                                                    objGetSiteInfo.getsrcgrps(srcURL, IsrootSite);
                                                    objGetSiteInfo.getdesgrps(destURL, outputFilePath + "\\" + grpfilepath, IsrootSite);

                                                    _logger.InfoFormat("=====================================groups Comparison Completed=====Completed Time==={0}", System.DateTime.Now.ToString(), "====================================================");
                                                    Console.WriteLine("=====================================groups Comparison Completed=====Completed Time==={0}", System.DateTime.Now.ToString(), "====================================================");
                                                    Console.WriteLine("\n");

                                                }
                                                if (chkWrkflw.Checked == true)
                                                {
                                                    _logger.InfoFormat("=====================================Workflow Comparison Started=====Started Time==={0}", System.DateTime.Now.ToString(), "====================================================");
                                                    Console.WriteLine("=====================================Workflow Comparison Started=====Started Time==={0}", System.DateTime.Now.ToString(), "====================================================");

                                                    DataTable dtsrc = new DataTable();
                                                    dtsrc = objdt.getDataTableWrksrc();
                                                    wrkflfilepath = "Post_Migration_WorkflowComparison_" + srcURL.Split('/').Last() + ".xlsx";
                                                    objGetSiteInfo.getWrkflwsrc(srcURL, dtsrc, IsrootSite);
                                                    DataTable dtdes = new DataTable();
                                                    dtdes = objdt.getDataTableWrkDes();
                                                    objGetSiteInfo.getWrkflwDes(destURL, dtdes, IsrootSite);
                                                    DataTable dtCmp = new DataTable();
                                                    dtCmp = objGetSiteInfo.CompareWrkflw(dtsrc, dtdes);
                                                    objExporttoExcel.CreateExcelDocumentFormatingWrkflow(dtsrc, dtdes, dtCmp, outputFilePath + "\\" + wrkflfilepath);

                                                    _logger.InfoFormat("=====================================Workflow Comparison Completed=====Completed Time==={0}", System.DateTime.Now.ToString());
                                                    Console.WriteLine("=====================================Workflow Comparison Completed=====Completed Time==={0}", System.DateTime.Now.ToString());
                                                    Console.WriteLine("\n");

                                                }
                                                if (chkDocument.Checked == true)
                                                {
                                                    _logger.InfoFormat("=====================================Document Version Comparison Started=====Started Time==={0}", System.DateTime.Now.ToString(), "====================================================");
                                                    Console.WriteLine("=====================================Document Version Comparison Started=====Started Time==={0}", System.DateTime.Now.ToString(), "====================================================");
                                                    documentfilepath = "Post_Migration_DocumentVersionComparison_" + srcURL.Split('/').Last() + ".xlsx";
                                                    objGetSiteInfo.getDocumentVersion(srcURL, destURL, outputFilePath + "\\" + documentfilepath);

                                                    _logger.InfoFormat("=====================================Document Version Comparison Completed=====Completed Time==={0}", System.DateTime.Now.ToString(), "====================================================");
                                                    Console.WriteLine("=====================================Document Version Comparison Completed=====Completed Time==={0}", System.DateTime.Now.ToString(), "====================================================");
                                                    Console.WriteLine("\n");

                                                }
                                                if (chkFeatureComparsion.Checked == true)
                                                {
                                                    _logger.InfoFormat("=====================================Site Fetures  Comparison Started=====Started Time==={0}", System.DateTime.Now.ToString(), "====================================================");
                                                    Console.WriteLine("=====================================Site Fetures   Comparison Started=====Started Time==={0}", System.DateTime.Now.ToString(), "====================================================");
                                                    featurefileapth = "Post_Migration_FeatureComparison_" + srcURL.Split('/').Last() + ".xlsx";
                                                    objGetSiteInfo.getFeatureComparsion(srcURL, destURL, outputFilePath + "\\" + featurefileapth);

                                                    _logger.InfoFormat("=====================================Site Fetures  Comparison Completed=====Completed Time==={0}", System.DateTime.Now.ToString(), "====================================================");
                                                    Console.WriteLine("=====================================Site Fetures   Comparison Completed=====Completed Time==={0}", System.DateTime.Now.ToString(), "====================================================");
                                                    Console.WriteLine("\n");

                                                }
                                                if (chkItemLevelPermission.Checked == true)
                                                {

                                                    ListName = string.Empty;
                                                    _logger.InfoFormat("=====================================Item Level Comparison Started=====Started Time==={0}", System.DateTime.Now.ToString(), "====================================================");
                                                    Console.WriteLine("=====================================Item Level  Comparison Started=====Started Time==={0}", System.DateTime.Now.ToString(), "====================================================");

                                                    userfilepath = "Post_Migration_ItemLevelPermission_" + srcURL.Split('/').Last() + ".xlsx";
                                                    objitemperm.getItemLevelComparison(srcURL, destURL, outputFilePath + "\\" + userfilepath, true, "",IsrootSite);
                                                    _logger.InfoFormat("=====================================Item Level Comparison Completed=====Completed Time==={0}", System.DateTime.Now.ToString(), "====================================================");
                                                    Console.WriteLine("=====================================Item Level  Comparison Completed=====Completed Time==={0}", System.DateTime.Now.ToString(), "====================================================");
                                                    Console.WriteLine("\n");
                                                }
                                                if (chkfldlevel.Checked == true)
                                                {

                                                    _logger.InfoFormat("=====================================Folder Level Comparison Started=====Started Time==={0}", System.DateTime.Now.ToString(), "====================================================");
                                                    Console.WriteLine("=====================================Folder Level  Comparison Started=====Started Time==={0}", System.DateTime.Now.ToString(), "====================================================");

                                                    floderfilepath = "Post_Migration_FolderLevelComparison" + srcURL.Split('/').Last() + ".xlsx";
                                                    objfld.GetFolderLevelComparison(srcURL, destURL, outputFilePath + "\\" + floderfilepath, true, "", IsrootSite);

                                                    _logger.InfoFormat("=====================================Folder Level Comparison Completed=====Completed Time==={0}", System.DateTime.Now.ToString(), "====================================================");
                                                    Console.WriteLine("=====================================Folder Level  Comparison Completed=====Completed Time==={0}", System.DateTime.Now.ToString(), "====================================================");
                                                    Console.WriteLine("\n");

                                                }
                                                if (chkListPerm.Checked == true)
                                                {
                                                    _logger.InfoFormat("=====================================List/Library Permission Comparison Started=====started Time==={0}", System.DateTime.Now.ToString());
                                                    Console.WriteLine("=====================================List/Library Permission Comparison Started=====started Time==={0}", System.DateTime.Now.ToString());
                                                    userfilepath = "Post_Migration_Item_List_Library_LevelPermission_" + srcURL.Split('/').Last() + ".xlsx";

                                                    DataTable dtsrc = new DataTable();
                                                    dtsrc = objdt.getDataTableListPersrc();
                                                    objGetSiteInfo.getListPermSrc(srcURL, dtsrc, IsrootSite);

                                                    DataTable dtdes = new DataTable();
                                                    dtdes = objdt.getDataTableListPerDes();
                                                    objGetSiteInfo.getListPermdes(destURL, dtdes, IsrootSite);

                                                    DataTable dtList = new DataTable();
                                                    dtList = objdt.getDataTableListPerCompare();
                                                    CompareListPerm(dtsrc, dtdes, dtList);

                                                    objExporttoExcel.CreateExcelDocumentFormatingListPerm(dtsrc, dtdes, dtList, outputFilePath + "\\" + userfilepath);
                                                    _logger.InfoFormat("=====================================List/Library Permission Comparison Completed=====Completed Time==={0}", System.DateTime.Now.ToString());
                                                    Console.WriteLine("=====================================List/Library Permission Comparison Completed=====Completed Time==={0}", System.DateTime.Now.ToString());
                                                }
                                                if (chkListFields.Checked == true)
                                                {
                                                    cntypesfilepath = string.Empty;
                                                    cntypesfilepath = "Post_Migration_listfieldsassociatedcontenttypeComparison_" + srcURL.Split('/').Last() + ".xlsx";
                                                    _logger.InfoFormat("=====================================list fields and the associated content type Comparison Started=====started Time==={0}", System.DateTime.Now.ToString(), "====================================================");
                                                    Console.WriteLine("=====================================list fields and the associated content type Comparison Started=====started Time==={0}", System.DateTime.Now.ToString(), "====================================================");
                                                    DataTable dtcntypesrc = new DataTable();
                                                    dtcntypesrc = objdt.getDataTableListContentTypes();

                                                    DataTable dtsrcList = new DataTable();
                                                    dtsrcList = objdt.getDataTableListContentTypes();
                                                    objGetSiteInfo.Listassociatedcontenttype(srcURL, dtcntypesrc, dtsrcList, IsrootSite);

                                                    DataTable dtcntypedes = new DataTable();
                                                    dtcntypedes = objdt.getDataTableListContentTypesDes();

                                                    DataTable dtdesList = new DataTable();
                                                    dtdesList = objdt.getDataTableListContentTypes();
                                                    objGetSiteInfo.ListassociatedcontenttypeDes(destURL, dtcntypedes, dtdesList, IsrootSite);

                                                    DataTable dtListCntType = new DataTable();
                                                    //dtListCntType = objdt.getDataTableListCompareContentTypes();
                                                    // CompareListContentTypes(dtsrcList, dtdesList, dtListCntType);
                                                    objExporttoExcel.CreateExcelDocumentFormatingListassociatedcontenttype(dtsrcList, dtdesList, dtListCntType, outputFilePath + "\\" + cntypesfilepath);
                                                    _logger.InfoFormat("=====================================list fields and the associated content type Comparison Started=====Completed Time==={0}", System.DateTime.Now.ToString(), "====================================================");
                                                    Console.WriteLine("=====================================list fields and the associated content type Comparison Started=====Completed Time==={0}", System.DateTime.Now.ToString(), "====================================================");
                                                }
                                                if (chkItemLevelLists.Checked == true)
                                                {
                                                    ListName = ConfigurationSettings.AppSettings["ListName"].ToString();
                                                    if (!string.IsNullOrEmpty(ListName))
                                                    {


                                                        #region Item Level Comparison only for lists/libraries
                                                        _logger.InfoFormat("=====================================Item Level Comparison only for lists/libraries Started=====Started Time==={0}", System.DateTime.Now.ToString(), "====================================================");
                                                        Console.WriteLine("=====================================Item Level  Comparison only for lists/libraries Started=====Started Time==={0}", System.DateTime.Now.ToString(), "====================================================");
                                                        userfilepath = "Post_Migration_ItemLevelPermission_" + srcURL.Split('/').Last() + "_" + ListName + ".xlsx";

                                                        objitemperm.getItemLevelComparison(srcURL, destURL, outputFilePath + "\\" + userfilepath, false, ListName, IsrootSite);

                                                        _logger.InfoFormat("=====================================Item Level Comparison Completed=====Completed Time==={0}", System.DateTime.Now.ToString(), "====================================================");
                                                        Console.WriteLine("=====================================Item Level  Comparison Completed=====Completed Time==={0}", System.DateTime.Now.ToString(), "====================================================");
                                                        Console.WriteLine("\n");
                                                        #endregion

                                                        #region Folder Level Comparison only for lists/libraries
                                                        _logger.InfoFormat("=====================================Folder Level Comparison Started only for lists/libraries=====Started Time==={0}", System.DateTime.Now.ToString(), "====================================================");
                                                        Console.WriteLine("=====================================Folder Level  Comparison Started only for lists/libraries=====Started Time==={0}", System.DateTime.Now.ToString(), "====================================================");

                                                        floderfilepath = "Post_Migration_FolderLevelComparison" + srcURL.Split('/').Last() + "_" + ListName + ".xlsx";
                                                        // objfld.GetFolderLevelComparison(srcURL, destURL, outputFilePath + "\\" + floderfilepath, false, ListName);

                                                        _logger.InfoFormat("=====================================Folder Level Comparison Completed=====Completed Time==={0}", System.DateTime.Now.ToString(), "====================================================");
                                                        Console.WriteLine("=====================================Folder Level  Comparison Completed=====Completed Time==={0}", System.DateTime.Now.ToString(), "====================================================");
                                                        Console.WriteLine("\n");

                                                        #endregion
                                                    }

                                                    else
                                                    {
                                                        MessageBox.Show("Please provide LisNamt to run ItemLevel Permission for Specify List/libraries");
                                                        return;
                                                    }
                                                }
                                                
                                            }
                                            catch (Exception ex)
                                            {
                                                _logger.ErrorFormat("Error Message: {0}", ex.Message.ToString());
                                            }

                                        }
                                    }
                                    Console.ResetColor();
                                    Console.ForegroundColor = ConsoleColor.Green;
                                    Console.WriteLine("Report Generated!");
                                    Console.WriteLine("Press ENTER to exit!");
                                    Console.ReadKey();
                                    MessageBox.Show("Report Generated");
                                }

                            }
                            catch (Exception ex)
                            {
                                _logger.ErrorFormat("Error Message: {0}", ex.Message.ToString());

                            }
                        }
                    }
                    else
                    {
                        MessageBox.Show("Please select a file containing Source,Destination URLs");
                    }
                }
                else if (btnsingleSite.Checked == true)
                {
                    if (txtSourceURL.Text != "" && txtDestinationURL.Text != "")
                    {
                        if (txtExport.Text == "")
                        {
                            MessageBox.Show("Please select a path for Report");
                        }
                        else
                        {
                            srcURL = this.txtSourceURL.Text;
                            destURL = this.txtDestinationURL.Text;
                            if (chkContentType.Checked == true)
                            {
                                _logger.InfoFormat("=====================================ContentType Comparison Started=====started Time==={0}", System.DateTime.Now.ToString());
                                Console.WriteLine("=====================================ContentType Comparison Started=====started Time==={0}", System.DateTime.Now.ToString());


                                cntypesfilepath = "Post_Migration_ContentTypeComparison_" + srcURL.Split('/').Last() + ".xlsx";
                                objcntyp.getContentTypes(srcURL, destURL, outputFilePath + "\\" + cntypesfilepath, IsrootSite);

                                _logger.InfoFormat("=====================================ContentType Comparison Completed=====Completed Time==={0}", System.DateTime.Now.ToString(), "====================================================");
                                Console.WriteLine("=====================================ContentType Comparison Completed=====Completed Time==={0}", System.DateTime.Now.ToString(), "====================================================");
                                Console.WriteLine("\n");
                            }
                            if (chkWebpart.Checked == true)
                            {
                                _logger.InfoFormat("=====================================Web parts Comparison Started=====started Time==={0}", System.DateTime.Now.ToString(), "====================================================");
                                Console.WriteLine("=====================================Web parts Comparison Started=====started Time==={0}", System.DateTime.Now.ToString(), "====================================================");

                                webpartfilepath = " Post_Migration_WebPartComparison_" + srcURL.Split('/').Last() + ".xlsx";


                                DataTable dtsrc = new DataTable();
                                dtsrc = objdt.getwebpartsrc();
                               objGetSiteInfo.getsrcwebpart(srcURL, dtsrc, IsrootSite);
                                DataTable dtdes = new DataTable();
                                dtdes = objdt.getwebpartDes();
                                objGetSiteInfo.getdeswebpart(destURL, dtdes, IsrootSite);
                                try
                                {
                                    List<DataRow> rowsToDelete = new List<DataRow>();
                                    foreach (DataRow DR in dtsrc.Rows)
                                    {
                                        if (DR["srcWebpartName"].ToString() == "FDMigrationBanner".ToString())
                                            rowsToDelete.Add(DR);
                                    }
                                    foreach (var r in rowsToDelete)
                                        dtsrc.Rows.Remove(r);
                                }
                                catch (Exception ex)
                                {

                                    _logger.ErrorFormat("Error Message: {0}", ex.Message.ToString());
                                }

                                DataTable dtwebpartSum = new DataTable();
                                dtwebpartSum = objGetSiteInfo.CompareWeparts(dtsrc, dtdes);
                                objExporttoExcel.CreateExcelDocumentFormatingWebparts(dtsrc, dtdes, dtwebpartSum, outputFilePath + "\\" + webpartfilepath);
                                _logger.InfoFormat("=====================================Web parts Comparison Completed=====Completed Time==={0}", System.DateTime.Now.ToString(), "====================================================");
                                Console.WriteLine("=====================================Web parts Comparison Completed=====Completed Time==={0}", System.DateTime.Now.ToString(), "====================================================");
                                Console.WriteLine("\n");

                            }
                            if (chkgrpper.Checked == true)
                            {
                                _logger.InfoFormat("=====================================groups Comparison Started=====Started Time==={0}", System.DateTime.Now.ToString(), "====================================================");
                                Console.WriteLine("=====================================groups Comparison Started=====Started Time==={0}", System.DateTime.Now.ToString(), "====================================================");

                                grpfilepath = "Post_Migration_GroupPermissionComparison_" + srcURL.Split('/').Last() + ".xlsx";
                                objGetSiteInfo.getsrcgrps(srcURL, IsrootSite);
                                objGetSiteInfo.getdesgrps(destURL, outputFilePath + "\\" + grpfilepath, IsrootSite);

                                _logger.InfoFormat("=====================================groups Comparison Completed=====Completed Time==={0}", System.DateTime.Now.ToString(), "====================================================");
                                Console.WriteLine("=====================================groups Comparison Completed=====Completed Time==={0}", System.DateTime.Now.ToString(), "====================================================");
                                Console.WriteLine("\n");

                            }
                            if (chkWrkflw.Checked == true)
                            {
                                _logger.InfoFormat("=====================================Workflow Comparison Started=====Started Time==={0}", System.DateTime.Now.ToString(), "====================================================");
                                Console.WriteLine("=====================================Workflow Comparison Started=====Started Time==={0}", System.DateTime.Now.ToString(), "====================================================");

                                DataTable dtsrc = new DataTable();
                                dtsrc = objdt.getDataTableWrksrc();
                                wrkflfilepath = "Post_Migration_WorkflowComparison_" + srcURL.Split('/').Last() + ".xlsx";
                                objGetSiteInfo.getWrkflwsrc(srcURL, dtsrc, IsrootSite);
                                DataTable dtdes = new DataTable();
                                dtdes = objdt.getDataTableWrkDes();
                                objGetSiteInfo.getWrkflwDes(destURL, dtdes, IsrootSite);
                                DataTable dtCmp = new DataTable();
                                dtCmp = objGetSiteInfo.CompareWrkflw(dtsrc, dtdes);
                                objExporttoExcel.CreateExcelDocumentFormatingWrkflow(dtsrc, dtdes, dtCmp, outputFilePath + "\\" + wrkflfilepath);

                                _logger.InfoFormat("=====================================Workflow Comparison Completed=====Completed Time==={0}", System.DateTime.Now.ToString());
                                Console.WriteLine("=====================================Workflow Comparison Completed=====Completed Time==={0}", System.DateTime.Now.ToString());
                                Console.WriteLine("\n");

                            }
                            if (chkDocument.Checked == true)
                            {
                                _logger.InfoFormat("=====================================Document Version Comparison Started=====Started Time==={0}", System.DateTime.Now.ToString(), "====================================================");
                                Console.WriteLine("=====================================Document Version Comparison Started=====Started Time==={0}", System.DateTime.Now.ToString(), "====================================================");
                                documentfilepath = "Post_Migration_DocumentVersionComparison_" + srcURL.Split('/').Last() + ".xlsx";
                                objGetSiteInfo.getDocumentVersion(srcURL, destURL, outputFilePath + "\\" + documentfilepath);

                                _logger.InfoFormat("=====================================Document Version Comparison Completed=====Completed Time==={0}", System.DateTime.Now.ToString(), "====================================================");
                                Console.WriteLine("=====================================Document Version Comparison Completed=====Completed Time==={0}", System.DateTime.Now.ToString(), "====================================================");
                                Console.WriteLine("\n");

                            }
                            if (chkItemLevelPermission.Checked == true)
                            {

                                ListName = string.Empty;
                                _logger.InfoFormat("=====================================Item Level Comparison Started=====Started Time==={0}", System.DateTime.Now.ToString(), "====================================================");
                                Console.WriteLine("=====================================Item Level  Comparison Started=====Started Time==={0}", System.DateTime.Now.ToString(), "====================================================");

                                userfilepath = "Post_Migration_ItemLevelPermission_" + srcURL.Split('/').Last() + ".xlsx";
                                objitemperm.getItemLevelComparison(srcURL, destURL, outputFilePath + "\\" + userfilepath, true, "", IsrootSite);
                                _logger.InfoFormat("=====================================Item Level Comparison Completed=====Completed Time==={0}", System.DateTime.Now.ToString(), "====================================================");
                                Console.WriteLine("=====================================Item Level  Comparison Completed=====Completed Time==={0}", System.DateTime.Now.ToString(), "====================================================");
                                Console.WriteLine("\n");
                            }
                            if (chkfldlevel.Checked == true)
                            {

                                _logger.InfoFormat("=====================================Folder Level Comparison Started=====Started Time==={0}", System.DateTime.Now.ToString(), "====================================================");
                                Console.WriteLine("=====================================Folder Level  Comparison Started=====Started Time==={0}", System.DateTime.Now.ToString(), "====================================================");

                                floderfilepath = "Post_Migration_FolderLevelComparison" + srcURL.Split('/').Last() + ".xlsx";
                                objfld.GetFolderLevelComparison(srcURL, destURL, outputFilePath + "\\" + floderfilepath, true, "", IsrootSite);

                                _logger.InfoFormat("=====================================Folder Level Comparison Completed=====Completed Time==={0}", System.DateTime.Now.ToString(), "====================================================");
                                Console.WriteLine("=====================================Folder Level  Comparison Completed=====Completed Time==={0}", System.DateTime.Now.ToString(), "====================================================");
                                Console.WriteLine("\n");

                            }
                            if (chkListPerm.Checked==true)
                            {
                                _logger.InfoFormat("=====================================List/Library Permission Comparison Started=====started Time==={0}", System.DateTime.Now.ToString());
                                Console.WriteLine("=====================================List/Library Permission Comparison Started=====started Time==={0}", System.DateTime.Now.ToString());
                                userfilepath = "Post_Migration_Item_List_Library_LevelPermission_" + srcURL.Split('/').Last() + ".xlsx";

                                DataTable dtsrc = new DataTable();
                                dtsrc = objdt.getDataTableListPersrc();
                                objGetSiteInfo.getListPermSrc(srcURL, dtsrc, IsrootSite);

                                DataTable dtdes = new DataTable();
                                dtdes = objdt.getDataTableListPerDes();
                                objGetSiteInfo.getListPermdes(destURL, dtdes, IsrootSite);

                                DataTable dtList = new DataTable();
                                dtList = objdt.getDataTableListPerCompare();
                                CompareListPerm(dtsrc, dtdes, dtList);

                                objExporttoExcel.CreateExcelDocumentFormatingListPerm(dtsrc, dtdes, dtList, outputFilePath + "\\" + userfilepath);
                                _logger.InfoFormat("=====================================List/Library Permission Comparison Completed=====Completed Time==={0}", System.DateTime.Now.ToString());
                                Console.WriteLine("=====================================List/Library Permission Comparison Completed=====Completed Time==={0}", System.DateTime.Now.ToString());
                            }
                            if (chkListFields.Checked == true)
                            {
                                cntypesfilepath = string.Empty;
                                cntypesfilepath = "Post_Migration_listfieldsassociatedcontenttypeComparison_" + srcURL.Split('/').Last() + ".xlsx";
                                _logger.InfoFormat("=====================================list fields and the associated content type Comparison Started=====started Time==={0}", System.DateTime.Now.ToString(), "====================================================");
                                Console.WriteLine("=====================================list fields and the associated content type Comparison Started=====started Time==={0}", System.DateTime.Now.ToString(), "====================================================");
                                DataTable dtcntypesrc = new DataTable();
                                dtcntypesrc = objdt.getDataTableListContentTypes();

                                DataTable dtsrcList = new DataTable();
                                dtsrcList = objdt.getDataTableListContentTypes();
                                objGetSiteInfo.Listassociatedcontenttype(srcURL, dtcntypesrc, dtsrcList, IsrootSite);

                                DataTable dtcntypedes = new DataTable();
                                dtcntypedes = objdt.getDataTableListContentTypesDes();

                                DataTable dtdesList = new DataTable();
                                dtdesList = objdt.getDataTableListContentTypes();
                                objGetSiteInfo.ListassociatedcontenttypeDes(destURL, dtcntypedes, dtdesList, IsrootSite);

                                DataTable dtListCntType = new DataTable();
                                //dtListCntType = objdt.getDataTableListCompareContentTypes();
                               // CompareListContentTypes(dtsrcList, dtdesList, dtListCntType);
                                objExporttoExcel.CreateExcelDocumentFormatingListassociatedcontenttype(dtsrcList, dtdesList, dtListCntType, outputFilePath + "\\" + cntypesfilepath);
                                _logger.InfoFormat("=====================================list fields and the associated content type Comparison Started=====Completed Time==={0}", System.DateTime.Now.ToString(), "====================================================");
                                Console.WriteLine("=====================================list fields and the associated content type Comparison Started=====Completed Time==={0}", System.DateTime.Now.ToString(), "====================================================");
                            }
                            if (chkItemLevelLists.Checked == true)
                            {
                                ListName = ConfigurationSettings.AppSettings["ListName"].ToString();
                                if (!string.IsNullOrEmpty(ListName))
                                {


                                    #region Item Level Comparison only for lists/libraries
                                    _logger.InfoFormat("=====================================Item Level Comparison only for lists/libraries Started=====Started Time==={0}", System.DateTime.Now.ToString(), "====================================================");
                                    Console.WriteLine("=====================================Item Level  Comparison only for lists/libraries Started=====Started Time==={0}", System.DateTime.Now.ToString(), "====================================================");
                                    userfilepath = "Post_Migration_ItemLevelPermission_" + srcURL.Split('/').Last() + "_" + ListName + ".xlsx";

                                    objitemperm.getItemLevelComparison(srcURL, destURL, outputFilePath + "\\" + userfilepath, false, ListName, IsrootSite);

                                    _logger.InfoFormat("=====================================Item Level Comparison Completed=====Completed Time==={0}", System.DateTime.Now.ToString(), "====================================================");
                                    Console.WriteLine("=====================================Item Level  Comparison Completed=====Completed Time==={0}", System.DateTime.Now.ToString(), "====================================================");
                                    Console.WriteLine("\n");
                                    #endregion

                                    #region Folder Level Comparison only for lists/libraries
                                    _logger.InfoFormat("=====================================Folder Level Comparison Started only for lists/libraries=====Started Time==={0}", System.DateTime.Now.ToString(), "====================================================");
                                    Console.WriteLine("=====================================Folder Level  Comparison Started only for lists/libraries=====Started Time==={0}", System.DateTime.Now.ToString(), "====================================================");

                                    floderfilepath = "Post_Migration_FolderLevelComparison" + srcURL.Split('/').Last() + "_" + ListName + ".xlsx";
                                    // objfld.GetFolderLevelComparison(srcURL, destURL, outputFilePath + "\\" + floderfilepath, false, ListName);

                                    _logger.InfoFormat("=====================================Folder Level Comparison Completed=====Completed Time==={0}", System.DateTime.Now.ToString(), "====================================================");
                                    Console.WriteLine("=====================================Folder Level  Comparison Completed=====Completed Time==={0}", System.DateTime.Now.ToString(), "====================================================");
                                    Console.WriteLine("\n");

                                    #endregion
                                }

                                else
                                {
                                    MessageBox.Show("Please provide LisNamt to run ItemLevel Permission for Specify List/libraries");
                                    return;
                                }
                            }
                            if (chkFeatureComparsion.Checked == true)
                            {
                                _logger.InfoFormat("=====================================Site Fetures  Comparison Started=====Started Time==={0}", System.DateTime.Now.ToString(), "====================================================");
                                Console.WriteLine("=====================================Site Fetures   Comparison Started=====Started Time==={0}", System.DateTime.Now.ToString(), "====================================================");
                                featurefileapth = "Post_Migration_FeatureComparison_" + srcURL.Split('/').Last() + ".xlsx";
                                objGetSiteInfo.getFeatureComparsion(srcURL, destURL, outputFilePath + "\\" + featurefileapth);

                                _logger.InfoFormat("=====================================Site Fetures  Comparison Completed=====Completed Time==={0}", System.DateTime.Now.ToString(), "====================================================");
                                Console.WriteLine("=====================================Site Fetures   Comparison Completed=====Completed Time==={0}", System.DateTime.Now.ToString(), "====================================================");
                                Console.WriteLine("\n");

                            }
                            Console.ResetColor();
                            Console.ForegroundColor = ConsoleColor.Green;
                            Console.WriteLine("Report Generated!");
                            Console.WriteLine("Press ENTER to exit!");
                            Console.ReadKey();
                        }
                    }
                    else
                    {
                        MessageBox.Show("Please enter Source and Destination URLs");
                    }
                }
                else
                {
                    MessageBox.Show("Please select any option");
                    return;
                }
            }
            catch (Exception ex)
            {
                _logger.ErrorFormat("Error Message: {0}", ex.Message.ToString());
            }
        }

        private static void CompareListPerm(DataTable dtsrcList, DataTable dtdesList, DataTable dtListCntType)
        {
            DataTable dtMisMatchSource = new DataTable();
            DataTable dtMisMatchTarget = new DataTable();
            try
            {
                if (dtsrcList.Rows.Count > 0)
                {


                    dtMisMatchSource = (from r in dtsrcList.AsEnumerable()
                                        where !dtdesList.AsEnumerable().Any(r2 => r["ListName"].ToString().Trim().ToLower() == r2["ListName"].ToString().Trim().ToLower()
                                            && r["ListPermission"].ToString().Trim().ToLower() == r2["ListPermission"].ToString().Trim().ToLower())
                                        select r).CopyToDataTable();
                }
            }
            catch (Exception ex)
            {

                _logger.ErrorFormat("Error Message: {0}", ex.Message.ToString());
            }
            try
            {
                if (dtdesList.Rows.Count > 0)
                {
                    dtMisMatchTarget = (from r in dtdesList.AsEnumerable()
                                        where !dtsrcList.AsEnumerable().Any(r2 => r["ListName"].ToString().Trim().ToLower() == r2["ListName"].ToString().Trim().ToLower()
                                            && r["ListPermission"].ToString().Trim().ToLower() == r2["ListPermission"].ToString().Trim().ToLower())
                                        select r).CopyToDataTable();
                }
            }
            catch (Exception ex)
            {

                _logger.ErrorFormat("Error Message: {0}", ex.Message.ToString());
            }
           

            if (dtMisMatchSource != null)
            {
                if (dtMisMatchSource.Rows.Count > 0)
                {

                    for (int i = 0; i < dtMisMatchSource.Rows.Count; i++)
                    {
                        DataRow row = dtListCntType.NewRow();
                        row["SiteUrl"] = dtMisMatchSource.Rows[i]["SiteUrl"].ToString();
                        row["ListName"] = dtMisMatchSource.Rows[i]["ListName"].ToString(); ;
                        row["ListPermission"] = dtMisMatchSource.Rows[i]["ListPermission"].ToString(); 
                        row["Users/Group"] = dtMisMatchSource.Rows[i]["Users/Group"].ToString(); ;
                        dtListCntType.Rows.Add(row);
                    }
                }
            }
            if (dtMisMatchTarget != null)
            {
                if (dtMisMatchTarget.Rows.Count > 0)
                {

                    for (int i = 0; i < dtMisMatchTarget.Rows.Count; i++)
                    {
                        DataRow row = dtListCntType.NewRow();
                        row["DesSiteUrl"] = dtMisMatchTarget.Rows[i]["SiteUrl"].ToString();
                        row["DesListName"] = dtMisMatchTarget.Rows[i]["ListName"].ToString(); ;
                        row["DesListPermission"] = dtMisMatchTarget.Rows[i]["ListPermission"].ToString();
                        row["DesUsers/Group"] = dtMisMatchTarget.Rows[i]["Users/Group"].ToString(); ;
                        dtListCntType.Rows.Add(row);
                    }
                }
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            try
            {
                if (this.txtSourceURL.Text != null)
                {
                    this.txtSourceURL.Clear();
                }
                if (this.txtDestinationURL.Text != null)
                {
                    this.txtDestinationURL.Clear();
                }
                if (this.txtURLFile.Text != null)
                {
                    this.txtURLFile.Clear();
                }
                if (this.txtExport.Text != null)
                {
                    this.txtExport.Clear();
                }
                if (this.btnsingleSite.Checked)
                {
                    this.btnsingleSite.Checked = false;
                }
                if (this.btnMultipleSites.Checked)
                {
                    this.btnMultipleSites.Checked = false;
                }
                this.txtSourceURL.Enabled = true;
                this.txtDestinationURL.Enabled = true;
                this.btnURLFile.Enabled = true;
                this.txtURLFile.Enabled = true;

            }
            catch (Exception)
            {

                throw;
            }
        }
        private void btnExit_Click(object sender, EventArgs e)
        {
            try
            {
                string message = "Do you want to close this window?";
                string title = "Close Window";
                MessageBoxButtons buttons = MessageBoxButtons.YesNo;

                DialogResult result = MessageBox.Show(message, title, buttons, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2);

                if (result == DialogResult.Yes)
                {
                    this.Close();
                }
                else
                {
                    // Do something  
                }
                // this.Close();
            }
            catch (Exception)
            {

                throw;
            }
        }
        private void txtSourceURL_TextChanged(object sender, EventArgs e)
        {
            if (this.btnsingleSite.Checked == false)
            {
                if (this.txtSourceURL.Text != null)
                {
                    this.btnsingleSite.Checked = true;
                }
            }
        }
        private void txtDestinationURL_TextChanged(object sender, EventArgs e)
        {
            if (this.btnsingleSite.Checked == false)
            {
                if (this.txtDestinationURL.Text != null)
                {
                    this.btnsingleSite.Checked = true;
                }
            }
        }
        private void txtURLFile_TextChanged(object sender, EventArgs e)
        {
            if (this.btnMultipleSites.Checked == false)
            {
                if (this.txtDestinationURL.Text != null)
                {
                    this.btnMultipleSites.Checked = true;
                }
            }
        }
        private void btnExport_Click(object sender, EventArgs e)
        {
            if (this.fbdExport.ShowDialog() == DialogResult.OK)
            {
                this.txtURLFile.Text = this.fbdExport.SelectedPath;
            }
        }

        private void btnURLFile_Click(object sender, EventArgs e)
        {
            if (this.fbdExport.ShowDialog() == DialogResult.OK)
            {
                this.txtExport.Text = this.fbdExport.SelectedPath;
            }
        }

        private void btnsingleSite_CheckedChanged(object sender, EventArgs e)
        {
            if (this.txtURLFile.Text != "")
            {

                this.txtURLFile.Clear();
                this.btnsingleSite.Checked = true;
            }
            if (this.btnsingleSite.Checked)
            {
                this.txtSourceURL.Enabled = true;
                this.txtDestinationURL.Enabled = true;
                // this.btnURLFile.Enabled = false;
                this.txtURLFile.Clear();
                this.txtURLFile.Enabled = false;
            }
        }

        private void btnMultipleSites_CheckedChanged(object sender, EventArgs e)
        {
            if (this.txtSourceURL.Text != "" || this.txtDestinationURL.Text != "")
            {
                this.txtSourceURL.Clear();
                this.txtDestinationURL.Clear();
                this.btnMultipleSites.Checked = true;

            }
            if (this.btnMultipleSites.Checked)
            {
                this.txtSourceURL.Enabled = false;
                this.txtDestinationURL.Enabled = false;
                // this.btnURLFile.Enabled = true;
                this.txtURLFile.Enabled = true;
                this.txtSourceURL.Clear();
                this.txtDestinationURL.Clear();
            }
        }

        private void ChkAll_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                if (ChkAll.Checked == true)
                {
                    chkContentType.Checked = true;
                    chkWebpart.Checked = true;
                    chkgrpper.Checked = true;
                    chkItemLevelPermission.Checked = true;
                    chkDocument.Checked = true;
                    chkFeatureComparsion.Checked = true;
                    chkWrkflw.Checked = true;
                    chkfldlevel.Checked = true;
                    chkListPerm.Checked = true;
                   // chkItemLevelLists.Checked = true;
                }
                else
                {
                    chkContentType.Checked = false;
                    chkWebpart.Checked = false;
                    chkgrpper.Checked = false;
                    chkItemLevelPermission.Checked = false;
                    chkDocument.Checked = false;
                    chkFeatureComparsion.Checked = false;
                    chkWrkflw.Checked = false;
                    chkfldlevel.Checked = false;
                    chkListPerm.Checked = false;
                    //chkItemLevelLists.Checked = false;
                }
            }
            catch (Exception)
            {

                throw;
            }
        }
    }
}
