﻿using Microsoft.SharePoint.Client;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net.Http;
using System.Security;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Configuration;
using PostMigrationToolV2.nJSubwebs;
using PostMigrationToolV2.nJLibrarys;
using PostMigrationToolV2.nJLibrarysRole;
using System.IO;
using Microsoft.VisualBasic.FileIO;

namespace PostMigrationToolV2
{
    public class Get_Folder_Level_Permissions
    {
        DataTable dtsrc = new DataTable();
        DataTable dtdes = new DataTable();
        DataTable dtuserssum = new DataTable();
        DataTable dtFldsum = new DataTable();
        ExporttoExcel objExporttoExcel = new ExporttoExcel();
        Connection objConnection = new Connection();
        public string ContentsPath = "";
        private ClientContext sContext;
        private static readonly log4net.ILog _logger = log4net.LogManager.GetLogger(typeof(Program));
        public void GetFolderLevelComparison(string sourceUrl, string destUrl, string filepath, bool isFlag, string ListName,bool IsrootSite)
        {
            string url = string.Empty;
            UtliClass util = new UtliClass();
            SecureString securePassword = new SecureString();
            StringBuilder stringBuilder = new StringBuilder();
            DataTable DtDoc = new DataTable();
            try
            {
                dtsrc = new DataTable();
                dtsrc.Columns.Add("SourceUrl", typeof(string));
                dtsrc.Columns.Add("SrcLibraryName", typeof(string));
                dtsrc.Columns.Add("SrcFolderName", typeof(string));
                dtsrc.Columns.Add("FileRef", typeof(string));
                dtsrc.Columns.Add("User/Group", typeof(string));
                dtsrc.Columns.Add("UserPrincipalName", typeof(string));
                dtsrc.Columns.Add("SrcPermissions", typeof(string));
                dtsrc.Columns.Add("HasUnique", typeof(string));


                dtdes = new DataTable();
                dtdes.Columns.Add("TargetUrl", typeof(string));
                dtdes.Columns.Add("DesLibraryName", typeof(string));
                dtdes.Columns.Add("DesFolderName", typeof(string));
                dtdes.Columns.Add("FileRef", typeof(string));
                dtdes.Columns.Add("User/Group", typeof(string));
                dtdes.Columns.Add("DesPermissions", typeof(string));
                dtdes.Columns.Add("HasUnique", typeof(string));
                dtdes.Columns.Add("SAMAccountName", typeof(string));


                util.UserName = ConfigurationSettings.AppSettings["domain"].ToString() + "\\" + ConfigurationSettings.AppSettings["SRCUserName"].ToString();
                util.Password = ConfigurationSettings.AppSettings["SRCPassword"].ToString();
                util.SPOuserName = ConfigurationSettings.AppSettings["OnlineUserName"].ToString();
                string SPOpassword = ConfigurationSettings.AppSettings["password"].ToString();
                foreach (var c in SPOpassword) securePassword.AppendChar(c);
                util.SPOpassword = securePassword;
                util.stringBuilder = stringBuilder;
                util.stringBuilder.AppendLine("Site Name,Source,Destination");
                url = "{0}/_api/web?&$select=Title";
                string jsonResponse = GetRestResult(string.Format(url, sourceUrl), util.SourcehttpClientHandler).Result;
                Newtonsoft.Json.Linq.JObject o = Newtonsoft.Json.Linq.JObject.Parse(jsonResponse);
                string siteName = Convert.ToString(o.SelectToken("d").SelectToken("Title"));
                util.stringBuilder.AppendLine(string.Format("{0},{1},{2}", siteName, sourceUrl, destUrl));
                try
                {

                    Console.WriteLine("Current Site Url:-{0},{1}", sourceUrl.ToString(), destUrl);
                    _logger.InfoFormat("Current Site Url:-{0},{1}", sourceUrl.ToString(), destUrl);

                    if (isFlag == true)
                    {
                        DocLibDiffReporter(util, sourceUrl, destUrl);
                        if (IsrootSite==false)
                        {
                            SubwebsDiffReporter(util, sourceUrl, destUrl);
                        }
                       
                        DataTable dtmlslog = new DataTable();
                        dtmlslog = GetValuesDataTabletFromCSVFile();
                        foreach (DataRow rowMasterItems in dtsrc.Rows)
                        {
                            string val = rowMasterItems["User/Group"].ToString().ToLower();
                            try
                            {
                                var results = (from row in dtmlslog.AsEnumerable()
                                               where row.Field<string>("SAMAccountName").ToString().ToLower() == val
                                               select row.Field<string>("UserPrincipalName"));
                                if (results.ToArray().Length > 0)
                                {
                                    rowMasterItems["UserPrincipalName"] = results.ToArray()[0].ToString().ToLower();
                                    rowMasterItems.AcceptChanges();
                                }
                                else
                                {
                                    rowMasterItems["UserPrincipalName"] = "not present in MLS Log Files";
                                    rowMasterItems.AcceptChanges();
                                }

                            }
                            catch (Exception ex)
                            {

                                _logger.ErrorFormat("Error in Item Level :{0},StackeTrace:{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
                                Console.WriteLine("Error in Item Level :{0},StackeTrace:{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
                            }
                        }
                        foreach (DataRow rowMasterItems in dtdes.Rows)
                        {
                            string val = rowMasterItems["User/Group"].ToString().ToLower();
                            try
                            {
                                var results = (from row in dtmlslog.AsEnumerable()
                                               where row.Field<string>("UserPrincipalName").ToString().ToLower() == val
                                               select row.Field<string>("SAMAccountName"));
                                if (results.ToArray().Length > 0)
                                {
                                    rowMasterItems["SAMAccountName"] = results.ToArray()[0].ToString().ToLower();
                                    rowMasterItems.AcceptChanges();
                                }
                                else
                                {
                                    rowMasterItems["SAMAccountName"] = "not present in MLS Log Files";
                                    rowMasterItems.AcceptChanges();
                                }

                            }
                            catch (Exception ex)
                            {

                                _logger.ErrorFormat("Error in Item Level :{0},StackeTrace:{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
                                Console.WriteLine("Error in Item Level :{0},StackeTrace:{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
                            }
                        }
                        CompareFolderLevelPermission();
                        objExporttoExcel.CreateExcelDocumentFormatingFolderLevelPermission(dtsrc, dtdes, dtFldsum, filepath);

                    }

                    if (!string.IsNullOrEmpty(ListName))
                    {
                        getFolderlevelPermissionSource(sourceUrl, ListName);
                        getFolderlevelPermissionTarget(destUrl, ListName);
                        DataTable dtmlslog = new DataTable();
                        dtmlslog = GetValuesDataTabletFromCSVFile();
                        foreach (DataRow rowMasterItems in dtsrc.Rows)
                        {
                            string val = rowMasterItems["User/Group"].ToString().ToLower();
                            try
                            {
                                var results = (from row in dtmlslog.AsEnumerable()
                                               where row.Field<string>("SAMAccountName").ToString().ToLower() == val
                                               select row.Field<string>("UserPrincipalName"));
                                if (results.ToArray().Length > 0)
                                {
                                    rowMasterItems["UserPrincipalName"] = results.ToArray()[0].ToString().ToLower();
                                    rowMasterItems.AcceptChanges();
                                }
                                else
                                {
                                    rowMasterItems["UserPrincipalName"] = "not present in MLS Log Files";
                                    rowMasterItems.AcceptChanges();
                                }

                            }
                            catch (Exception ex)
                            {

                                _logger.ErrorFormat("Error in Item Level :{0},StackeTrace:{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
                                Console.WriteLine("Error in Item Level :{0},StackeTrace:{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
                            }
                        }
                        foreach (DataRow rowMasterItems in dtdes.Rows)
                        {
                            string val = rowMasterItems["User/Group"].ToString().ToLower();
                            try
                            {
                                var results = (from row in dtmlslog.AsEnumerable()
                                               where row.Field<string>("UserPrincipalName").ToString().ToLower() == val
                                               select row.Field<string>("SAMAccountName"));
                                if (results.ToArray().Length > 0)
                                {
                                    rowMasterItems["SAMAccountName"] = results.ToArray()[0].ToString().ToLower();
                                    rowMasterItems.AcceptChanges();
                                }
                                else
                                {
                                    rowMasterItems["SAMAccountName"] = "not present in MLS Log Files";
                                    rowMasterItems.AcceptChanges();
                                }

                            }
                            catch (Exception ex)
                            {

                                _logger.ErrorFormat("Error in Item Level :{0},StackeTrace:{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
                                Console.WriteLine("Error in Item Level :{0},StackeTrace:{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
                            }
                        }
                        CompareFolderLevelPermission();
                        objExporttoExcel.CreateExcelDocumentFormatingFolderLevelPermission(dtsrc, dtdes, dtFldsum, filepath);
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error in Folder Level :{0},StackeTrace:{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
                    _logger.ErrorFormat("Error in Folder Level :{0},StackeTrace:{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
                }

            }
            catch (Exception ex)
            {
                _logger.ErrorFormat("Error in Folder Level :{0},StackeTrace:{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
                Console.WriteLine("Error in Folder Level :{0},StackeTrace:{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
            }

        }
        public DataTable GetValuesDataTabletFromCSVFile()
        {
            ContentsPath = ConfigurationSettings.AppSettings["MLSLogFile"];
            DataTable csvData = new DataTable();
            try
            {

                using (TextFieldParser csvReader = new TextFieldParser(ContentsPath))
                {
                    csvReader.SetDelimiters(new string[] { "," });
                    csvReader.HasFieldsEnclosedInQuotes = true;
                    //read column names
                    string[] colFields = csvReader.ReadFields();
                    foreach (string column in colFields)
                    {
                        DataColumn datecolumn = new DataColumn(column);
                        datecolumn.AllowDBNull = true;
                        csvData.Columns.Add(datecolumn);
                    }
                    while (!csvReader.EndOfData)
                    {
                        string[] fieldData = csvReader.ReadFields();
                        //Making empty value as null
                        for (int i = 0; i < fieldData.Length; i++)
                        {
                            if (fieldData[i] == "")
                            {
                                fieldData[i] = null;
                            }
                        }
                        csvData.Rows.Add(fieldData);
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.ErrorFormat("Error Message: {0}", ex.Message.ToString());
            }
            return csvData;
        }
        public void CompareFolderLevelPermission()
        {
            DataTable dtMisMatchSource = new DataTable();
            DataTable dtMisMatchTarget = new DataTable();
            try
            {
                if (dtsrc.Rows.Count > 0)
                {
                    //dtMisMatchSource = (from r in dtsrc.AsEnumerable()
                    //                    where !dtdes.AsEnumerable().Any(r2 => r["User/Group"].ToString().Trim().ToLower() == r2["SAMAccountName"].ToString().Trim().ToLower()
                    //                        && r["SrcPermissions"].ToString().Trim().ToLower() == r2["DesPermissions"].ToString().Trim().ToLower()
                    //                        && r["SrcFolderName"].ToString().Trim().ToLower() == r2["DesFolderName"].ToString().Trim().ToLower())
                    //                    select r).CopyToDataTable();

                    dtMisMatchSource = (from r in dtsrc.AsEnumerable()
                                        where !dtdes.AsEnumerable().Any(r2 => r["SrcPermissions"].ToString().Trim().ToLower() == r2["DesPermissions"].ToString().Trim().ToLower()
                                            && r["SrcFolderName"].ToString().Trim().ToLower() == r2["DesFolderName"].ToString().Trim().ToLower())
                                        select r).CopyToDataTable();
                }


                


            }
            catch (Exception ex)
            {

                _logger.ErrorFormat("Error Message: {0}", ex.Message.ToString());
            }

            try
            {
                if (dtdes.Rows.Count > 0)
                {
                    dtMisMatchTarget = (from r in dtdes.AsEnumerable()
                                        where !dtsrc.AsEnumerable().Any(r2 => r["DesPermissions"].ToString().Trim().ToLower() == r2["SrcPermissions"].ToString().Trim().ToLower()
                                            && r["DesFolderName"].ToString().Trim().ToLower() == r2["SrcFolderName"].ToString().Trim().ToLower())
                                        select r).CopyToDataTable();
                }
            }
            catch (Exception ex)
            {

                _logger.ErrorFormat("Error Message: {0}", ex.Message.ToString());
            }
            try
            {


                dtFldsum = new DataTable();
                dtFldsum.Columns.Add("SourceUrl", typeof(string));
                dtFldsum.Columns.Add("SrcLibraryName", typeof(string));
                dtFldsum.Columns.Add("SrcFileRef", typeof(string));
                dtFldsum.Columns.Add("SrcFolderName", typeof(string));
                dtFldsum.Columns.Add("SrcUser/Group", typeof(string));
                dtFldsum.Columns.Add("UserPrincipalName", typeof(string));
                dtFldsum.Columns.Add("SrcPermissions", typeof(string));
                dtFldsum.Columns.Add("TargetUrl", typeof(string));
                dtFldsum.Columns.Add("DesLibraryName", typeof(string));
                dtFldsum.Columns.Add("DesFolderName", typeof(string));
                dtFldsum.Columns.Add("DesFileRef", typeof(string));
                dtFldsum.Columns.Add("DesUser/Group", typeof(string));
                dtFldsum.Columns.Add("SAMAccountName", typeof(string));
                dtFldsum.Columns.Add("DesPermissions", typeof(string));
                dtFldsum.Columns.Add("HasUnique", typeof(string));

                if (dtMisMatchSource != null)
                {
                    if (dtMisMatchSource.Rows.Count > 0)
                    {

                        for (int i = 0; i < dtMisMatchSource.Rows.Count; i++)
                        {
                            if (dtMisMatchSource.Rows[i]["UserPrincipalName"].ToString().ToLower() != "i:0#.f|membership|svc-SPO-MigAdmin11@firstdata.onmicrosoft.com".ToString().ToLower())
                            {
                                DataRow row = dtFldsum.NewRow();

                                row["SourceUrl"] = dtMisMatchSource.Rows[i]["SourceUrl"];
                                row["SrcLibraryName"] = dtMisMatchSource.Rows[i]["SrcLibraryName"];
                                row["SrcFolderName"] = dtMisMatchSource.Rows[i]["SrcFolderName"];
                                row["SrcFileRef"] = dtMisMatchSource.Rows[i]["FileRef"];
                                row["SrcUser/Group"] = dtMisMatchSource.Rows[i]["User/Group"];
                                row["UserPrincipalName"] = dtMisMatchSource.Rows[i]["UserPrincipalName"];
                                row["SrcPermissions"] = dtMisMatchSource.Rows[i]["SrcPermissions"];
                                row["HasUnique"] = dtMisMatchSource.Rows[i]["HasUnique"];

                                dtFldsum.Rows.Add(row);
                            }
                        }
                    }
                }

                if (dtMisMatchTarget != null)
                {
                    if (dtMisMatchTarget.Rows.Count > 0)
                    {
                        for (int i = 0; i < dtMisMatchTarget.Rows.Count; i++)
                        {
                            if (dtMisMatchTarget.Rows[i]["User/Group"].ToString().ToLower() != "i:0#.f|membership|svc-SPO-MigAdmin11@firstdata.onmicrosoft.com".ToString().ToLower())
                            {

                                DataRow row = dtFldsum.NewRow();
                                row["TargetUrl"] = dtMisMatchTarget.Rows[i]["TargetUrl"];
                                row["DesLibraryName"] = dtMisMatchTarget.Rows[i]["DesLibraryName"];
                                row["DesFolderName"] = dtMisMatchTarget.Rows[i]["DesFolderName"];
                                row["DesFileRef"] = dtMisMatchTarget.Rows[i]["FileRef"];
                                row["DesUser/Group"] = dtMisMatchTarget.Rows[i]["User/Group"];
                                row["SAMAccountName"] = dtMisMatchTarget.Rows[i]["SAMAccountName"];
                                row["DesPermissions"] = dtMisMatchTarget.Rows[i]["DesPermissions"];
                                row["HasUnique"] = dtMisMatchTarget.Rows[i]["HasUnique"];
                                dtFldsum.Rows.Add(row);
                            }
                        }
                    }
                }




            }
            catch (Exception ex)
            {
                _logger.ErrorFormat("Error in Folder Level :{0},StackeTrace:{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
                //Console.WriteLine("Error in Folder Level :{0},StackeTrace:{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
            }

        }

        private void SubwebsDiffReporter(UtliClass util, string sourceUrl, string destUrl)
        {
            try
            {
                string url = "{0}/_api/web/Webs?$select=Title,Url,ServerRelativeUrl";
                string temp = string.Empty;
                string jsonResponse = GetRestResult(string.Format(url, sourceUrl), util.SourcehttpClientHandler).Result;
                JSubwebs subwebsS = JsonConvert.DeserializeObject<JSubwebs>(jsonResponse);
                jsonResponse = GetRestResult(string.Format(url, destUrl), GetSPOClientHandler(string.Format(url, destUrl), util)).Result;
                JSubwebs subwebsD = JsonConvert.DeserializeObject<JSubwebs>(jsonResponse);
                IEnumerable<nJSubwebs.Result> diffsubwebs = subwebsS.d.results.Where(s => !subwebsD.d.results.Any(d => s.Title == d.Title));
                if (subwebsS.d.results.Length > 0 || subwebsD.d.results.Length > 0)
                    util.stringBuilder.AppendLine("Sub Sites,,");

                diffsubwebs = subwebsD.d.results.Where(s => !subwebsS.d.results.Any(d => s.Title == d.Title));

                diffsubwebs = subwebsS.d.results.Where(s => subwebsD.d.results.Any(d => s.Title == d.Title));
                foreach (nJSubwebs.Result result in diffsubwebs.ToArray())
                {
                    temp = result.ServerRelativeUrl.Split('/')[result.ServerRelativeUrl.Split('/').Length - 1];

                    DocLibDiffReporter(util, string.Format("{0}/{1}", sourceUrl, temp), string.Format("{0}/{1}", destUrl, temp));
                    SubwebsDiffReporter(util, string.Format("{0}/{1}", sourceUrl, temp), string.Format("{0}/{1}", destUrl, temp));
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error in Folder Level :{0},StackeTrace:{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
                _logger.ErrorFormat("Error in Folder Level :{0},StackeTrace:{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
            }

        }

        private void DocLibDiffReporter(UtliClass util, string sourceUrl, string destUrl)
        {
            try
            {
                util.stringBuilder.AppendLine("Document Library,,");
                string url = "{0}/_api/web/lists?$select=Title,EntityTypeName,ItemCount,id&$filter=BaseTemplate eq 101 or BaseTemplate eq 851 or BaseTemplate eq 109 or BaseTemplate eq 110 or BaseTemplate eq 130 or BaseTemplate eq 850 or BaseTemplate eq 433";
                string jsonResponse = GetRestResult(string.Format(url, sourceUrl), util.SourcehttpClientHandler).Result;
                JLibrarys jLibs = JsonConvert.DeserializeObject<JLibrarys>(jsonResponse);
                jsonResponse = GetRestResult(string.Format(url, destUrl), GetSPOClientHandler(string.Format(url, destUrl), util)).Result;
                JLibrarys jLibsd = JsonConvert.DeserializeObject<JLibrarys>(jsonResponse);
                IEnumerable<nJLibrarys.Result> diffdocLib = jLibs.d.results.Where(s => !jLibsd.d.results.Any(des => s.EntityTypeName == des.EntityTypeName));
                diffdocLib = jLibsd.d.results.Where(s => !jLibs.d.results.Any(des => s.EntityTypeName == des.EntityTypeName));
                diffdocLib = jLibsd.d.results.Where(s => jLibs.d.results.Any(des => s.EntityTypeName == des.EntityTypeName));
                foreach (nJLibrarys.Result result in diffdocLib.ToArray())
                {
                    // Console.WriteLine(string.Format("{0} , {1}, {2}", result.Title, jLibs.d.results.Where(des => des.EntityTypeName == result.EntityTypeName).First().Title, result.ItemCount));
                    if (int.Parse(result.ItemCount) > 0)
                    {
                        //  util.stringBuilder.AppendLine(string.Format("{0},{1},{2}", result.Title, jLibs.d.results.Where(des => des.EntityTypeName == result.EntityTypeName).First().ItemCount, result.ItemCount));
                        DocDiffReporter(util, sourceUrl, destUrl, result, jLibs.d.results.Where(des => des.EntityTypeName == result.EntityTypeName).First());
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error in Folder Level :{0},StackeTrace:{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
                _logger.ErrorFormat("Error in Folder Level :{0},StackeTrace:{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
            }


        }

        private void DocDiffReporter(UtliClass util, string sourceUrl, string destUrl, nJLibrarys.Result result, nJLibrarys.Result socresult)
        {
            try
            {
                Console.WriteLine("\n");
                Console.WriteLine("Current Site Url & List Name:-{0},{1},{2}", sourceUrl, destUrl, result.Title);
                getFolderlevelPermissionSource(sourceUrl, result.Title);
                getFolderlevelPermissionTarget(destUrl, result.Title);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error in Folder Level :{0},StackeTrace:{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
                _logger.ErrorFormat("Error in Folder Level :{0},StackeTrace:{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
            }

        }

        private void getFolderlevelPermissionSource(string srcurl, string LstName)
        {
            try
            {
                sContext = new ClientContext(srcurl);
                Web web = sContext.Web;
                sContext.Load(web);
                sContext.Load(web, wb => wb.ServerRelativeUrl, wb => wb.HasUniqueRoleAssignments);
                sContext.ExecuteQuery();
                //if (web.HasUniqueRoleAssignments == true)
                //{
                    List list = web.Lists.GetByTitle(LstName);
                    sContext.Load(list, l => l.RootFolder, l => l.ItemCount, l => l.RootFolder.Folders);
                    sContext.ExecuteQuery();
                    ListItemCollectionPosition position = null;
                    int rowLimit = 5000;
                    if (list != null && list.ItemCount > 0)
                    {
                        CamlQuery camlQuery = new CamlQuery();
                        camlQuery.ViewXml =
                            "<View Scope='RecursiveAll'>"
                          + "  <Query>"
                          + "    <Where>"
                          + "      <Eq><FieldRef Name='FSObjType' /><Value Type='Integer'>1</Value></Eq>"
                          + "    </Where>"
                          + "  </Query>"
                          + "  <ViewFields><FieldRef Name='Title' /></ViewFields>"
                          + "<RowLimit Paged='TRUE'>" + rowLimit + "</RowLimit></View>";
                        do
                        {
                            ListItemCollection listItems = null;
                            camlQuery.ListItemCollectionPosition = position;
                            listItems = list.GetItems(camlQuery);
                            sContext.Load(listItems);
                            sContext.ExecuteQuery();

                            if (listItems.Count > 0)
                            {
                                Console.WriteLine("Working on this List:-{0}", LstName);
                                _logger.InfoFormat("Working on this List:-{0}", LstName);
                                foreach (var item in listItems)
                                {
                                    string fileurl = item.FieldValues["FileRef"].ToString();
                                    string fldname = item.FieldValues["FileLeafRef"].ToString();

                                    Folder folder = web.GetFolderByServerRelativeUrl(fileurl);

                                    sContext.Load(folder, fd => fd.ParentFolder.ServerRelativeUrl, fd => fd.ParentFolder.ListItemAllFields.HasUniqueRoleAssignments, fd => fd.ListItemAllFields.HasUniqueRoleAssignments, fd => fd.ListItemAllFields.RoleAssignments, fd => fd.ServerRelativeUrl);
                                    try
                                    {
                                        sContext.ExecuteQuery();
                                    }
                                    catch (Exception ex)
                                    {
                                        _logger.ErrorFormat("Error in Folder Level :{0},StackeTrace:{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
                                    }

                                    RoleAssignmentCollection roleAssCol = folder.ListItemAllFields.RoleAssignments;
                                    sContext.Load(roleAssCol);
                                    try
                                    {
                                        sContext.ExecuteQuery();
                                        if (folder.ListItemAllFields.HasUniqueRoleAssignments == true)
                                        {
                                            foreach (RoleAssignment roleAss in roleAssCol)
                                            {
                                                sContext.Load(roleAss, rl => rl.Member, rl => rl.RoleDefinitionBindings);
                                                try
                                                {
                                                    sContext.ExecuteQuery();
                                                }
                                                catch (Exception ex)
                                                {
                                                    _logger.ErrorFormat("Error in Folder Level :{0},StackeTrace:{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
                                                }

                                                //var user = sContext.Web.EnsureUser(roleAss.Member.LoginName);
                                                //sContext.Load(user);
                                                //sContext.ExecuteQuery();

                                                foreach (var roldef in roleAss.RoleDefinitionBindings)
                                                {
                                                    string roldefperm = roldef.Name.ToString();
                                                    DataRow row = dtsrc.NewRow();

                                                    row["SourceUrl"] = srcurl;
                                                    row["SrcLibraryName"] = LstName;
                                                    row["SrcFolderName"] = fldname;
                                                    row["FileRef"] = fileurl;

                                                    //if (!string.IsNullOrEmpty(user.Email.ToString()))
                                                    //{
                                                    //    row["User/Group"] = user.LoginName.ToString();
                                                    //}
                                                    if (roleAss.Member.LoginName.Contains("i:0#.w"))
                                                    {
                                                        //useremail = User.LoginName.ToString().Split('|')[1].ToString();
                                                        row["User/Group"] = roleAss.Member.LoginName.ToString().Split('|')[1].ToString();
                                                    }
                                                    else
                                                    {
                                                        row["User/Group"] = roleAss.Member.LoginName.ToString();
                                                    }
                                                    row["SrcPermissions"] = roldefperm.ToString();
                                                    row["HasUnique"] = folder.ListItemAllFields.HasUniqueRoleAssignments;
                                                    dtsrc.Rows.Add(row);
                                                }
                                            }
                                        }

                                    }
                                    catch (Exception ex)
                                    {
                                        //Console.WriteLine("Error in Folder Level :{0},StackeTrace:{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
                                        _logger.ErrorFormat("Error in Folder Level :{0},StackeTrace:{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
                                    }

                                }
                            }
                            position = listItems.ListItemCollectionPosition;
                        } while (position != null);

                    }
               // }


            }
            catch (Exception ex)
            {
                // Console.WriteLine("Error in Folder Level :{0},StackeTrace:{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
                _logger.ErrorFormat("Error in Folder Level :{0},StackeTrace:{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
            }
        }
        private void getFolderlevelPermissionTarget(string desurl, string LstName)
        {
            try
            {
                ClientContext tContext = objConnection.getdestContext(desurl);
                Web web = tContext.Web;
                tContext.Load(web);
                tContext.Load(web, wb => wb.ServerRelativeUrl, wb => wb.HasUniqueRoleAssignments);
                tContext.ExecuteQuery();
                //if (web.HasUniqueRoleAssignments == true)
                //{
                    List list = web.Lists.GetByTitle(LstName);
                    tContext.Load(list, l => l.RootFolder, l => l.ItemCount, l => l.RootFolder.Folders);
                    tContext.ExecuteQuery();
                    int rowLimit = 5000;
                    ListItemCollectionPosition position = null;
                    if (list != null && list.ItemCount > 0)
                    {
                        CamlQuery camlQuery = new CamlQuery();
                        camlQuery.ViewXml =
                            "<View Scope='RecursiveAll'>"
                          + "  <Query>"
                          + "    <Where>"
                          + "      <Eq><FieldRef Name='FSObjType' /><Value Type='Integer'>1</Value></Eq>"
                          + "    </Where>"
                          + "  </Query>"
                          + "  <ViewFields><FieldRef Name='Title' /></ViewFields>"
                          + "<RowLimit Paged='TRUE'>" + rowLimit + "</RowLimit></View>";
                        do
                        {
                            ListItemCollection listItems = null;
                            camlQuery.ListItemCollectionPosition = position;
                            listItems = list.GetItems(camlQuery);

                            tContext.Load(listItems);
                            tContext.ExecuteQuery();
                            if (listItems.Count > 0)
                            {
                                foreach (var item in listItems)
                                {
                                    string fileurl = item.FieldValues["FileRef"].ToString();
                                    string fldname = item.FieldValues["FileLeafRef"].ToString();

                                    Folder folder = web.GetFolderByServerRelativeUrl(fileurl);
                                    tContext.Load(folder, fd => fd.ParentFolder.ServerRelativeUrl, fd => fd.ParentFolder.ListItemAllFields.HasUniqueRoleAssignments, fd => fd.ListItemAllFields.HasUniqueRoleAssignments, fd => fd.ListItemAllFields.RoleAssignments, fd => fd.ServerRelativeUrl);
                                    try
                                    {
                                        tContext.ExecuteQuery();
                                    }
                                    catch (Exception ex)
                                    {
                                        // Console.WriteLine("Error in Folder Level :{0},StackeTrace:{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
                                        _logger.ErrorFormat("Error in Folder Level :{0},StackeTrace:{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
                                    }

                                    RoleAssignmentCollection roleAssCol = folder.ListItemAllFields.RoleAssignments;
                                    tContext.Load(roleAssCol);
                                    try
                                    {
                                        tContext.ExecuteQuery();
                                        if (folder.ListItemAllFields.HasUniqueRoleAssignments == true)
                                        {
                                            foreach (RoleAssignment roleAss in roleAssCol)
                                            {
                                                tContext.Load(roleAss, rl => rl.Member, rl => rl.RoleDefinitionBindings);
                                                try
                                                {
                                                    tContext.ExecuteQuery();
                                                }
                                                catch (Exception ex)
                                                {
                                                    // Console.WriteLine("Error in Folder Level :{0},StackeTrace:{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
                                                    _logger.ErrorFormat("Error in Folder Level :{0},StackeTrace:{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
                                                }
                                                //var useremail = tContext.Web.EnsureUser(roleAss.Member.LoginName);
                                                //tContext.Load(useremail);
                                                //tContext.ExecuteQuery();
                                                foreach (var roldef in roleAss.RoleDefinitionBindings)
                                                {
                                                    DataRow row = dtdes.NewRow();

                                                    row["TargetUrl"] = desurl;
                                                    row["DesLibraryName"] = LstName;
                                                    row["DesFolderName"] = fldname;
                                                    row["FileRef"] = fileurl;
                                                    //if (!string.IsNullOrEmpty(useremail.Email.ToString()))
                                                    //{
                                                    row["User/Group"] = roleAss.Member.LoginName;
                                                    //}

                                                    row["DesPermissions"] = roldef.Name.ToString();
                                                    row["HasUnique"] = folder.ListItemAllFields.HasUniqueRoleAssignments;
                                                    dtdes.Rows.Add(row);
                                                }
                                            }
                                        }

                                    }
                                    catch (Exception ex)
                                    {
                                        // Console.WriteLine("Error in Folder Level :{0},StackeTrace:{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
                                        _logger.ErrorFormat("Error in Folder Level :{0},StackeTrace:{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
                                    }

                                }
                            }
                            position = listItems.ListItemCollectionPosition;
                        } while (position != null);

                    }
               // }


            }
            catch (Exception ex)
            {
                //Console.WriteLine("Error in Folder Level :{0},StackeTrace:{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
                _logger.ErrorFormat("Error in Folder Level :{0},StackeTrace:{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
            }
        }
        private async Task<string> GetRestResult(string webUrl, HttpClientHandler handler)
        {
            string jsonData = string.Empty;
            using (var client = new HttpClient(handler))
            {
                client.Timeout = TimeSpan.FromSeconds(1000);
                client.DefaultRequestHeaders.Clear();
                client.DefaultRequestHeaders.Add("Accept", "application/json;odata=verbose");
                client.DefaultRequestHeaders.Add("ContentType", "application/json");

                HttpResponseMessage response = await client.GetAsync(webUrl).ConfigureAwait(false);

                response.EnsureSuccessStatusCode();
                jsonData = await response.Content.ReadAsStringAsync();
                return jsonData;
            }



        }

        private HttpClientHandler GetSPOClientHandler(string spSiteUrl, UtliClass utli)
        {
            var credential = new SharePointOnlineCredentials(utli.SPOuserName, utli.SPOpassword);
            HttpClientHandler handler = new HttpClientHandler() { Credentials = credential };
            //Getting authentication cookies
            Uri uri = new Uri(spSiteUrl);
            handler.CookieContainer.SetCookies(uri, credential.GetAuthenticationCookie(uri));
            return handler;
        }
    }


}

