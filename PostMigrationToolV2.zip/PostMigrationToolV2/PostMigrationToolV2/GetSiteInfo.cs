﻿using FD.SPOMigration.PostMigReport.DocumentComparison;
using FD.SPOMigration.PostMigReport.SiteFeatureComparer;
using Microsoft.SharePoint.Client;
using Microsoft.SharePoint.Client.WebParts;
using Microsoft.SharePoint.Client.Workflow;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.IO;
using System.Linq;


namespace PostMigrationToolV2
{
    public class GetSiteInfo
    {

        private static readonly log4net.ILog _logger = log4net.LogManager.GetLogger(typeof(Program));
        ExporttoExcel objExporttoExcel = new ExporttoExcel();
        Connection objConnection = new Connection();
        DataTable dtcnTypeSum = new DataTable();
        DataTable dtWrflCmp = new DataTable();
        DataTable dtsrwebpart = new DataTable();
        DataTable dtdescWebpart = new DataTable();
        DataTable dtwebpartSum = new DataTable();

        DataTable dtsrcgrps = new DataTable();
        DataTable dtdesgrps = new DataTable();
        DataTable dtgrpssum = new DataTable();
        DataTable dtgrpsMissing = new DataTable();

        DataTable dtsrcuser = new DataTable();
        DataTable dtdesuser = new DataTable();
        DataTable dtuserssum = new DataTable();

        DataTable dtFeatResult = new DataTable();
        DataTable dtDocResult = new DataTable();

        DataTable dtsiteUserssrc = new DataTable();
        DataTable dtsiteUsersdes = new DataTable();
        DataTable dtsiteUserssum = new DataTable();



        #region
        public void getWrkflwsrc(string srcUrl, DataTable dtwrkflwsrc,bool IsrootSite)
        {

            ClientContext ctx = new ClientContext(srcUrl);
            Web oWebsite = ctx.Web;
            ctx.Load(oWebsite, website => website.Url, website => website.Webs, website => website.Title);
            try
            {
                ListCollection lc = oWebsite.Lists;
                ctx.Load(lc);
                ctx.ExecuteQuery();

                Console.WriteLine("Current Site Url:-{0}", oWebsite.Url.ToString());
                _logger.InfoFormat("Current Site Url:-{0}", oWebsite.Url.ToString());
                foreach (List list in lc)
                {
                    try
                    {
                        if (!(list.Hidden))
                        {


                            ctx.Load(list, l => l.Title, l => l.BaseTemplate, l => l.BaseType, l => l.DocumentTemplateUrl, l => l.HasUniqueRoleAssignments);
                            ctx.ExecuteQuery();

                            WorkflowAssociationCollection wfac = list.WorkflowAssociations;
                            ctx.Load(wfac);
                            ctx.ExecuteQuery();
                            foreach (WorkflowAssociation wfa in wfac)
                            {

                                ctx.Load(wfa, w => w.Id, w => w.Name, w => w.ListId);
                                ctx.ExecuteQuery();

                                if (!wfa.Name.Contains("Previous Version"))
                                {
                                    DataRow row = dtwrkflwsrc.NewRow();
                                    row["SiteUrl"] = srcUrl;
                                    row["ListName"] = list.Title;
                                    row["WorkflowName"] = wfa.Name;
                                    row["WrkflwID"] = wfa.Id;
                                    dtwrkflwsrc.Rows.Add(row);
                                }

                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine("Error in Workflow:{0},StackeTrace:{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
                        _logger.ErrorFormat("Error in Workflow:{0},StackeTrace:{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.ErrorFormat("Error in Workflow:{0},Site Url:{1}", ex.Message.ToString(), srcUrl);
                Console.WriteLine("Error in Workflow:{0},StackeTrace:{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());

            }
            if (IsrootSite==false)
            {
                foreach (Web orWebsite in oWebsite.Webs)
                {

                    if (!string.IsNullOrEmpty(orWebsite.Url.ToString()))
                    {
                        //ctx = new ClientContext(orWebsite.Url);
                        //Web subWebsite = ctx.Web;
                        //ctx.Load(subWebsite, website => website.HasUniqueRoleAssignments, website => website.Url, website => website.Webs, website => website.Title);
                        //ctx.ExecuteQuery();
                        //if (subWebsite.HasUniqueRoleAssignments == true)
                        //{
                        getWrkflwsrc(orWebsite.Url, dtwrkflwsrc, IsrootSite);
                        //}

                    }

                }
            }
          



        }

        public void getWrkflwDes(string srcUrl, DataTable dtwrkflwDes,bool IsrootSite)
        {

            ClientContext ctx = objConnection.getdestContext(srcUrl);
            Web oWebsite = ctx.Web;
            ctx.Load(oWebsite, website => website.Url, website => website.Webs, website => website.Title);
            try
            {
                ListCollection lc = oWebsite.Lists;
                ctx.Load(lc);
                ctx.ExecuteQuery();

                Console.WriteLine("Current Site Url:-{0}", oWebsite.Url.ToString());
                _logger.InfoFormat("Current Site Url:-{0}", oWebsite.Url.ToString());
                foreach (List list in lc)
                {
                    try
                    {
                        if (!(list.Hidden))
                        {


                            ctx.Load(list, l => l.Title, l => l.BaseTemplate, l => l.BaseType, l => l.DocumentTemplateUrl, l => l.HasUniqueRoleAssignments);
                            ctx.ExecuteQuery();

                            WorkflowAssociationCollection wfac = list.WorkflowAssociations;
                            ctx.Load(wfac);
                            ctx.ExecuteQuery();
                            foreach (WorkflowAssociation wfa in wfac)
                            {

                                ctx.Load(wfa, w => w.Id, w => w.Name, w => w.ListId);
                                ctx.ExecuteQuery();
                                if (!wfa.Name.Contains("Previous Version"))
                                {
                                    DataRow row = dtwrkflwDes.NewRow();
                                    row["SiteUrl"] = srcUrl;
                                    row["ListName"] = list.Title;
                                    row["WorkflowName"] = wfa.Name;
                                    row["WrkflwID"] = wfa.Id;
                                    dtwrkflwDes.Rows.Add(row);

                                }


                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine("Error in Workflow:{0},StackeTrace:{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
                        _logger.ErrorFormat("Error in Workflow:{0},StackeTrace:{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error in Workflow:{0},StackeTrace:{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
                _logger.ErrorFormat("Error in Workflow:{0},Site Url:{1}", ex.Message.ToString().ToString(), srcUrl);

            }
            if (IsrootSite==false)
            {
                foreach (Web orWebsite in oWebsite.Webs)
                {

                    if (!string.IsNullOrEmpty(orWebsite.Url.ToString()))
                    {
                        //ctx = objConnection.getdestContext(orWebsite.Url);
                        //Web subWebsite = ctx.Web;
                        //ctx.Load(subWebsite, website => website.HasUniqueRoleAssignments, website => website.Url, website => website.Webs, website => website.Title);
                        //ctx.ExecuteQuery();
                        //if (subWebsite.HasUniqueRoleAssignments == true)
                        //{
                        getWrkflwDes(orWebsite.Url, dtwrkflwDes, IsrootSite);
                        //}

                    }

                }

            }
           

        }

        public DataTable CompareWrkflw(DataTable dtsrc, DataTable dtdes)
        {
            DataTable dtMisMatchSource = new DataTable();
            DataTable dtMisMatchTarget = new DataTable();
            try
            {
                var qry1 = dtsrc.AsEnumerable().Select(a => new { cntType = a["WorkflowName"].ToString() });
                var qry2 = dtdes.AsEnumerable().Select(b => new { cntType = b["WorkflowName"].ToString() });

                try
                {
                    var exceptSource = qry2.Except(qry1);
                    dtMisMatchSource = new DataTable();
                    dtMisMatchSource = (from a in dtdes.AsEnumerable()
                                        join ab in exceptSource on a["WorkflowName"].ToString() equals ab.cntType
                                        select a).CopyToDataTable();
                }
                catch (Exception ex)
                {
                    // _logger.ErrorFormat("Error Message: {0}", ex.Message.ToString());
                }

                try
                {
                    var exceptdes = qry1.Except(qry2);
                    dtMisMatchTarget = new DataTable();
                    dtMisMatchTarget = (from a in dtsrc.AsEnumerable()
                                        join ab in exceptdes on a["WorkflowName"].ToString() equals ab.cntType
                                        select a).CopyToDataTable();
                }
                catch (Exception ex)
                {
                    // _logger.ErrorFormat("Error Message: {0}", ex.Message.ToString());

                }



                dtcnTypeSum = new DataTable();
                dtcnTypeSum.Columns.Add("SourceUrl", typeof(string));
                dtcnTypeSum.Columns.Add("SrclistName", typeof(string));
                dtcnTypeSum.Columns.Add("SrcWrkflwName", typeof(string));
                dtcnTypeSum.Columns.Add("DesSiteUrl", typeof(string));
                dtcnTypeSum.Columns.Add("DeslistName", typeof(string));
                dtcnTypeSum.Columns.Add("DesWrkflwName", typeof(string));
                if (dtMisMatchTarget.Rows.Count > 0)
                {

                    for (int i = 0; i < dtMisMatchTarget.Rows.Count; i++)
                    {
                        DataRow row = dtcnTypeSum.NewRow();

                        row["SourceUrl"] = dtMisMatchTarget.Rows[i]["SiteUrl"];
                        row["SrclistName"] = dtMisMatchTarget.Rows[i]["ListName"];
                        row["SrcWrkflwName"] = dtMisMatchTarget.Rows[i]["WorkflowName"];


                        dtcnTypeSum.Rows.Add(row);
                    }
                }

                if (dtMisMatchSource.Rows.Count > 0)
                {
                    for (int i = 0; i < dtMisMatchSource.Rows.Count; i++)
                    {
                        DataRow row = dtcnTypeSum.NewRow();
                        row["DesSiteUrl"] = dtMisMatchSource.Rows[i]["SiteUrl"];
                        row["DeslistName"] = dtMisMatchSource.Rows[i]["ListName"];
                        row["DesWrkflwName"] = dtMisMatchSource.Rows[i]["WorkflowName"];
                        dtcnTypeSum.Rows.Add(row);
                    }
                }


            }
            catch (Exception ex)
            {
                Console.WriteLine("Error in Workflow:{0},StackeTrace:{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
                _logger.ErrorFormat("Error in Workflow:{0},Method Name:{2}{1}", ex.Message.ToString(), ex.TargetSite.ToString());
            }
            return dtcnTypeSum;
        }
        #endregion


        /// <summary>
        /// get webpart details
        /// </summary>
        /// <param name="srcUrl"></param>
        public void getsrcwebpart(string srcUrl, DataTable dtsrwebpart,bool IsrootSite)
        {
            ClientContext clientContext = new ClientContext(srcUrl);
            Web web = clientContext.Web;
            clientContext.Load(web, wb => wb.Webs, wb => wb.Title, wb => wb.Url, wb => wb.AllProperties, wb => wb.RootFolder.WelcomePage, wb => wb.ServerRelativeUrl);
            ListCollection lists = web.Lists;
            clientContext.Load(lists);
            clientContext.Load(lists, list => list.Include(l => l.DefaultViewUrl));
            try
            {
                clientContext.ExecuteQuery();
            }
            catch (Exception ex)
            {

                Console.WriteLine("Error in webpart:{0},StackeTrace:{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
                _logger.ErrorFormat("Error in webpart:{0},StackeTrace:{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
            }

            Console.WriteLine("Current Site Url:-{0}", web.Url.ToString());
            _logger.InfoFormat("Current Site Url:-{0}", web.Url.ToString());
            string pageUrl = web.RootFolder.WelcomePage;
            if (string.IsNullOrEmpty(pageUrl))
            {
                pageUrl = "default.aspx";
                // pageUrl = web.ServerRelativeUrl + "/" + pageUrl;
            }

            if (!pageUrl.Contains("Pages"))
            {
                if (pageUrl.StartsWith(@"/"))
                {
                    pageUrl = pageUrl.TrimStart(new char[] { '/' });
                }
                if (web.ServerRelativeUrl.EndsWith(@"/"))
                {
                    pageUrl = web.ServerRelativeUrl + pageUrl;
                }
                else
                {
                    pageUrl = web.ServerRelativeUrl + "/" + pageUrl;
                }
                Microsoft.SharePoint.Client.File oFiles = clientContext.Web.GetFileByServerRelativeUrl(pageUrl);
                LimitedWebPartManager limitedWebPartManager = oFiles.GetLimitedWebPartManager(PersonalizationScope.Shared);
                WebPartDefinitionCollection webpart = limitedWebPartManager.WebParts;
                clientContext.Load(webpart);
                try
                {
                    clientContext.ExecuteQuery();
                    foreach (WebPartDefinition webPartDefinition in webpart)
                    {
                        WebPart webPart = webPartDefinition.WebPart;

                        clientContext.Load(webPart, wp => wp.IsClosed, wp => wp.ZoneIndex, wp => wp.Properties, wp => wp.Title, wp => wp.Subtitle, wp => wp.TitleUrl);
                        try
                        {
                            clientContext.ExecuteQuery();
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine("Error in webpart:{0},StackeTrace:{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
                            _logger.ErrorFormat("Error in webpart:{0},StackeTrace:{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
                        }

                        if (webPart.IsClosed == false)
                        {

                            if (!string.IsNullOrEmpty(webPart.Title))
                            {
                                DataRow row = dtsrwebpart.NewRow();
                                row["SourceUrl"] = srcUrl;
                                row["srcWebpartName"] = webPart.Title;
                                row["WebpartUrl"] = pageUrl;
                                row["WebpartIsClosed"] = webPart.IsClosed;

                                dtsrwebpart.Rows.Add(row);

                            }
                        }


                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error in webpart:{0},StackeTrace:{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
                    _logger.ErrorFormat("Error in webpart:{0},StackeTrace:{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());

                }
            }


            var webPartLsts = from list in lists.AsEnumerable()
                              where list.DefaultViewUrl.Contains("Pages")
                              select list;
            foreach (Microsoft.SharePoint.Client.List webPartLst in webPartLsts)
            {
                clientContext.ExecuteQuery();
                if (webPartLst != null)
                {
                    string webparttitle = webPartLst.Title.ToString();
                    CamlQuery camlQuery = new CamlQuery();
                    camlQuery.ViewXml = "<View><RowLimit></RowLimit></View>";
                    ListItemCollection collListItem = webPartLst.GetItems(camlQuery);
                    clientContext.Load(collListItem);
                    try
                    {
                        clientContext.ExecuteQuery();

                        foreach (ListItem item in collListItem)
                        {
                            string serverRelativeCurrentPageUrl = item["FileRef"].ToString();
                            if (serverRelativeCurrentPageUrl.EndsWith(".aspx"))
                            {
                                Microsoft.SharePoint.Client.File oFile = clientContext.Web.GetFileByServerRelativeUrl(serverRelativeCurrentPageUrl);
                                LimitedWebPartManager limitedWebPartManager = oFile.GetLimitedWebPartManager(PersonalizationScope.Shared);
                                WebPartDefinitionCollection wps = limitedWebPartManager.WebParts;
                                clientContext.Load(wps);
                                try
                                {
                                    clientContext.ExecuteQuery();
                                }
                                catch (Exception ex)
                                {
                                    Console.WriteLine("Error in webpart:{0},StackeTrace:{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
                                    _logger.ErrorFormat("Error in webpart:{0},StackeTrace:{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
                                }

                                foreach (WebPartDefinition webPartDefinition in wps)
                                {
                                    WebPart webPart = webPartDefinition.WebPart;

                                    clientContext.Load(webPart, wp => wp.IsClosed, wp => wp.ZoneIndex, wp => wp.Properties, wp => wp.Title, wp => wp.Subtitle, wp => wp.TitleUrl);
                                    try
                                    {
                                        clientContext.ExecuteQuery();
                                    }
                                    catch (Exception ex)
                                    {
                                        Console.WriteLine("Error in webpart:{0},StackeTrace:{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
                                        _logger.ErrorFormat("Error in webpart:-{0},StackeTrace:-{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
                                    }

                                    if (webPart.IsClosed == false)
                                    {
                                        if (!string.IsNullOrEmpty(webPart.Title))
                                        {
                                            DataRow row = dtsrwebpart.NewRow();
                                            row["SourceUrl"] = srcUrl;
                                            row["srcWebpartName"] = webPart.Title;
                                            row["WebpartUrl"] = serverRelativeCurrentPageUrl;
                                            row["WebpartIsClosed"] = webPart.IsClosed;
                                            dtsrwebpart.Rows.Add(row);

                                        }
                                    }


                                }
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine("Error in webpart:{0},StackeTrace:{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
                        _logger.ErrorFormat("Error in webpart:{0},StackeTrace:{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
                    }

                   
                }
            }
            if (IsrootSite==false)
            {
                foreach (Web orWebsite in web.Webs)
                {

                    if (!string.IsNullOrEmpty(orWebsite.Url.ToString()))
                    {
                        clientContext = new ClientContext(orWebsite.Url);

                        Web subWebsite = clientContext.Web;
                        clientContext.Load(subWebsite, website => website.HasUniqueRoleAssignments, website => website.Url, website => website.Webs, website => website.Title);
                        clientContext.ExecuteQuery();
                        getsrcwebpart(orWebsite.Url, dtsrwebpart, IsrootSite);

                    }
                }
            }
           

        }
        public void getdeswebpart(string srcUrl, DataTable dtdescWebpart,bool IsrootSite)
        {

            ClientContext clientContext = objConnection.getdestContext(srcUrl);
            Web web = clientContext.Web;
            clientContext.Load(web, wb => wb.Webs, wb => wb.Title, wb => wb.Url, wb => wb.AllProperties, wb => wb.RootFolder.WelcomePage, wb => wb.ServerRelativeUrl);
            ListCollection lists = web.Lists;
            clientContext.Load(lists);
            clientContext.Load(lists, list => list.Include(l => l.DefaultViewUrl));
            try
            {
                clientContext.ExecuteQuery();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error in webpart:-{0},StackeTrace:-{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
                _logger.ErrorFormat("Error in webpart:-{0},StackeTrace:-{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
            }

            Console.WriteLine("Current Site Url:-{0}", web.Url.ToString());
            _logger.InfoFormat("Current Site Url:-{0}", web.Url.ToString());
            string pageUrl = web.RootFolder.WelcomePage;
            if (string.IsNullOrEmpty(pageUrl))
            {
                pageUrl = "default.aspx";
                // pageUrl = web.ServerRelativeUrl + "/" + pageUrl;
            }
            //if (pageUrl.Contains("default"))
            //{
            //    pageUrl = web.ServerRelativeUrl + "/" + pageUrl;
            //}

            if (!pageUrl.Contains("Pages"))
            {
                if (pageUrl.StartsWith(@"/"))
                {
                    pageUrl = pageUrl.TrimStart(new char[] { '/' });
                }
                if (web.ServerRelativeUrl.EndsWith(@"/"))
                {
                    pageUrl = web.ServerRelativeUrl + pageUrl;
                }
                else
                {
                    pageUrl = web.ServerRelativeUrl + "/" + pageUrl;
                }
                Microsoft.SharePoint.Client.File oFiles = clientContext.Web.GetFileByServerRelativeUrl(pageUrl);
                LimitedWebPartManager limitedWebPartManager = oFiles.GetLimitedWebPartManager(PersonalizationScope.Shared);
                WebPartDefinitionCollection webpart = limitedWebPartManager.WebParts;
                clientContext.Load(webpart);
                try
                {
                    clientContext.ExecuteQuery();
                    foreach (WebPartDefinition webPartDefinition in webpart)
                    {
                        WebPart webPart = webPartDefinition.WebPart;

                        clientContext.Load(webPart, wp => wp.IsClosed, wp => wp.ZoneIndex, wp => wp.Properties, wp => wp.Title, wp => wp.Subtitle, wp => wp.TitleUrl);
                        try
                        {
                            clientContext.ExecuteQuery();
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine("Error in webpart:-{0},StackeTrace:-{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
                            _logger.ErrorFormat("Error in webpart:-{0},StackeTrace:-{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
                        }
                        if (webPart.IsClosed == false)
                        {
                            if (!string.IsNullOrEmpty(webPart.Title))
                            {
                                DataRow row = dtdescWebpart.NewRow();
                                row["TargeteUrl"] = srcUrl;
                                row["desWebpartName"] = webPart.Title;
                                row["WebpartUrl"] = pageUrl;
                                row["WebpartIsClosed"] = webPart.IsClosed;
                                dtdescWebpart.Rows.Add(row);

                            }
                        }

                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error in webpart:-{0},StackeTrace:-{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
                    _logger.ErrorFormat("Error in webpart:-{0},StackeTrace:-{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
                }
            }

            var webPartLsts = from list in lists.AsEnumerable()
                              where list.DefaultViewUrl.Contains("Pages")
                              select list;
            foreach (Microsoft.SharePoint.Client.List webPartLst in webPartLsts)
            {

                clientContext.ExecuteQuery();
                if (webPartLst != null)
                {
                    ListItemCollectionPosition position = null;
                    int rowLimit = 5000;
                    string webparttitle = webPartLst.Title.ToString();
                    CamlQuery camlQuery = new CamlQuery();
                    //camlQuery.ViewXml = "<View><RowLimit></RowLimit></View>";
                    camlQuery.ViewXml = @"<View Scope='RecursiveAll'>
                    <Query>
                        <OrderBy Override='TRUE'><FieldRef Name='ID'/></OrderBy>
                    </Query>
                    <RowLimit Paged='TRUE'>" + rowLimit + "</RowLimit></View>";
                    do
                    {
                        ListItemCollection collListItem = null;
                        camlQuery.ListItemCollectionPosition = position;
                        collListItem = webPartLst.GetItems(camlQuery);
                        clientContext.Load(collListItem);
                        try
                        {
                            clientContext.ExecuteQuery();
                            foreach (ListItem item in collListItem)
                            {
                                string serverRelativeCurrentPageUrl = item["FileRef"].ToString();
                                if (serverRelativeCurrentPageUrl.EndsWith(".aspx"))
                                {
                                    Microsoft.SharePoint.Client.File oFile = clientContext.Web.GetFileByServerRelativeUrl(serverRelativeCurrentPageUrl);
                                    LimitedWebPartManager limitedWebPartManager = oFile.GetLimitedWebPartManager(PersonalizationScope.Shared);
                                    WebPartDefinitionCollection wps = limitedWebPartManager.WebParts;
                                    clientContext.Load(wps);
                                    try
                                    {
                                        clientContext.ExecuteQuery();
                                    }
                                    catch (Exception ex)
                                    {
                                        Console.WriteLine("Error in webpart:-{0},StackeTrace:-{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
                                        _logger.ErrorFormat("Error in webpart:-{0},StackeTrace:-{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
                                    }

                                    foreach (WebPartDefinition webPartDefinition in wps)
                                    {
                                        WebPart webPart = webPartDefinition.WebPart;

                                        clientContext.Load(webPart, wp => wp.IsClosed, wp => wp.ZoneIndex, wp => wp.Properties, wp => wp.Title, wp => wp.Subtitle, wp => wp.TitleUrl);
                                        try
                                        {
                                            clientContext.ExecuteQuery();
                                        }
                                        catch (Exception ex)
                                        {
                                            Console.WriteLine("Error in webpart:-{0},StackeTrace:-{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
                                            _logger.ErrorFormat("Error in webpart:-{0},StackeTrace:-{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
                                        }
                                        if (webPart.IsClosed == false)
                                        {
                                            if (!string.IsNullOrEmpty(webPart.Title))
                                            {

                                                //DataRow row = dtsrwebpart.NewRow();
                                                //row["SourceUrl"] = srcUrl;
                                                //row["srcWebpartName"] = webPart.Title;
                                                //row["WebpartUrl"] = serverRelativeCurrentPageUrl;
                                                //row["WebpartIsClosed"] = webPart.IsClosed;
                                                //dtsrwebpart.Rows.Add(row);

                                                DataRow row = dtdescWebpart.NewRow();
                                                row["TargeteUrl"] = srcUrl;
                                                row["desWebpartName"] = webPart.Title;
                                                row["WebpartUrl"] = serverRelativeCurrentPageUrl;
                                                row["WebpartIsClosed"] = webPart.IsClosed;
                                                dtdescWebpart.Rows.Add(row);

                                            }
                                        }


                                    }
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine("Error in webpart:-{0},StackeTrace:-{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
                            _logger.ErrorFormat("Error in webpart:-{0},StackeTrace:-{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
                        }
                        position = collListItem.ListItemCollectionPosition;
                    } while (position != null);
                }
            }
            #region
            //foreach (Microsoft.SharePoint.Client.List webPartLst in webPartLsts)
            //{

            //    clientContext.ExecuteQuery();
            //    if (webPartLst != null)
            //    {
            //        ListItemCollectionPosition position = null;
            //        int rowLimit = 5000;
            //        string webparttitle = webPartLst.Title.ToString();
            //        CamlQuery camlQuery = new CamlQuery();
            //        //camlQuery.ViewXml = "<View><RowLimit></RowLimit></View>";
            //        camlQuery.ViewXml = @"<View Scope='RecursiveAll'>
            //        <Query>
            //            <OrderBy Override='TRUE'><FieldRef Name='ID'/></OrderBy>
            //        </Query>
            //        <RowLimit Paged='TRUE'>" + rowLimit + "</RowLimit></View>";
            //        do
            //        {
            //            ListItemCollection collListItem = null;
            //            camlQuery.ListItemCollectionPosition = position;
            //            collListItem = webPartLst.GetItems(camlQuery);
            //            clientContext.Load(collListItem);
            //            try
            //            {
            //                clientContext.ExecuteQuery();
            //                foreach (ListItem item in collListItem)
            //                {
            //                    string serverRelativeCurrentPageUrl = item["FileRef"].ToString();
            //                    if (serverRelativeCurrentPageUrl.EndsWith(".aspx"))
            //                    {
            //                        Microsoft.SharePoint.Client.File oFile = clientContext.Web.GetFileByServerRelativeUrl(serverRelativeCurrentPageUrl);
            //                        LimitedWebPartManager limitedWebPartManager = oFile.GetLimitedWebPartManager(PersonalizationScope.Shared);
            //                        WebPartDefinitionCollection wps = limitedWebPartManager.WebParts;
            //                        clientContext.Load(wps);
            //                        try
            //                        {
            //                            clientContext.ExecuteQuery();
            //                        }
            //                        catch (Exception ex)
            //                        {
            //                            Console.WriteLine("Error in webpart:-{0},StackeTrace:-{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
            //                            _logger.ErrorFormat("Error in webpart:-{0},StackeTrace:-{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
            //                        }

            //                        foreach (WebPartDefinition webPartDefinition in wps)
            //                        {
            //                            WebPart webPart = webPartDefinition.WebPart;

            //                            clientContext.Load(webPart, wp => wp.IsClosed, wp => wp.ZoneIndex, wp => wp.Properties, wp => wp.Title, wp => wp.Subtitle, wp => wp.TitleUrl);
            //                            try
            //                            {
            //                                clientContext.ExecuteQuery();
            //                            }
            //                            catch (Exception ex)
            //                            {
            //                                Console.WriteLine("Error in webpart:-{0},StackeTrace:-{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
            //                                _logger.ErrorFormat("Error in webpart:-{0},StackeTrace:-{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
            //                            }
            //                            if (webPart.IsClosed == false)
            //                            {
            //                                if (!string.IsNullOrEmpty(webPart.Title))
            //                                {
            //                                    DataRow row = dtdescWebpart.NewRow();
            //                                    row["TargeteUrl"] = srcUrl;
            //                                    row["desWebpartName"] = webPart.Title;
            //                                    row["WebpartUrl"] = serverRelativeCurrentPageUrl;
            //                                    row["WebpartIsClosed"] = webPart.IsClosed;
            //                                    dtdescWebpart.Rows.Add(row);

            //                                }
            //                            }


            //                        }
            //                    }
            //                }
            //            }
            //            catch (Exception ex)
            //            {
            //                Console.WriteLine("Error in webpart:-{0},StackeTrace:-{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
            //                _logger.ErrorFormat("Error in webpart:-{0},StackeTrace:-{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
            //            }
            //            position = collListItem.ListItemCollectionPosition;
            //        } while (position != null);
            //    }
            //}
            #endregion
            if (IsrootSite==false)
            {
                foreach (Web orWebsite in web.Webs)
                {
                    if (!string.IsNullOrEmpty(orWebsite.Url.ToString()))
                    {
                        clientContext = objConnection.getdestContext(orWebsite.Url);
                        Web subWebsite = clientContext.Web;
                        clientContext.Load(subWebsite, website => website.HasUniqueRoleAssignments, website => website.Url, website => website.Webs, website => website.Title);
                        clientContext.ExecuteQuery();
                        getdeswebpart(orWebsite.Url, dtdescWebpart, IsrootSite);

                    }

                }
            }
           

            // CompareWeparts();
            //objExporttoExcel.CreateExcelDocumentFormatingWebparts(dtsrwebpart, dtdescWebpart, dtwebpartSum, filepath);
        }
        public DataTable CompareWeparts(DataTable dtsrwebpart, DataTable dtdescWebpart)
        {
            DataTable dtMisMatchSource = new DataTable();
            DataTable dtMisMatchTarget = new DataTable();
            try
            {
                var qry1 = dtsrwebpart.AsEnumerable().Select(a => new { webpart = a["srcWebpartName"].ToString() });
                var qry2 = dtdescWebpart.AsEnumerable().Select(b => new { webpart = b["desWebpartName"].ToString() });

                try
                {
                    var exceptSource = qry2.Except(qry1);
                    dtMisMatchSource = new DataTable();
                    dtMisMatchSource = (from a in dtdescWebpart.AsEnumerable()
                                        join ab in exceptSource on a["desWebpartName"].ToString() equals ab.webpart
                                        select a).CopyToDataTable();
                }
                catch (Exception ex)
                {
                    //  _logger.ErrorFormat("Error Message: {0}", ex.Message.ToString());
                }

                try
                {
                    var exceptdes = qry1.Except(qry2);
                    dtMisMatchTarget = new DataTable();
                    dtMisMatchTarget = (from a in dtsrwebpart.AsEnumerable()
                                        join ab in exceptdes on a["srcWebpartName"].ToString() equals ab.webpart
                                        select a).CopyToDataTable();
                }
                catch (Exception ex)
                {
                    //  _logger.ErrorFormat("Error Message: {0}", ex.Message.ToString());
                }



                dtwebpartSum = new DataTable();


                dtwebpartSum.Columns.Add("SourceUrl", typeof(string));
                dtwebpartSum.Columns.Add("srcWebpartName", typeof(string));
                dtwebpartSum.Columns.Add("WebpartUrl", typeof(string));
                dtwebpartSum.Columns.Add("TargeteUrl", typeof(string));
                dtwebpartSum.Columns.Add("desWebpartName", typeof(string));
                dtwebpartSum.Columns.Add("TargetWebpartUrl", typeof(string));


                if (dtMisMatchTarget.Rows.Count > 0)
                {

                    for (int i = 0; i < dtMisMatchTarget.Rows.Count; i++)
                    {
                        DataRow row = dtwebpartSum.NewRow();

                        row["SourceUrl"] = dtMisMatchTarget.Rows[i]["SourceUrl"];
                        row["srcWebpartName"] = dtMisMatchTarget.Rows[i]["srcWebpartName"];
                        row["WebpartUrl"] = dtMisMatchTarget.Rows[i]["WebpartUrl"];
                        dtwebpartSum.Rows.Add(row);
                    }
                }

                if (dtMisMatchSource.Rows.Count > 0)
                {
                    for (int i = 0; i < dtMisMatchSource.Rows.Count; i++)
                    {
                        DataRow row = dtwebpartSum.NewRow();
                        row["TargeteUrl"] = dtMisMatchSource.Rows[i]["TargeteUrl"];
                        row["desWebpartName"] = dtMisMatchSource.Rows[i]["desWebpartName"];
                        row["TargetWebpartUrl"] = dtMisMatchSource.Rows[i]["WebpartUrl"];
                        dtwebpartSum.Rows.Add(row);
                    }
                }


            }
            catch (Exception ex)
            {
                Console.WriteLine("Error in webpart:-{0},StackeTrace:-{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
                _logger.ErrorFormat("Error Message: {0}", ex.Message.ToString());
            }
            return dtwebpartSum;
        }
        public void Listassociatedcontenttype(string siteURL, DataTable dtListCtype, DataTable dtsrcList,bool IsrootSite)
        {


            string ListName = string.Empty;
            string CnType = string.Empty;

            try
            {
                Console.WriteLine("\n");
                Console.WriteLine("Site Url:{0}", siteURL);
                ClientContext clientContext = new ClientContext(siteURL);
                Web oWebsite = clientContext.Web;
                clientContext.Load(oWebsite, web => web.Webs, Web => Web.Title, web => web.ServerRelativeUrl);

                ListCollection lists = clientContext.Web.Lists;
                clientContext.Load(lists);
                clientContext.Load(lists, list => list.Include(l => l.DefaultViewUrl));
                try
                {
                    clientContext.ExecuteQuery();
                }
                catch (Exception ex)
                {
                    _logger.ErrorFormat("Error getListInfo :{0},StackeTrace:{1},Method Name:-", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
                    Console.WriteLine("Error getListInfo :{0},StackeTrace:{1},Method Name:-", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
                }
                foreach (List list in lists)
                {

                    if (!(list.Hidden))
                    {
                        ContentTypeCollection contentTypeColl = clientContext.Web.Lists.GetByTitle(list.Title).ContentTypes;
                        clientContext.Load(contentTypeColl);
                        clientContext.ExecuteQuery();
                        if (list.ContentTypesEnabled == true)
                        {
                            foreach (ContentType ct in contentTypeColl)
                            {
                                if (ct.Name != "Folder")
                                {


                                    ListName = list.Title;
                                    CnType = ct.Name;

                                    FieldCollection fieldColl = ct.Fields;
                                    clientContext.Load(fieldColl);
                                    clientContext.ExecuteQuery();
                                    Console.WriteLine("List Name & Content Types :{0},{1}", ListName, CnType);
                                    foreach (Field field in fieldColl)
                                    {
                                        if (field.Hidden == false)
                                        {
                                            DataRow row = dtListCtype.NewRow();
                                            row["SiteUrl"] = siteURL;
                                            row["ListName"] = ListName;
                                            row["ContentTypeName"] = CnType;
                                            row["FieldName"] = field.Title;
                                            dtListCtype.Rows.Add(row);
                                        }

                                    }




                                }
                            }
                        }

                    }
                    FieldCollection fieldCollection = list.Fields;
                    clientContext.Load(fieldCollection);
                    clientContext.ExecuteQuery();

                    //Printing Column Names
                    foreach (Field field in fieldCollection)
                    {

                        IEnumerable<DataRow> largeProducts = dtListCtype.AsEnumerable().Where(p => p.Field<string>("FieldName") == field.Title.ToString());
                        foreach (DataRow dr in largeProducts)
                        {
                            DataRow row = dtsrcList.NewRow();
                            row["SiteUrl"] = siteURL;
                            row["ListName"] = list.Title;
                            row["ContentTypeName"] = dr.Field<string>("ContentTypeName");
                            row["FieldName"] = dr.Field<string>("FieldName");
                            dtsrcList.Rows.Add(row);


                        }

                    }
                }
                if (IsrootSite==false)
                {
                    foreach (Web orWebsite in oWebsite.Webs)
                    {

                        if (!string.IsNullOrEmpty(orWebsite.Url.ToString()))
                        {
                            Listassociatedcontenttype(orWebsite.Url.Trim(), dtListCtype, dtsrcList, IsrootSite);
                        }
                    }
                }
               
            }
            catch (Exception ex)
            {

                _logger.ErrorFormat("Error getListInfo :{0},StackeTrace:{1},Method Name:-", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
                Console.WriteLine("Error getListInfo :{0},StackeTrace:{1},Method Name:-", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
            }

        }
        public void ListassociatedcontenttypeDes(string siteURL, DataTable dtListCtype, DataTable dtdesList,bool IsrootSite)
        {
            string ListName = string.Empty;
            string CnType = string.Empty;

            try
            {
                Console.WriteLine("\n");
                Console.WriteLine("Site Url:{0}", siteURL);
                ClientContext clientContext = objConnection.getdestContext(siteURL);
                Web oWebsite = clientContext.Web;
                clientContext.Load(oWebsite, web => web.Webs, Web => Web.Title);
                ListCollection lists = clientContext.Web.Lists;
                clientContext.Load(lists);
                clientContext.Load(lists, list => list.Include(l => l.DefaultViewUrl));
                try
                {
                    clientContext.ExecuteQuery();
                }
                catch (Exception ex)
                {
                    _logger.ErrorFormat("Error getListInfo :{0},StackeTrace:{1},Method Name:-", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
                    Console.WriteLine("Error getListInfo :{0},StackeTrace:{1},Method Name:-", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
                }
                foreach (List list in lists)
                {

                    if (!(list.Hidden))
                    {
                        ContentTypeCollection contentTypeColl = clientContext.Web.Lists.GetByTitle(list.Title).ContentTypes;
                        clientContext.Load(contentTypeColl);
                        clientContext.ExecuteQuery();
                        if (list.ContentTypesEnabled == true)
                        {
                            foreach (ContentType ct in contentTypeColl)
                            {
                                if (ct.Name != "Folder")
                                {
                                    ListName = list.Title;
                                    CnType = ct.Name;
                                    FieldCollection fieldColl = ct.Fields;
                                    clientContext.Load(fieldColl);
                                    clientContext.ExecuteQuery();
                                    Console.WriteLine("List Name & Content Types :{0},{1}", ListName, CnType);
                                    foreach (Field field in fieldColl)
                                    {
                                        if (field.Hidden == false)
                                        {
                                            DataRow row = dtListCtype.NewRow();
                                            row["SiteUrl"] = siteURL;
                                            row["ListName"] = ListName;
                                            row["ContentTypeName"] = CnType;
                                            row["FieldName"] = field.Title;
                                            dtListCtype.Rows.Add(row);
                                        }

                                    }
                                }
                            }
                        }

                    }
                    FieldCollection fieldCollection = list.Fields;
                    clientContext.Load(fieldCollection);
                    clientContext.ExecuteQuery();
                    //Printing Column Names
                    foreach (Field field in fieldCollection)
                    {

                        IEnumerable<DataRow> largeProducts = dtListCtype.AsEnumerable().Where(p => p.Field<string>("FieldName") == field.Title.ToString());
                        foreach (DataRow dr in largeProducts)
                        {
                            DataRow row = dtdesList.NewRow();
                            row["SiteUrl"] = siteURL;
                            row["ListName"] = list.Title;
                            row["ContentTypeName"] = dr.Field<string>("ContentTypeName");
                            row["FieldName"] = dr.Field<string>("FieldName");
                            dtdesList.Rows.Add(row);


                        }

                    }
                }
                if (IsrootSite==false)
                {
                    foreach (Web orWebsite in oWebsite.Webs)
                    {

                        if (!string.IsNullOrEmpty(orWebsite.Url.ToString()))
                        {
                            ListassociatedcontenttypeDes(orWebsite.Url.Trim(), dtListCtype, dtdesList, IsrootSite);


                        }
                    }
                }
               
            }
            catch (Exception ex)
            {

                _logger.ErrorFormat("Error getListInfo :{0},StackeTrace:{1},Method Name:-", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
                Console.WriteLine("Error getListInfo :{0},StackeTrace:{1},Method Name:-", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
            }

        }
       


        /// <summary>
        /// get group details
        /// </summary>
        /// <param name="srcUrl"></param>
        public void getsrcgrps(string srcUrl ,bool IsrootSite)
        {
            dtsrcgrps = new DataTable();
            dtsrcgrps.Columns.Add("SourceUrl", typeof(string));
            dtsrcgrps.Columns.Add("srcgrpName", typeof(string));
            dtsrcgrps.Columns.Add("srcgrppermission", typeof(string));
            dtsrcgrps.Columns.Add("HasUniqueSitepermission", typeof(string));
            getgrpsitepermission(srcUrl, IsrootSite);
        }
        private void getgrpsitepermission(string srcUrl,bool IsrootSite)
        {
            ClientContext clientContext = new ClientContext(srcUrl);
            Web web = clientContext.Web;
            clientContext.Load(web, website => website.Webs, website => website.Url, website => website.Title);
            clientContext.ExecuteQuery();
            clientContext.Load(web, oweb =>
           oweb.HasUniqueRoleAssignments,
           oweb => oweb.Title,
           oweb => oweb.RoleAssignments.Include(
           roleAssignment => roleAssignment.Member.Title,
           roleAssignment => roleAssignment.Member.Id,
           roleAssignment => roleAssignment.RoleDefinitionBindings.Include(
           roleDefinition => roleDefinition.Name)));
            try
            {
                clientContext.ExecuteQuery();
                if (web.HasUniqueRoleAssignments == true)
                {
                    GroupCollection gps = web.SiteGroups;
                    clientContext.Load(gps);
                    try
                    {
                        clientContext.ExecuteQuery();
                    }
                    catch (Exception ex)
                    {
                        _logger.ErrorFormat("Error in groups:{0},Source Url:{1}", ex.Message.ToString(), srcUrl);
                    }

                    Console.WriteLine("Current Site Url:-{0}", web.Url.ToString());
                    _logger.InfoFormat("Current Site Url:-{0}", web.Url.ToString());
                    foreach (var group in gps)
                    {

                        string sitegrpname = group.Title.ToString();
                        RoleAssignmentCollection roleAssignments = web.RoleAssignments;
                        clientContext.Load(clientContext.Web, w => w.RoleAssignments.Where(ra => ra.Member.LoginName == group.LoginName));
                        try
                        {
                            clientContext.ExecuteQuery();
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine("Error in groupsComparison:-{0},StackeTrace:-{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
                            _logger.ErrorFormat("Error in groupsComparison:-{0},StackeTrace:-{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
                        }
                        foreach (var ra in roleAssignments)
                        {
                            clientContext.Load(ra.Member);
                            clientContext.Load(ra.RoleDefinitionBindings);
                            try
                            {
                                clientContext.ExecuteQuery();
                            }
                            catch (Exception ex)
                            {
                                Console.WriteLine("Error in groupsComparison:-{0},StackeTrace:-{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
                                _logger.ErrorFormat("Error in groupsComparison:-{0},StackeTrace:-{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
                            }
                            foreach (var definition in ra.RoleDefinitionBindings)
                            {
                                clientContext.Load(definition);
                                clientContext.ExecuteQuery();
                                DataRow row = dtsrcgrps.NewRow();
                                row["SourceUrl"] = srcUrl;
                                row["srcgrpName"] = group.LoginName;
                                row["srcgrppermission"] = definition.Name;
                                row["HasUniqueSitepermission"] = web.HasUniqueRoleAssignments;
                                dtsrcgrps.Rows.Add(row);
                            }

                        }


                    }
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine("Error in groupsComparison:-{0},StackeTrace:-{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
                _logger.ErrorFormat("Error in groups:{0},Source Url:{1}", ex.Message.ToString(), srcUrl);
            }
            if (IsrootSite==false)
            {
                foreach (Web orWebsite in web.Webs)
                {
                    try
                    {
                        clientContext.Load(orWebsite, sw => sw.Webs, sw => sw.Url, sw => sw.HasUniqueRoleAssignments, sw => sw.ServerRelativeUrl);
                        clientContext.ExecuteQuery();
                        if (orWebsite.HasUniqueRoleAssignments == true)
                        {
                            string pathUrl = string.Empty;
                            // pathUrl = srcUrl.Split(new string[] { "/sites" }, 2, StringSplitOptions.None)[0];
                            //string newpath = pathUrl + orWebsite.ServerRelativeUrl;
                            getgrpsitepermission(orWebsite.Url, IsrootSite);
                        }
                    }
                    catch (Exception ex)
                    {
                        _logger.ErrorFormat("Error Message: {0}", ex.Message.ToString());
                    }
                }
            }
            
        }
        public void getdesgrps(string srcUrl, string filepath,bool IsrootSite)
        {
            dtdesgrps = new DataTable();
            dtdesgrps.Columns.Add("TargetUrl", typeof(string));
            dtdesgrps.Columns.Add("DesgrpName", typeof(string));
            dtdesgrps.Columns.Add("Desgrppermission", typeof(string));
            dtdesgrps.Columns.Add("HasUniqueSiteppermission", typeof(string));
            getTargetSitegrpPermission(srcUrl, filepath, IsrootSite);

            ComparegrpsPermission();
            Comparegrps();
            objExporttoExcel.CreateExcelDocumentFormatinggrpsPermission(dtsrcgrps, dtdesgrps, dtgrpssum, dtgrpsMissing, filepath);
        }
        private void getTargetSitegrpPermission(string srcUrl, string filepath,bool IsrootSite)
        {
            ClientContext clientContext = objConnection.getdestContext(srcUrl);
            Web web = clientContext.Web;

            clientContext.Load(web, website => website.Webs, website => website.Url, website => website.Title);
            clientContext.ExecuteQuery();
            clientContext.Load(web, oweb =>
            oweb.HasUniqueRoleAssignments,
            oweb => oweb.Title,
            oweb => oweb.RoleAssignments.Include(
            roleAssignment => roleAssignment.Member.Title,
            roleAssignment => roleAssignment.Member.Id,
            roleAssignment => roleAssignment.RoleDefinitionBindings.Include(
            roleDefinition => roleDefinition.Name)));
            try
            {
                clientContext.ExecuteQuery();
                if (web.HasUniqueRoleAssignments == true)
                {
                    GroupCollection gps = web.SiteGroups;
                    clientContext.Load(gps);
                    try
                    {
                        clientContext.ExecuteQuery();
                    }
                    catch (Exception ex)
                    {
                        _logger.ErrorFormat("Error in groupsComparison:-{0},StackeTrace:-{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
                    }

                    Console.WriteLine("Current Site Url:-{0}", web.Url.ToString());
                    _logger.InfoFormat("Current Site Url:-{0}", web.Url.ToString());
                    foreach (var group in gps)
                    {

                        string sitegrpname = group.Title.ToString();
                        RoleAssignmentCollection roleAssignments = web.RoleAssignments;
                        clientContext.Load(clientContext.Web, w => w.RoleAssignments.Where(ra => ra.Member.LoginName == group.LoginName));
                        try
                        {
                            clientContext.ExecuteQuery();
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine("Error in groupsComparison:-{0},StackeTrace:-{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
                            _logger.ErrorFormat("Error in groupsComparison:-{0},StackeTrace:-{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
                        }
                        foreach (var ra in roleAssignments)
                        {
                            clientContext.Load(ra.Member);
                            clientContext.Load(ra.RoleDefinitionBindings);
                            try
                            {
                                clientContext.ExecuteQuery();
                            }
                            catch (Exception ex)
                            {
                                Console.WriteLine("Error in groupsComparison:-{0},StackeTrace:-{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
                                _logger.ErrorFormat("Error in groupsComparison:-{0},StackeTrace:-{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
                            }
                            foreach (var definition in ra.RoleDefinitionBindings)
                            {
                                clientContext.Load(definition);
                                clientContext.ExecuteQuery();
                                DataRow row = dtdesgrps.NewRow();
                                row["TargetUrl"] = srcUrl;
                                row["DesgrpName"] = group.LoginName;
                                row["Desgrppermission"] = definition.Name;
                                row["HasUniqueSiteppermission"] = web.HasUniqueRoleAssignments;

                                dtdesgrps.Rows.Add(row);

                            }
                        }


                    }
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine("Error in groupsComparison:-{0},StackeTrace:-{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
                _logger.ErrorFormat("Error in groups:{0},Source Url:{1}", ex.Message.ToString(), srcUrl);
            }
            if (IsrootSite==false)
            {
                foreach (Web orWebsite in web.Webs)
                {
                    try
                    {

                        clientContext.Load(orWebsite, sw => sw.Webs, sw => sw.Url, sw => sw.HasUniqueRoleAssignments, sw => sw.ServerRelativeUrl);
                        clientContext.ExecuteQuery();
                        if (orWebsite.HasUniqueRoleAssignments == true)
                        {
                            getTargetSitegrpPermission(orWebsite.Url, filepath, IsrootSite);
                        }
                    }
                    catch (Exception ex)
                    {
                        _logger.ErrorFormat("Error in groups:{0},Source Url:{1}", ex.Message.ToString(), srcUrl);
                    }
                }
            }
           
        }
        public DataTable ComparegrpsPermission()
        {
            DataTable dtMisMatchSource = new DataTable();
            DataTable dtMisMatchTarget = new DataTable();
            try
            {
                var qry1 = dtsrcgrps.AsEnumerable().Select(a => new { MobileNo = a["srcgrppermission"].ToString() });
                var qry2 = dtdesgrps.AsEnumerable().Select(b => new { MobileNo = b["Desgrppermission"].ToString() });

                try
                {
                    var exceptSource = qry2.Except(qry1);
                    dtMisMatchSource = new DataTable();
                    dtMisMatchSource = (from a in dtdesgrps.AsEnumerable()
                                        join ab in exceptSource on a["Desgrppermission"].ToString() equals ab.MobileNo
                                        select a).CopyToDataTable();
                }
                catch (Exception ex)
                {
                    // _logger.ErrorFormat("Error Message: {0}", ex.Message.ToString());
                }

                try
                {
                    var exceptdes = qry1.Except(qry2);
                    dtMisMatchTarget = new DataTable();
                    dtMisMatchTarget = (from a in dtsrcgrps.AsEnumerable()
                                        join ab in exceptdes on a["srcgrppermission"].ToString() equals ab.MobileNo
                                        select a).CopyToDataTable();
                }
                catch (Exception ex)
                {
                    // _logger.ErrorFormat("Error Message: {0}", ex.Message.ToString());
                }

                dtgrpssum = new DataTable();
                dtgrpssum.Columns.Add("SourceUrl", typeof(string));
                dtgrpssum.Columns.Add("srcgrpName", typeof(string));
                dtgrpssum.Columns.Add("srcgrppermission", typeof(string));
                dtgrpssum.Columns.Add("TargetUrl", typeof(string));
                dtgrpssum.Columns.Add("DesgrpName", typeof(string));
                dtgrpssum.Columns.Add("Desgrppermission", typeof(string));


                if (dtMisMatchTarget.Rows.Count > 0)
                {

                    for (int i = 0; i < dtMisMatchTarget.Rows.Count; i++)
                    {
                        DataRow row = dtgrpssum.NewRow();

                        row["SourceUrl"] = dtMisMatchTarget.Rows[i]["SourceUrl"];
                        row["srcgrpName"] = dtMisMatchTarget.Rows[i]["srcgrpName"];
                        row["srcgrppermission"] = dtMisMatchTarget.Rows[i]["srcgrppermission"];
                        dtgrpssum.Rows.Add(row);
                    }
                }

                if (dtMisMatchSource.Rows.Count > 0)
                {
                    for (int i = 0; i < dtMisMatchSource.Rows.Count; i++)
                    {
                        DataRow row = dtgrpssum.NewRow();
                        row["TargetUrl"] = dtMisMatchSource.Rows[i]["TargetUrl"];
                        row["DesgrpName"] = dtMisMatchSource.Rows[i]["DesgrpName"];
                        row["Desgrppermission"] = dtMisMatchSource.Rows[i]["Desgrppermission"];
                        dtgrpssum.Rows.Add(row);
                    }
                }


            }
            catch (Exception ex)
            {
                _logger.ErrorFormat("Error Message: {0}", ex.Message.ToString());
            }
            return dtgrpssum;
        }
        public DataTable Comparegrps()
        {
            DataTable dtMisMatchSource = new DataTable();
            DataTable dtMisMatchTarget = new DataTable();
            try
            {
                var qry1 = dtsrcgrps.AsEnumerable().Select(a => new { MobileNo = a["srcgrpName"].ToString() });
                var qry2 = dtdesgrps.AsEnumerable().Select(b => new { MobileNo = b["DesgrpName"].ToString() });

                try
                {
                    var exceptSource = qry2.Except(qry1);
                    dtMisMatchSource = new DataTable();
                    dtMisMatchSource = (from a in dtdesgrps.AsEnumerable()
                                        join ab in exceptSource on a["DesgrpName"].ToString() equals ab.MobileNo
                                        select a).CopyToDataTable();
                }
                catch (Exception ex)
                {
                    // _logger.ErrorFormat("Error Message: {0}", ex.Message.ToString());
                }

                try
                {
                    var exceptdes = qry1.Except(qry2);
                    dtMisMatchTarget = new DataTable();
                    dtMisMatchTarget = (from a in dtsrcgrps.AsEnumerable()
                                        join ab in exceptdes on a["srcgrpName"].ToString() equals ab.MobileNo
                                        select a).CopyToDataTable();
                }
                catch (Exception ex)
                {
                    //_logger.ErrorFormat("Error Message: {0}", ex.Message.ToString());
                }

                dtgrpsMissing = new DataTable();
                dtgrpsMissing.Columns.Add("SourceUrl", typeof(string));
                dtgrpsMissing.Columns.Add("srcgrpName", typeof(string));
                dtgrpsMissing.Columns.Add("srcgrppermission", typeof(string));
                dtgrpsMissing.Columns.Add("TargetUrl", typeof(string));
                dtgrpsMissing.Columns.Add("DesgrpName", typeof(string));
                dtgrpsMissing.Columns.Add("Desgrppermission", typeof(string));


                if (dtMisMatchTarget.Rows.Count > 0)
                {

                    for (int i = 0; i < dtMisMatchTarget.Rows.Count; i++)
                    {
                        DataRow row = dtgrpsMissing.NewRow();

                        row["SourceUrl"] = dtMisMatchTarget.Rows[i]["SourceUrl"];
                        row["srcgrpName"] = dtMisMatchTarget.Rows[i]["srcgrpName"];
                        row["srcgrppermission"] = dtMisMatchTarget.Rows[i]["srcgrppermission"];
                        dtgrpsMissing.Rows.Add(row);
                    }
                }

                if (dtMisMatchSource.Rows.Count > 0)
                {
                    for (int i = 0; i < dtMisMatchSource.Rows.Count; i++)
                    {
                        DataRow row = dtgrpsMissing.NewRow();
                        row["TargetUrl"] = dtMisMatchSource.Rows[i]["TargetUrl"];
                        row["DesgrpName"] = dtMisMatchSource.Rows[i]["DesgrpName"];
                        row["Desgrppermission"] = dtMisMatchSource.Rows[i]["Desgrppermission"];
                        dtgrpsMissing.Rows.Add(row);
                    }
                }


            }
            catch (Exception ex)
            {
                _logger.ErrorFormat("Error Message: {0}", ex.Message.ToString());
            }
            return dtgrpsMissing;
        }



        public void getListPermSrc(string siteUrl, DataTable dtListsrc,bool IsrootSite)
        {
            ClientContext clientContext = new ClientContext(siteUrl);
            Web oWebsite = clientContext.Web;
            clientContext.Load(oWebsite, web => web.Webs, Web => Web.Title);
            ListCollection lists = clientContext.Web.Lists;
            clientContext.Load(lists);
            clientContext.ExecuteQuery();

            foreach (List list in lists)
            {
                if (!(list.Hidden))
                {
                    List lst = oWebsite.Lists.GetByTitle(list.Title);
                    clientContext.Load(lst, l => l.HasUniqueRoleAssignments, l => l.RoleAssignments, l => l.Title);
                    clientContext.ExecuteQuery();
                    if (lst.HasUniqueRoleAssignments == true)
                    {
                        Console.WriteLine("\n");
                        Console.WriteLine("Site Url:{0}", siteUrl);
                        Console.WriteLine("List Name Url:{0}", lst.Title);
                        RoleAssignmentCollection roleAssCol = lst.RoleAssignments;
                        clientContext.Load(roleAssCol);
                        clientContext.ExecuteQuery();
                        foreach (RoleAssignment roleAss in roleAssCol)
                        {
                            clientContext.Load(roleAss, rl => rl.Member, rl => rl.RoleDefinitionBindings);
                            try
                            {
                                clientContext.ExecuteQuery();
                            }
                            catch (Exception ex)
                            {
                                _logger.ErrorFormat("Error in Folder Level :{0},StackeTrace:{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
                                Console.WriteLine("Error in Folder Level :{0},StackeTrace:{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
                            }

                            foreach (var roldef in roleAss.RoleDefinitionBindings)
                            {
                                DataRow row = dtListsrc.NewRow();
                                row["SiteUrl"] = siteUrl;
                                row["ListName"] = lst.Title.ToString();
                                row["ListPermission"] = roldef.Name.ToString();

                                Console.WriteLine("List Permission:{0}", roldef.Name.ToString());
                                if (roleAss.Member.LoginName.Contains("i:0#.w"))
                                {
                                    row["Users/Group"] = roleAss.Member.LoginName.ToString().Split('|')[1].ToString();
                                }
                                else
                                {
                                    row["Users/Group"] = roleAss.Member.LoginName.ToString();
                                }
                                dtListsrc.Rows.Add(row);

                            }
                        }
                    }

                }
            }

            if (IsrootSite==false)
            {
                foreach (Web orWebsite in oWebsite.Webs)
                {
                    if (!string.IsNullOrEmpty(orWebsite.Url.ToString()))
                    {
                        getListPermSrc(orWebsite.Url.ToString().Trim(), dtListsrc, IsrootSite);
                    }

                }
            }
           
        }

        public void getListPermdes(string siteUrl, DataTable dtListdes,bool IsrootSite)
        {
            ClientContext clientContext = objConnection.getdestContext(siteUrl);
            Web oWebsite = clientContext.Web;
            clientContext.Load(oWebsite, web => web.Webs, Web => Web.Title);
            ListCollection lists = clientContext.Web.Lists;
            clientContext.Load(lists);
            clientContext.ExecuteQuery();

            foreach (List list in lists)
            {
                if (!(list.Hidden))
                {
                    List lst = oWebsite.Lists.GetByTitle(list.Title);
                    clientContext.Load(lst, l => l.HasUniqueRoleAssignments, l => l.RoleAssignments, l => l.Title);
                    clientContext.ExecuteQuery();
                    if (lst.HasUniqueRoleAssignments == true)
                    {
                        Console.WriteLine("\n");
                        Console.WriteLine("Site Url:{0}", siteUrl);
                        Console.WriteLine("List Name Url:{0}", lst.Title);
                        RoleAssignmentCollection roleAssCol = lst.RoleAssignments;
                        clientContext.Load(roleAssCol);
                        clientContext.ExecuteQuery();
                        foreach (RoleAssignment roleAss in roleAssCol)
                        {
                            clientContext.Load(roleAss, rl => rl.Member, rl => rl.RoleDefinitionBindings);
                            try
                            {
                                clientContext.ExecuteQuery();
                            }
                            catch (Exception ex)
                            {
                                _logger.ErrorFormat("Error in Folder Level :{0},StackeTrace:{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
                                Console.WriteLine("Error in Folder Level :{0},StackeTrace:{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
                            }

                            foreach (var roldef in roleAss.RoleDefinitionBindings)
                            {

                                Console.WriteLine("List Permission:{0}", roldef.Name.ToString());

                                DataRow row = dtListdes.NewRow();
                                row["SiteUrl"] = siteUrl;
                                row["ListName"] = lst.Title.ToString();
                                row["ListPermission"] = roldef.Name.ToString();
                                row["Users/Group"] = roleAss.Member.LoginName.ToString();
                                dtListdes.Rows.Add(row);

                            }
                        }
                    }

                }
            }

            if (IsrootSite==false)
            {
                foreach (Web orWebsite in oWebsite.Webs)
                {
                    if (!string.IsNullOrEmpty(orWebsite.Url.ToString()))
                    {
                        getListPermdes(orWebsite.Url.ToString().Trim(), dtListdes, IsrootSite);
                    }

                }
            }
          
        }

        /// <summary>
        /// Feature Comparsion
        /// </summary>
        public void getFeatureComparsion(string srcUrl, string strTargetURL, string filepath)
        {
            try
            {
                SiteFeatureComparer comparer = new SiteFeatureComparer();

                Console.WriteLine("Current Site Url:-{0},{1}", srcUrl.ToString(), strTargetURL);
                _logger.InfoFormat("Current Site Url:-{0},{1}", srcUrl.ToString(), strTargetURL);
                dtFeatResult = comparer.GetFeatureComparisionResult(srcUrl, strTargetURL);
                objExporttoExcel.CreateExcelDocumentFormatingFeature(dtFeatResult, filepath);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error in FeatureComparison:{0},StackeTrace:{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
                _logger.ErrorFormat("Error in FeatureComparison:{0},StackeTrace:{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
            }
        }

        /// <summary>
        /// Finding Document Versions
        /// </summary>
        /// <param name="srcUrl"></param>
        /// <param name="strTargetURL"></param>
        /// <param name="filepath"></param>
        public void getDocumentVersion(string srcUrl, string strTargetURL, string filepath)
        {
            try
            {
                DocumentComparison docCom = new DocumentComparison();

                Console.WriteLine("Current Site Url:-{0},{1}", srcUrl.ToString(), strTargetURL);
                _logger.InfoFormat("Current Site Url:-{0},{1}", srcUrl.ToString(), strTargetURL);
                dtDocResult = docCom.GetDocumentComparison(srcUrl, strTargetURL);
                objExporttoExcel.CreateExcelDocumentFormatingDocumetVersion(dtDocResult, filepath);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error in DocumentVersion:{0},StackeTrace:{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
                _logger.ErrorFormat("Error in DocumentVersion:{0},StackeTrace:{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
            }
        }

        public void getSiteUsers(string srcUrl)
        {
            dtsiteUserssrc = new DataTable();
            dtsiteUserssrc.Columns.Add("SiteUrl", typeof(string));
            dtsiteUserssrc.Columns.Add("UserLoginName", typeof(string));
            dtsiteUserssrc.Columns.Add("UserEmail", typeof(string));
            dtsiteUserssrc.Columns.Add("ListName", typeof(string));
            dtsiteUserssrc.Columns.Add("Permission", typeof(string));
            try
            {
                using (var clientContext = new ClientContext(srcUrl))
                {
                    Web web = clientContext.Web;
                    UserCollection coll = web.SiteUsers;
                    clientContext.Load(coll);
                    clientContext.ExecuteQuery();
                    foreach (User users in coll)
                    {

                        User usr = clientContext.Web.EnsureUser(users.LoginName);
                        clientContext.Load(usr);
                        try
                        {
                            clientContext.ExecuteQuery();

                            var lists = clientContext.Web.Lists;
                            clientContext.Load(lists, lc => lc.Include(l => l.Title, l => l.Hidden));
                            //you can use one execute per multiple loads
                            clientContext.ExecuteQuery();
                            foreach (var list in lists)
                            {
                                if (list.Hidden == false)
                                {


                                    DataRow row = dtsiteUserssrc.NewRow();
                                    var permissions = list.GetUserEffectivePermissions(usr.LoginName);
                                    var assignments = list.RoleAssignments;
                                    clientContext.Load(assignments, ac => ac.Include(
                                        a => a.RoleDefinitionBindings, a => a.Member.LoginName));
                                    clientContext.ExecuteQuery();


                                    var assignment = assignments.FirstOrDefault(a => a.Member.LoginName == usr.LoginName);

                                    if (assignment != null)
                                    {
                                        foreach (var role in assignment.RoleDefinitionBindings)
                                        {

                                            row["SiteUrl"] = srcUrl;
                                            row["UserLoginName"] = usr.LoginName;
                                            row["UserEmail"] = usr.Email;
                                            row["ListName"] = list.Title;
                                            row["Permission"] = role.Name;
                                            break;
                                        }
                                    }
                                    else
                                    {

                                        row["SiteUrl"] = srcUrl;
                                        row["UserLoginName"] = usr.LoginName;
                                        row["UserEmail"] = usr.Email;
                                        row["ListName"] = list.Title;
                                        row["Permission"] = string.Empty;
                                        break;
                                    }

                                    dtsiteUserssrc.Rows.Add(row);
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            _logger.ErrorFormat("Error Message: {0}", ex.Message.ToString());
                        }

                    }


                }
            }
            catch (Exception ex)
            {
                _logger.ErrorFormat("Error Message: {0}", ex.Message.ToString());
            }
        }
        public void getSiteUsersDes(string strTargetURL, string filepath)
        {
            dtsiteUsersdes = new DataTable();
            dtsiteUsersdes.Columns.Add("SiteUrl", typeof(string));
            dtsiteUsersdes.Columns.Add("UserLoginName", typeof(string));
            dtsiteUsersdes.Columns.Add("UserEmail", typeof(string));
            dtsiteUsersdes.Columns.Add("ListName", typeof(string));
            dtsiteUsersdes.Columns.Add("Permission", typeof(string));
            try
            {
                using (var clientContext = objConnection.getdestContext(strTargetURL))
                {
                    Web web = clientContext.Web;
                    UserCollection coll = web.SiteUsers;
                    clientContext.Load(coll);
                    clientContext.ExecuteQuery();
                    foreach (User users in coll)
                    {

                        User usr = clientContext.Web.EnsureUser(users.LoginName);
                        clientContext.Load(usr);
                        try
                        {
                            clientContext.ExecuteQuery();

                            var lists = clientContext.Web.Lists;
                            clientContext.Load(lists, lc => lc.Include(l => l.Title, l => l.Hidden));
                            //you can use one execute per multiple loads
                            clientContext.ExecuteQuery();
                            foreach (var list in lists)
                            {
                                if (list.Hidden == false)
                                {
                                    DataRow row = dtsiteUsersdes.NewRow();
                                    var permissions = list.GetUserEffectivePermissions(usr.LoginName);
                                    var assignments = list.RoleAssignments;
                                    clientContext.Load(assignments, ac => ac.Include(
                                        a => a.RoleDefinitionBindings, a => a.Member.LoginName));
                                    clientContext.ExecuteQuery();


                                    var assignment = assignments.FirstOrDefault(a => a.Member.LoginName == usr.LoginName);

                                    if (assignment != null)
                                    {
                                        foreach (var role in assignment.RoleDefinitionBindings)
                                        {

                                            row["SiteUrl"] = strTargetURL;
                                            row["UserLoginName"] = usr.LoginName;
                                            row["UserEmail"] = usr.Email;
                                            row["ListName"] = list.Title;
                                            row["Permission"] = role.Name;
                                        }
                                    }
                                    else
                                    {

                                        row["SiteUrl"] = strTargetURL;
                                        row["UserLoginName"] = usr.LoginName;
                                        row["UserEmail"] = usr.Email;
                                        row["ListName"] = list.Title;
                                        row["Permission"] = string.Empty;
                                    }

                                    dtsiteUsersdes.Rows.Add(row);
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            _logger.ErrorFormat("Error Message: {0}", ex.Message.ToString());
                        }

                    }


                }
            }
            catch (Exception ex)
            {
                _logger.ErrorFormat("Error Message: {0}", ex.Message.ToString());
            }

            CompareSiteUsers();
            objExporttoExcel.CreateExcelDocumentFormatingSiteUsersPermission(dtsiteUserssrc, dtsiteUsersdes, dtsiteUserssum, filepath);
        }
        public DataTable CompareSiteUsers()
        {
            DataTable dtMisMatchSource = null;
            DataTable dtMisMatchTarget = null;
            try
            {
                var qry1 = dtsiteUserssrc.AsEnumerable().Select(a => new { MobileNo = a["Permission"].ToString() });
                var qry2 = dtsiteUsersdes.AsEnumerable().Select(b => new { MobileNo = b["Permission"].ToString() });

                try
                {
                    var exceptSource = qry2.Except(qry1);
                    dtMisMatchSource = new DataTable();
                    dtMisMatchSource = (from a in dtsiteUsersdes.AsEnumerable()
                                        join ab in exceptSource on a["Permission"].ToString() equals ab.MobileNo
                                        select a).CopyToDataTable();
                }
                catch (Exception ex)
                {
                    _logger.ErrorFormat("Error Message: {0}", ex.Message.ToString());
                }

                try
                {
                    var exceptdes = qry1.Except(qry2);
                    dtMisMatchTarget = new DataTable();
                    dtMisMatchTarget = (from a in dtsiteUserssrc.AsEnumerable()
                                        join ab in exceptdes on a["Permission"].ToString() equals ab.MobileNo
                                        select a).CopyToDataTable();
                }
                catch (Exception ex)
                {
                    _logger.ErrorFormat("Error Message: {0}", ex.Message.ToString());

                }



                dtsiteUserssum = new DataTable();


                dtsiteUserssum.Columns.Add("SourceUrl", typeof(string));
                dtsiteUserssum.Columns.Add("sourceEmail", typeof(string));
                dtsiteUserssum.Columns.Add("SourcePermission", typeof(string));

                dtsiteUserssum.Columns.Add("TargeteUrl", typeof(string));
                dtsiteUserssum.Columns.Add("TargetEmail", typeof(string));
                dtsiteUserssum.Columns.Add("TargetPermission", typeof(string));

                if (dtMisMatchTarget.Rows.Count > 0)
                {

                    for (int i = 0; i < dtMisMatchTarget.Rows.Count; i++)
                    {
                        DataRow row = dtsiteUserssum.NewRow();

                        row["SourceUrl"] = dtMisMatchTarget.Rows[i]["SiteUrl"];
                        row["sourceEmail"] = dtMisMatchTarget.Rows[i]["UserEmail"];
                        row["SourcePermission"] = dtMisMatchTarget.Rows[i]["Permission"];

                        dtsiteUserssum.Rows.Add(row);
                    }
                }

                if (dtMisMatchSource.Rows.Count > 0)
                {
                    for (int i = 0; i < dtMisMatchSource.Rows.Count; i++)
                    {
                        DataRow row = dtsiteUserssum.NewRow();

                        row["TargeteUrl"] = dtMisMatchTarget.Rows[i]["SiteUrl"];
                        row["TargetEmail"] = dtMisMatchTarget.Rows[i]["UserEmail"];
                        row["TargetPermission"] = dtMisMatchTarget.Rows[i]["Permission"];

                        dtsiteUserssum.Rows.Add(row);
                    }
                }


            }
            catch (Exception ex)
            {
                _logger.ErrorFormat("Error Message: {0}", ex.Message.ToString());
            }
            return dtcnTypeSum;
        }
    }

}

