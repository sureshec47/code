﻿namespace PostMigrationToolV2
{
    public class JDocLib
    {
        public D d { get; set; }
    }

    public class D
    {
        public Result[] results { get; set; }
        public string __next { get; set; }
    }
    public class Result
    {
      
        public File File { get; set; }

        
    }
    public class File
    {
        public string CheckOutType { get; set; }
        public string MajorVersion { get; set; }
        public string Name { get; set; }
        public string ServerRelativeUrl { get; set; }
        public string UIVersionLabel { get; set; }
        public string LinkingUrl { get; set; }
        public RoleAssignments[] roleAssignments { get; set; }
      
        public string DocumentURL { get; set; }

    }
    public class RoleAssignments
    {
        public string Member { get; set; }
        public string LoginName { get; set; }
        public string RoleDefinitionBindings { get; set; }
        public string Name { get; set; }
       
    }
}
