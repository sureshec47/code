﻿using Microsoft.SharePoint.Client;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net.Http;
using System.Security;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Configuration;
using PostMigrationToolV2.nJSubwebs;
using PostMigrationToolV2.nJContentTypes;
using System.IO;

namespace PostMigrationToolV2
{
    public class GetContentTypes
    {
        private static readonly log4net.ILog _logger = log4net.LogManager.GetLogger(typeof(Program));
        string url = string.Empty;
        UtliClass util = new UtliClass();
        SecureString securePassword = new SecureString();
        StringBuilder stringBuilder = new StringBuilder();
        DataTable dtsrc = new DataTable();
        DataTable dtdes = new DataTable();
        DataTable dtcnTypeSum = new DataTable();
        ExporttoExcel objExporttoExcel = new ExporttoExcel();
        public void getContentTypes(string sourceUrl, string destUrl, string filepath,bool IsrootSite)
        {
            string siteName = string.Empty;
            dtsrc = new DataTable();
            dtsrc.Columns.Add("SourceUrl", typeof(string));
            dtsrc.Columns.Add("SourceCntTypeName", typeof(string));

            dtdes = new DataTable();
            dtdes.Columns.Add("TargeteUrl", typeof(string));
            dtdes.Columns.Add("TargetCntTypeName", typeof(string));



            try
            {
                util.UserName = ConfigurationSettings.AppSettings["domain"].ToString() + "\\" + ConfigurationSettings.AppSettings["SRCUserName"].ToString();
                util.Password = ConfigurationSettings.AppSettings["SRCPassword"].ToString();
                util.SPOuserName = ConfigurationSettings.AppSettings["OnlineUserName"].ToString();
                string SPOpassword = ConfigurationSettings.AppSettings["password"].ToString();
                foreach (var c in SPOpassword) securePassword.AppendChar(c);
                util.SPOpassword = securePassword;
                util.stringBuilder = stringBuilder;
                util.stringBuilder.AppendLine("Site Name,Source,Destination");
                url = "{0}/_api/web?&$select=Title";
                string jsonResponse = GetRestResult(string.Format(url, sourceUrl), util.SourcehttpClientHandler).Result;
                Newtonsoft.Json.Linq.JObject o = Newtonsoft.Json.Linq.JObject.Parse(jsonResponse);
                siteName = Convert.ToString(o.SelectToken("d").SelectToken("Title"));
               
                Console.WriteLine("Current Site Url:-{0},{1}", sourceUrl.ToString(), destUrl);
                _logger.InfoFormat("Current Site Url:-{0},{1}", sourceUrl.ToString(), destUrl);
                getContentTypeDetails(util, sourceUrl, destUrl);
                if (IsrootSite==false)
                {
                    SubwebsDiffReporter(util, sourceUrl, destUrl);
                }
               
                CompareContentTypes();
                objExporttoExcel.CreateExcelDocumentFormatingContentType(dtsrc, dtdes, dtcnTypeSum, filepath);
            }
            catch (Exception ex)
            {
                _logger.ErrorFormat("Error in ContentTypes :{0},Site Name:{1}", ex.Message.ToString(), siteName);
            }
        }

        private void getContentTypeDetails(UtliClass util, string sourceUrl, string destUrl)
        {

            try
            {
                string url = "{0}/_api/web/contenttypes?$select=Name";
                string jsonResponse = GetRestResult(string.Format(url, sourceUrl), util.SourcehttpClientHandler).Result;
                JContentTypes jDocS = JsonConvert.DeserializeObject<JContentTypes>(jsonResponse);
                jDocS.d.results = jDocS.d.results.Where(s => s.Name != null).ToArray();
                foreach (var cntype in jDocS.d.results)
                {

                    if (!string.IsNullOrEmpty(cntype.Name))
                    {
                        DataRow row = dtsrc.NewRow();

                        row["SourceUrl"] = sourceUrl;
                        row["SourceCntTypeName"] = cntype.Name;
                        dtsrc.Rows.Add(row);
                    }

                }
                jsonResponse = string.Empty;
                jsonResponse = GetRestResult(string.Format(url, destUrl), GetSPOClientHandler(string.Format(url, destUrl), util)).Result;
                JContentTypes jLibsd = JsonConvert.DeserializeObject<JContentTypes>(jsonResponse);
                jLibsd.d.results = jLibsd.d.results.Where(s => s.Name != null).ToArray();
                foreach (var cntypedes in jLibsd.d.results)
                {

                    if (!string.IsNullOrEmpty(cntypedes.Name))
                    {
                        DataRow row = dtdes.NewRow();

                        row["TargeteUrl"] = destUrl;
                        row["TargetCntTypeName"] = cntypedes.Name;
                        dtdes.Rows.Add(row);
                    }

                }
            }
            catch (Exception ex)
            {
                _logger.ErrorFormat("Error in Content Types:{0},StackeTrace:{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
            }

        }

        private void SubwebsDiffReporter(UtliClass util, string sourceUrl, string destUrl)
        {
            try
            {
                string url = "{0}/_api/web/Webs?$select=Title,Url,ServerRelativeUrl";
                string temp = string.Empty;
                string jsonResponse = GetRestResult(string.Format(url, sourceUrl), util.SourcehttpClientHandler).Result;
                JSubwebs subwebsS = JsonConvert.DeserializeObject<JSubwebs>(jsonResponse);
                jsonResponse = GetRestResult(string.Format(url, destUrl), GetSPOClientHandler(string.Format(url, destUrl), util)).Result;
                JSubwebs subwebsD = JsonConvert.DeserializeObject<JSubwebs>(jsonResponse);
                IEnumerable<nJSubwebs.Result> diffsubwebs = subwebsS.d.results.Where(s => !subwebsD.d.results.Any(d => s.Title == d.Title));
                if (subwebsS.d.results.Length > 0 || subwebsD.d.results.Length > 0)
                    util.stringBuilder.AppendLine("Sub Sites,,");

                diffsubwebs = subwebsD.d.results.Where(s => !subwebsS.d.results.Any(d => s.Title == d.Title));

                diffsubwebs = subwebsS.d.results.Where(s => subwebsD.d.results.Any(d => s.Title == d.Title));
                foreach (nJSubwebs.Result result in diffsubwebs.ToArray())
                {
                    temp = result.ServerRelativeUrl.Split('/')[result.ServerRelativeUrl.Split('/').Length - 1];
                    getContentTypeDetails(util, string.Format("{0}/{1}", sourceUrl, temp), string.Format("{0}/{1}", destUrl, temp));
                    SubwebsDiffReporter(util, string.Format("{0}/{1}", sourceUrl, temp), string.Format("{0}/{1}", destUrl, temp));
                }
            }
            catch (Exception ex)
            {
                _logger.ErrorFormat("Error in Content Types:{0},StackeTrace:{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
            }

        }

        public DataTable CompareContentTypes()
        {
            DataTable dtMisMatchSource = new DataTable();

            DataTable dtMisMatchTarget = new DataTable();
            try
            {
                var qry1 = dtsrc.AsEnumerable().Select(a => new { cntType = a["SourceCntTypeName"].ToString() });
                var qry2 = dtdes.AsEnumerable().Select(b => new { cntType = b["TargetCntTypeName"].ToString() });

                //var qry3 = dtcsvContent.AsEnumerable().Select(c => new { cntType = c["Content Types"].ToString() });
                try
                {
                    var exceptSource = qry2.Except(qry1);
                    dtMisMatchSource = new DataTable();
                    dtMisMatchSource = (from a in dtdes.AsEnumerable()
                                        join ab in exceptSource on a["TargetCntTypeName"].ToString() equals ab.cntType
                                        select a).CopyToDataTable();
                }
                catch (Exception ex)
                {
                   // _logger.ErrorFormat("Error Message: {0}", ex.Message.ToString());

                }

                try
                {
                    var exceptdes = qry1.Except(qry2);
                    dtMisMatchTarget = new DataTable();
                    dtMisMatchTarget = (from a in dtsrc.AsEnumerable()
                                        join ab in exceptdes on a["SourceCntTypeName"].ToString() equals ab.cntType
                                        select a).CopyToDataTable();
                }
                catch (Exception ex)
                {
                   // _logger.ErrorFormat("Error Message: {0}", ex.Message.ToString());
                }

                dtcnTypeSum = new DataTable();
                dtcnTypeSum.Columns.Add("SourceUrl", typeof(string));
                dtcnTypeSum.Columns.Add("SourceCntTypeName", typeof(string));
                dtcnTypeSum.Columns.Add("TargeteUrl", typeof(string));
                dtcnTypeSum.Columns.Add("TargetCntTypeName", typeof(string));
                if (dtMisMatchTarget.Rows.Count > 0)
                {

                    for (int i = 0; i < dtMisMatchTarget.Rows.Count; i++)
                    {
                        DataRow row = dtcnTypeSum.NewRow();

                        row["SourceUrl"] = dtMisMatchTarget.Rows[i]["SourceUrl"];
                        row["SourceCntTypeName"] = dtMisMatchTarget.Rows[i]["SourceCntTypeName"];
                        dtcnTypeSum.Rows.Add(row);
                    }
                }

                if (dtMisMatchSource.Rows.Count > 0)
                {
                    for (int i = 0; i < dtMisMatchSource.Rows.Count; i++)
                    {
                        DataRow row = dtcnTypeSum.NewRow();
                        row["TargeteUrl"] = dtMisMatchSource.Rows[i]["TargeteUrl"];
                        row["TargetCntTypeName"] = dtMisMatchSource.Rows[i]["TargetCntTypeName"];
                        dtcnTypeSum.Rows.Add(row);
                    }
                }


            }
            catch (Exception ex)
            {
                _logger.ErrorFormat("Error in Content Types:{0},StackeTrace:{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());

            }
            return dtcnTypeSum;
        }
        private async Task<string> GetRestResult(string webUrl, HttpClientHandler handler)
        {
            string jsonData = string.Empty;
            using (var client = new HttpClient(handler))
            {
                client.Timeout = TimeSpan.FromSeconds(1000);
                client.DefaultRequestHeaders.Clear();
                client.DefaultRequestHeaders.Add("Accept", "application/json;odata=verbose");
                client.DefaultRequestHeaders.Add("ContentType", "application/json");

                HttpResponseMessage response = await client.GetAsync(webUrl).ConfigureAwait(false);

                response.EnsureSuccessStatusCode();
                jsonData = await response.Content.ReadAsStringAsync();
                return jsonData;
            }



        }

        private HttpClientHandler GetSPOClientHandler(string spSiteUrl, UtliClass utli)
        {
            var credential = new SharePointOnlineCredentials(utli.SPOuserName, utli.SPOpassword);
            HttpClientHandler handler = new HttpClientHandler() { Credentials = credential };
            //Getting authentication cookies
            Uri uri = new Uri(spSiteUrl);
            handler.CookieContainer.SetCookies(uri, credential.GetAuthenticationCookie(uri));
            return handler;
        }
    }
}
