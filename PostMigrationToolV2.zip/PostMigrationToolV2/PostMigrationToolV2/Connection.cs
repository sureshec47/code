﻿using Microsoft.SharePoint.Client;
using System;
using System.Configuration;
using System.IO;
using System.Security;
namespace PostMigrationToolV2
{
    public class Connection
    {
        private static readonly log4net.ILog _logger = log4net.LogManager.GetLogger(typeof(Program));
        public string username = "";
        public string password = "";
        public string domain = "";
        public string onlineUserName = "";
        
        ExporttoExcel objExporttoExcel = new ExporttoExcel();
        public Connection()
        {
             
            username = ConfigurationManager.AppSettings["username"];
            password = ConfigurationManager.AppSettings["password"];
            domain = ConfigurationManager.AppSettings["domain"];
            onlineUserName = ConfigurationManager.AppSettings["OnlineUserName"];
           
            
        }
        public ClientContext getsrcContext(string URL)
        {
            ClientContext clientContext = new ClientContext(URL);
            try
            {
             // clientContext.Credentials = new NetworkCredential(username, password, domain);
            }
            catch (Exception ex)
            {
                _logger.ErrorFormat("Error Message: {0}", ex.Message.ToString());
            }
            return clientContext;
        }
        public ClientContext getdestContext(string URL)
        {
            ClientContext clientContext = new ClientContext(URL);
            try
            {
                clientContext.Credentials = new SharePointOnlineCredentials(onlineUserName, GetPasswordFromConsoleInput(password));
            }
            catch (Exception ex)
            {
                _logger.ErrorFormat("Error Message: {0}", ex.Message.ToString());
            }
            return clientContext;
        }
        public Web getWeb(ClientContext clientContext)
        {
                Web web = clientContext.Web;
                clientContext.Load(web);
                try
                {
                    clientContext.ExecuteQuery();
                }
            catch (Exception ex)
            {
                _logger.ErrorFormat("Error Message: {0}", ex.Message.ToString());
            }
            return web;

        }
        public WebCollection getWebs(ClientContext clientContext,Web web)
        {
            WebCollection webs = web.Webs;
            clientContext.Load(webs,w => w.Include(w1 => w1.Title,w1 => w1.ServerRelativeUrl));
            try
            {
                clientContext.ExecuteQuery();
            }
            catch (Exception ex)
            {
                _logger.ErrorFormat("Error Message: {0}", ex.Message.ToString());
            }
            return webs;
        }
       
        private static SecureString GetPasswordFromConsoleInput(string password)
        {
            SecureString securePassword = new SecureString();
            foreach (char c in password)
            {
                securePassword.AppendChar(c);
            }
            return securePassword;
        }
    }
}
