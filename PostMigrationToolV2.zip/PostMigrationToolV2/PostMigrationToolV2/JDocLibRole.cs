﻿namespace PostMigrationToolV2.nJLibrarysRole
{
    public class JDocLibRole
    {
        public D d { get; set; }
    }

    public class D
    {
        public Result[] results { get; set; }
    }

    public class Result
    {
        public __Metadata __metadata { get; set; }
        public Roleassignments RoleAssignments { get; set; }
        public File File { get; set; }
        public bool HasUniqueRoleAssignments { get; set; }
    }

    public class __Metadata
    {
        public string id { get; set; }
        public string uri { get; set; }
        public string etag { get; set; }
        public string type { get; set; }
    }

    public class Roleassignments
    {
        public Result1[] results { get; set; }
    }

    public class Result1
    {
        public __Metadata1 __metadata { get; set; }
        public Member Member { get; set; }
        public Roledefinitionbindings RoleDefinitionBindings { get; set; }
    }

    public class __Metadata1
    {
        public string id { get; set; }
        public string uri { get; set; }
        public string type { get; set; }
    }

    public class Member
    {
        public __Metadata2 __metadata { get; set; }
        public Groups Groups { get; set; }
        public string LoginName { get; set; }
        public Users Users { get; set; }
    }

    public class __Metadata2
    {
        public string id { get; set; }
        public string uri { get; set; }
        public string type { get; set; }
    }

    public class Groups
    {
        public __Deferred __deferred { get; set; }
    }

    public class __Deferred
    {
        public string uri { get; set; }
    }

    public class Users
    {
        public Result2[] results { get; set; }
    }

    public class Result2
    {
        public __Metadata3 __metadata { get; set; }
        public Groups1 Groups { get; set; }
        public int Id { get; set; }
        public bool IsHiddenInUI { get; set; }
        public string LoginName { get; set; }
        public string Title { get; set; }
        public int PrincipalType { get; set; }
        public string Email { get; set; }
        public bool IsSiteAdmin { get; set; }
        public Userid UserId { get; set; }
    }

    public class __Metadata3
    {
        public string id { get; set; }
        public string uri { get; set; }
        public string type { get; set; }
    }

    public class Groups1
    {
        public __Deferred1 __deferred { get; set; }
    }

    public class __Deferred1
    {
        public string uri { get; set; }
    }

    public class Userid
    {
        public __Metadata4 __metadata { get; set; }
        public string NameId { get; set; }
        public string NameIdIssuer { get; set; }
    }

    public class __Metadata4
    {
        public string type { get; set; }
    }

    public class Roledefinitionbindings
    {
        public Result3[] results { get; set; }
    }

    public class Result3
    {
        public __Metadata5 __metadata { get; set; }
        public string Name { get; set; }
    }

    public class __Metadata5
    {
        public string id { get; set; }
        public string uri { get; set; }
        public string type { get; set; }
    }

    public class File
    {
        public __Metadata6 __metadata { get; set; }
        public string Name { get; set; }
        public string ServerRelativeUrl { get; set; }
    }

    public class __Metadata6
    {
        public string id { get; set; }
        public string uri { get; set; }
        public string type { get; set; }
    }
}