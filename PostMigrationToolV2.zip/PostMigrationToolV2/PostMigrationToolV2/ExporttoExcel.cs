﻿using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Spreadsheet;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.IO;

namespace PostMigrationToolV2
{
    public class ExporttoExcel
    {
        public int sourceCount = 0;
        public int TargetCount = 0;
        public int mismatchCount = 0;
        private static readonly log4net.ILog _logger = log4net.LogManager.GetLogger(typeof(Program));
        DataSet tableSet = new DataSet();

        //public void logFile(string logMessage, TextWriter w)
        //{
        //    w.WriteLine(logMessage);
        //}


        public bool CreateExcelDocumentFormatingContentType(DataTable dtsource, DataTable dttarget, DataTable dtCmpCntType, string xlsxFilePath)
        {
            tableSet = new DataSet();

            if (dtsource != null)
            {
                dtsource.TableName = "SourceUserCntType";
                tableSet.Tables.Add(dtsource);
            }
            if (dttarget != null)
            {
                dttarget.TableName = "TargetCntType";
                tableSet.Tables.Add(dttarget);
            }
            if (dtCmpCntType != null)
            {
                dtCmpCntType.TableName = "CntTypeComparsion";
                tableSet.Tables.Add(dtCmpCntType);
            }
            //List<DataRow> rowsToDelete = new List<DataRow>();
            //for (int i = 0; i < dtcsvContent.Rows.Count; i++)
            //{
            //    foreach (DataRow DR in dtCmpCntType.Rows)
            //    {
            //        if (DR["SourceCntTypeName"].ToString() == dtcsvContent.Rows[i]["Source Content Types"].ToString())
            //            rowsToDelete.Add(DR);

            //        if (DR["TargetCntTypeName"].ToString() == dtcsvContent.Rows[i]["Target Content Types"].ToString())
            //            rowsToDelete.Add(DR);
            //    }
            //}

            //foreach (var r in rowsToDelete)
            //    dtCmpCntType.Rows.Remove(r);

            WorkbookPart wBookPart = null;
            try
            {

                using (SpreadsheetDocument spreadsheetDoc = SpreadsheetDocument.Create(xlsxFilePath, SpreadsheetDocumentType.Workbook))
                {
                    wBookPart = spreadsheetDoc.AddWorkbookPart();
                    wBookPart.Workbook = new Workbook();

                    WorkbookStylesPart stylePart = wBookPart.AddNewPart<WorkbookStylesPart>();
                    stylePart.Stylesheet = GenerateStylesheet();
                    stylePart.Stylesheet.Save();

                    uint sheetId = 1;
                    spreadsheetDoc.WorkbookPart.Workbook.Sheets = new Sheets();
                    Sheets sheets = spreadsheetDoc.WorkbookPart.Workbook.GetFirstChild<Sheets>();

                    foreach (DataTable table in tableSet.Tables)
                    {
                        WorksheetPart wSheetPart = wBookPart.AddNewPart<WorksheetPart>();
                        Sheet sheet = new Sheet() { Id = spreadsheetDoc.WorkbookPart.GetIdOfPart(wSheetPart), SheetId = sheetId, Name = table.TableName + "-" + sheetId };
                        sheets.Append(sheet);
                        SheetData sheetData = new SheetData();
                        wSheetPart.Worksheet = new Worksheet(sheetData);
                        if (table.TableName == "SourceUserCntType")
                        {
                            Row headerRow = new Row();
                            headerRow.Append(

                                  ConstructCell("SourceUrl", CellValues.String, 0),
                                  ConstructCell("SourceCntTypeName", CellValues.String, 0));

                            sheetData.AppendChild(headerRow);
                            for (int i = 0; i < table.Rows.Count; i++)
                            {
                                Row row = new Row();
                                row.Append(
                                            ConstructCell(table.Rows[i]["SourceUrl"].ToString(), CellValues.String, 0),
                                            ConstructCell(table.Rows[i]["SourceCntTypeName"].ToString(), CellValues.String, 0));
                                sheetData.AppendChild(row);
                            }
                        }
                        if (table.TableName == "TargetCntType")
                        {
                            Row headerRow = new Row();
                            headerRow.Append(

                                  ConstructCell("TargeteUrl", CellValues.String, 0),
                                  ConstructCell("TargetCntTypeName", CellValues.String, 0));
                            sheetData.AppendChild(headerRow);

                            for (int i = 0; i < table.Rows.Count; i++)
                            {
                                Row row = new Row();
                                row.Append(
                                            ConstructCell(table.Rows[i]["TargeteUrl"].ToString(), CellValues.String, 0),
                                            ConstructCell(table.Rows[i]["TargetCntTypeName"].ToString(), CellValues.String, 0));
                                sheetData.AppendChild(row);
                            }
                        }
                        if (table.TableName == "CntTypeComparsion")
                        {
                            Row headerRow = new Row();
                            headerRow.Append(
                                  ConstructCell("SourceUrl", CellValues.Number, 0),
                                  ConstructCell("SourceCntTypeName", CellValues.String, 0),
                                  ConstructCell("TargeteUrl", CellValues.String, 0),
                                  ConstructCell("TargetCntTypeName", CellValues.Number, 0));
                            sheetData.AppendChild(headerRow);

                            for (int i = 0; i < table.Rows.Count; i++)
                            {
                                Row row = new Row();
                                if (string.IsNullOrEmpty(table.Rows[i]["SourceCntTypeName"].ToString()))
                                {
                                    row.Append(ConstructCell(table.Rows[i]["SourceUrl"].ToString(), CellValues.String, 2),
                                           ConstructCell(table.Rows[i]["SourceCntTypeName"].ToString(), CellValues.String, 2),
                                           ConstructCell(table.Rows[i]["TargeteUrl"].ToString(), CellValues.String, 0),
                                           ConstructCell(table.Rows[i]["TargetCntTypeName"].ToString(), CellValues.String, 0));
                                }
                                else if (string.IsNullOrEmpty(table.Rows[i]["TargetCntTypeName"].ToString()))
                                {
                                    row.Append(ConstructCell(table.Rows[i]["SourceUrl"].ToString(), CellValues.String, 0),
                                          ConstructCell(table.Rows[i]["SourceCntTypeName"].ToString(), CellValues.String, 0),
                                          ConstructCell(table.Rows[i]["TargeteUrl"].ToString(), CellValues.String, 2),
                                          ConstructCell(table.Rows[i]["TargetCntTypeName"].ToString(), CellValues.String, 2));
                                }

                                sheetData.AppendChild(row);
                            }
                        }

                        sheetId++;
                    }


                }

            }
            catch (Exception ex)
            {
                _logger.ErrorFormat("Error Message: {0}", ex.Message.ToString());
            }
            return true;
        }
        public bool CreateExcelDocumentFormatingWebparts(DataTable dtsource, DataTable dttarget, DataTable dtCmpCntType, string xlsxFilePath)
        {
            tableSet = new DataSet();

            if (dtsource != null)
            {
                dtsource.TableName = "SourceWebPart";
                tableSet.Tables.Add(dtsource);
            }
            if (dttarget != null)
            {
                dttarget.TableName = "TargetWebPart";
                tableSet.Tables.Add(dttarget);
            }
            if (dtCmpCntType != null)
            {
                dtCmpCntType.TableName = "WebpartComparsion";
                tableSet.Tables.Add(dtCmpCntType);
            }
            WorkbookPart wBookPart = null;
            try
            {

                using (SpreadsheetDocument spreadsheetDoc = SpreadsheetDocument.Create(xlsxFilePath, SpreadsheetDocumentType.Workbook))
                {
                    wBookPart = spreadsheetDoc.AddWorkbookPart();
                    wBookPart.Workbook = new Workbook();

                    WorkbookStylesPart stylePart = wBookPart.AddNewPart<WorkbookStylesPart>();
                    stylePart.Stylesheet = GenerateStylesheet();
                    stylePart.Stylesheet.Save();

                    uint sheetId = 1;
                    spreadsheetDoc.WorkbookPart.Workbook.Sheets = new Sheets();
                    Sheets sheets = spreadsheetDoc.WorkbookPart.Workbook.GetFirstChild<Sheets>();

                    foreach (DataTable table in tableSet.Tables)
                    {
                        WorksheetPart wSheetPart = wBookPart.AddNewPart<WorksheetPart>();
                        Sheet sheet = new Sheet() { Id = spreadsheetDoc.WorkbookPart.GetIdOfPart(wSheetPart), SheetId = sheetId, Name = table.TableName + "-" + sheetId };
                        sheets.Append(sheet);
                        SheetData sheetData = new SheetData();
                        wSheetPart.Worksheet = new Worksheet(sheetData);
                        if (table.TableName == "SourceWebPart")
                        {
                            Row headerRow = new Row();
                            headerRow.Append(
                                  ConstructCell("SourceUrl", CellValues.String, 0),
                                  ConstructCell("srcWebpartName", CellValues.String, 0),
                                  ConstructCell("WebpartUrl", CellValues.String, 0),
                                  ConstructCell("WebpartIsClosed", CellValues.String, 0));

                            sheetData.AppendChild(headerRow);
                            for (int i = 0; i < table.Rows.Count; i++)
                            {
                                Row row = new Row();
                                row.Append(ConstructCell(table.Rows[i]["SourceUrl"].ToString(), CellValues.String, 0),
                                            ConstructCell(table.Rows[i]["srcWebpartName"].ToString(), CellValues.String, 0),
                                            ConstructCell(table.Rows[i]["WebpartUrl"].ToString(), CellValues.String, 0),
                                            ConstructCell(table.Rows[i]["WebpartIsClosed"].ToString(), CellValues.String, 0));
                                sheetData.AppendChild(row);
                            }
                        }
                        if (table.TableName == "TargetWebPart")
                        {
                            Row headerRow = new Row();
                            headerRow.Append(

                                  ConstructCell("TargeteUrl", CellValues.String, 0),
                                  ConstructCell("desWebpartName", CellValues.String, 0),
                                  ConstructCell("WebpartUrl", CellValues.String, 0), ConstructCell("WebpartIsClosed", CellValues.String, 0));
                            sheetData.AppendChild(headerRow);

                            for (int i = 0; i < table.Rows.Count; i++)
                            {
                                Row row = new Row();
                                row.Append(ConstructCell(table.Rows[i]["TargeteUrl"].ToString(), CellValues.String, 0),
                                            ConstructCell(table.Rows[i]["desWebpartName"].ToString(), CellValues.String, 0),
                                            ConstructCell(table.Rows[i]["WebpartUrl"].ToString(), CellValues.String, 0),
                                            ConstructCell(table.Rows[i]["WebpartIsClosed"].ToString(), CellValues.String, 0));
                                sheetData.AppendChild(row);
                            }
                        }
                        if (table.TableName == "WebpartComparsion")
                        {
                            Row headerRow = new Row();
                            headerRow.Append(
                                  ConstructCell("SourceUrl", CellValues.String, 0),
                                  ConstructCell("srcWebpartName", CellValues.String, 0),
                                  ConstructCell("WebpartUrl", CellValues.String, 0),
                                  ConstructCell("TargeteUrl", CellValues.String, 0),
                                  ConstructCell("desWebpartName", CellValues.String, 0),
                                  ConstructCell("TargetWebpartUrl", CellValues.String, 0));
                            sheetData.AppendChild(headerRow);

                            for (int i = 0; i < table.Rows.Count; i++)
                            {
                                Row row = new Row();
                                if (string.IsNullOrEmpty(table.Rows[i]["WebpartUrl"].ToString()))
                                {
                                    if (table.Rows[i]["srcWebpartName"].ToString() == "FDMigrationBanner")
                                    {

                                    }
                                    else
                                    {
                                        row.Append(ConstructCell(table.Rows[i]["WebpartUrl"].ToString(), CellValues.String, 2),
                                          ConstructCell(table.Rows[i]["srcWebpartName"].ToString(), CellValues.String, 2),
                                          ConstructCell(table.Rows[i]["WebpartUrl"].ToString(), CellValues.String, 2),
                                          ConstructCell(table.Rows[i]["TargeteUrl"].ToString(), CellValues.String, 0),
                                           ConstructCell(table.Rows[i]["desWebpartName"].ToString(), CellValues.String, 0),
                                            ConstructCell(table.Rows[i]["TargetWebpartUrl"].ToString(), CellValues.String, 0));
                                    }

                                }
                                else if (string.IsNullOrEmpty(table.Rows[i]["TargetWebpartUrl"].ToString()))
                                {
                                    row.Append(ConstructCell(table.Rows[i]["WebpartUrl"].ToString(), CellValues.String, 0),
                                          ConstructCell(table.Rows[i]["srcWebpartName"].ToString(), CellValues.String, 0),
                                          ConstructCell(table.Rows[i]["WebpartUrl"].ToString(), CellValues.String, 0),
                                          ConstructCell(table.Rows[i]["TargeteUrl"].ToString(), CellValues.String, 2),
                                           ConstructCell(table.Rows[i]["desWebpartName"].ToString(), CellValues.String, 2),
                                            ConstructCell(table.Rows[i]["TargetWebpartUrl"].ToString(), CellValues.String, 2));
                                }

                                sheetData.AppendChild(row);
                            }
                        }

                        sheetId++;
                    }


                }

            }
            catch (Exception ex)
            {
                _logger.ErrorFormat("Error Message: {0}", ex.Message.ToString());
            }
            return true;
        }
        public bool CreateExcelDocumentFormatingFolderLevelPermission(DataTable dtsource, DataTable dttarget, DataTable dtfldComp, string xlsxFilePath)
        {
            tableSet = new DataSet();

            if (dtsource != null)
            {
                dtsource.TableName = "SourceFolderLevel";
                tableSet.Tables.Add(dtsource);
            }
            if (dttarget != null)
            {
                dttarget.TableName = "TargetFolderLevel";
                tableSet.Tables.Add(dttarget);
            }
            if (dtfldComp != null)
            {
                dtfldComp.TableName = "FolderLevelPermission";
                tableSet.Tables.Add(dtfldComp);
            }

            WorkbookPart wBookPart = null;
            try
            {

                using (SpreadsheetDocument spreadsheetDoc = SpreadsheetDocument.Create(xlsxFilePath, SpreadsheetDocumentType.Workbook))
                {
                    wBookPart = spreadsheetDoc.AddWorkbookPart();
                    wBookPart.Workbook = new Workbook();

                    WorkbookStylesPart stylePart = wBookPart.AddNewPart<WorkbookStylesPart>();
                    stylePart.Stylesheet = GenerateStylesheet();
                    stylePart.Stylesheet.Save();

                    uint sheetId = 1;
                    spreadsheetDoc.WorkbookPart.Workbook.Sheets = new Sheets();
                    Sheets sheets = spreadsheetDoc.WorkbookPart.Workbook.GetFirstChild<Sheets>();

                    foreach (DataTable table in tableSet.Tables)
                    {
                        WorksheetPart wSheetPart = wBookPart.AddNewPart<WorksheetPart>();
                        Sheet sheet = new Sheet() { Id = spreadsheetDoc.WorkbookPart.GetIdOfPart(wSheetPart), SheetId = sheetId, Name = table.TableName + "-" + sheetId };
                        sheets.Append(sheet);
                        SheetData sheetData = new SheetData();
                        wSheetPart.Worksheet = new Worksheet(sheetData);
                        if (table.TableName == "SourceFolderLevel")
                        {
                            Row headerRow = new Row();
                            headerRow.Append(
                                  ConstructCell("SourceUrl", CellValues.String, 0),
                                  ConstructCell("SrcLibraryName", CellValues.String, 0),
                                  ConstructCell("SrcFolderName", CellValues.String, 0),
                                  ConstructCell("FileRef", CellValues.String, 0),
                                  ConstructCell("User/Group", CellValues.String, 0),
                                  ConstructCell("UserPrincipalName", CellValues.String, 0),
                                   ConstructCell("SrcPermissions", CellValues.String, 0),
                                   ConstructCell("HasUnique", CellValues.String, 0));

                            sheetData.AppendChild(headerRow);
                            for (int i = 0; i < table.Rows.Count; i++)
                            {
                                Row row = new Row();
                                row.Append(ConstructCell(table.Rows[i]["SourceUrl"].ToString(), CellValues.String, 0),
                                            ConstructCell(table.Rows[i]["SrcLibraryName"].ToString(), CellValues.String, 0),
                                            ConstructCell(table.Rows[i]["SrcFolderName"].ToString(), CellValues.String, 0),
                                            ConstructCell(table.Rows[i]["FileRef"].ToString(), CellValues.String, 0),
                                            ConstructCell(table.Rows[i]["User/Group"].ToString(), CellValues.String, 0),
                                            ConstructCell(table.Rows[i]["UserPrincipalName"].ToString(), CellValues.String, 0),
                                            ConstructCell(table.Rows[i]["SrcPermissions"].ToString(), CellValues.String, 0),
                                            ConstructCell(table.Rows[i]["HasUnique"].ToString(), CellValues.String, 0));
                                sheetData.AppendChild(row);
                            }
                        }
                        if (table.TableName == "TargetFolderLevel")
                        {
                            Row headerRow = new Row();
                            headerRow.Append(
                                  ConstructCell("TargetUrl", CellValues.String, 0),
                                  ConstructCell("DesLibraryName", CellValues.String, 0),
                                   ConstructCell("DesFolderName", CellValues.String, 0),
                                  ConstructCell("FileRef", CellValues.String, 0),
                                  ConstructCell("User/Group", CellValues.String, 0),
                                  ConstructCell("SAMAccountName", CellValues.String, 0),
                                   ConstructCell("DesPermissions", CellValues.String, 0),
                                   ConstructCell("HasUnique", CellValues.String, 0));
                            sheetData.AppendChild(headerRow);

                            for (int i = 0; i < table.Rows.Count; i++)
                            {
                                Row row = new Row();
                                row.Append(ConstructCell(table.Rows[i]["TargetUrl"].ToString(), CellValues.String, 0),
                                            ConstructCell(table.Rows[i]["DesLibraryName"].ToString(), CellValues.String, 0),
                                            ConstructCell(table.Rows[i]["DesFolderName"].ToString(), CellValues.String, 0),
                                            ConstructCell(table.Rows[i]["FileRef"].ToString(), CellValues.String, 0),
                                            ConstructCell(table.Rows[i]["User/Group"].ToString(), CellValues.String, 0),
                                            ConstructCell(table.Rows[i]["SAMAccountName"].ToString(), CellValues.String, 0),
                                            ConstructCell(table.Rows[i]["DesPermissions"].ToString(), CellValues.String, 0),
                                            ConstructCell(table.Rows[i]["HasUnique"].ToString(), CellValues.String, 0));
                                sheetData.AppendChild(row);
                            }
                        }

                        if (table.TableName == "FolderLevelPermission")
                        {
                            Row headerRow = new Row();
                            headerRow.Append(
                                  ConstructCell("SourceUrl", CellValues.String, 0),
                                  ConstructCell("SrcLibraryName", CellValues.String, 0),
                                  ConstructCell("SrcFolderName", CellValues.String, 0),
                                  ConstructCell("SrcFileRef", CellValues.String, 0),
                                  ConstructCell("SrcUser/Group", CellValues.String, 0),
                                  ConstructCell("UserPrincipalName", CellValues.String, 0),
                                  ConstructCell("SrcPermissions", CellValues.String, 0),
                                    ConstructCell("TargetUrl", CellValues.String, 0),
                                     ConstructCell("DesLibraryName", CellValues.String, 0),
                                     ConstructCell("DesFolderName", CellValues.String, 0),
                                      ConstructCell("DesFileRef", CellValues.String, 0),
                                       ConstructCell("DesUser/Group", CellValues.String, 0),
                                       ConstructCell("SAMAccountName", CellValues.String, 0),
                                        ConstructCell("DesPermissions", CellValues.String, 0));

                            sheetData.AppendChild(headerRow);

                            for (int i = 0; i < table.Rows.Count; i++)
                            {
                                Row row = new Row();
                                if (string.IsNullOrEmpty(table.Rows[i]["DesFolderName"].ToString()))
                                {
                                    row.Append(ConstructCell(table.Rows[i]["SourceUrl"].ToString(), CellValues.String, 0),
                                            ConstructCell(table.Rows[i]["SrcLibraryName"].ToString(), CellValues.String, 0),
                                            ConstructCell(table.Rows[i]["SrcFolderName"].ToString(), CellValues.String, 0),
                                            ConstructCell(table.Rows[i]["SrcFileRef"].ToString(), CellValues.String, 0),
                                            ConstructCell(table.Rows[i]["SrcUser/Group"].ToString(), CellValues.String, 0),
                                            ConstructCell(table.Rows[i]["UserPrincipalName"].ToString(), CellValues.String, 0),
                                            ConstructCell(table.Rows[i]["SrcPermissions"].ToString(), CellValues.String, 0),

                                             ConstructCell(table.Rows[i]["TargetUrl"].ToString(), CellValues.String, 2),
                                              ConstructCell(table.Rows[i]["DesLibraryName"].ToString(), CellValues.String, 2),
                                              ConstructCell(table.Rows[i]["DesFolderName"].ToString(), CellValues.String, 2),
                                              ConstructCell(table.Rows[i]["DesFileRef"].ToString(), CellValues.String, 2),
                                               ConstructCell(table.Rows[i]["DesUser/Group"].ToString(), CellValues.String, 2),
                                               ConstructCell(table.Rows[i]["SAMAccountName"].ToString(), CellValues.String, 2),
                                               ConstructCell(table.Rows[i]["DesPermissions"].ToString(), CellValues.String, 2));
                                }
                                else if (string.IsNullOrEmpty(table.Rows[i]["SrcFolderName"].ToString()))
                                {
                                    row.Append(ConstructCell(table.Rows[i]["SourceUrl"].ToString(), CellValues.String, 2),
                                            ConstructCell(table.Rows[i]["SrcLibraryName"].ToString(), CellValues.String, 2),
                                            ConstructCell(table.Rows[i]["SrcFolderName"].ToString(), CellValues.String, 2),
                                            ConstructCell(table.Rows[i]["SrcFileRef"].ToString(), CellValues.String, 2),
                                            ConstructCell(table.Rows[i]["SrcUser/Group"].ToString(), CellValues.String, 2),
                                            ConstructCell(table.Rows[i]["UserPrincipalName"].ToString(), CellValues.String, 2),
                                            ConstructCell(table.Rows[i]["SrcPermissions"].ToString(), CellValues.String, 2),

                                             ConstructCell(table.Rows[i]["TargetUrl"].ToString(), CellValues.String, 0),
                                              ConstructCell(table.Rows[i]["DesLibraryName"].ToString(), CellValues.String, 0),
                                              ConstructCell(table.Rows[i]["DesFolderName"].ToString(), CellValues.String, 0),
                                              ConstructCell(table.Rows[i]["DesFileRef"].ToString(), CellValues.String, 0),
                                               ConstructCell(table.Rows[i]["DesUser/Group"].ToString(), CellValues.String, 0),
                                               ConstructCell(table.Rows[i]["SAMAccountName"].ToString(), CellValues.String, 0),
                                               ConstructCell(table.Rows[i]["DesPermissions"].ToString(), CellValues.String, 0));
                                }

                                sheetData.AppendChild(row);
                            }
                        }
                        sheetId++;
                    }


                }

            }
            catch (Exception ex)
            {
                _logger.ErrorFormat("Error Message: {0}", ex.Message.ToString());
            }
            return true;
        }
        public bool CreateExcelDocumentFormatingItemlLevelPermission(DataTable dtsource, DataTable dttarget, DataTable dtuserssum, string xlsxFilePath)
        {
            tableSet = new DataSet();

            if (dtsource != null)
            {
                dtsource.TableName = "SourceUserLevel";
                tableSet.Tables.Add(dtsource);
            }
            if (dttarget != null)
            {
                dttarget.TableName = "TargetUserLevel";
                tableSet.Tables.Add(dttarget);
            }
            if (dtuserssum != null)
            {
                dtuserssum.TableName = "ItemLevelPermission";
                tableSet.Tables.Add(dtuserssum);
            }

            WorkbookPart wBookPart = null;
            try
            {

                using (SpreadsheetDocument spreadsheetDoc = SpreadsheetDocument.Create(xlsxFilePath, SpreadsheetDocumentType.Workbook))
                {
                    wBookPart = spreadsheetDoc.AddWorkbookPart();
                    wBookPart.Workbook = new Workbook();

                    WorkbookStylesPart stylePart = wBookPart.AddNewPart<WorkbookStylesPart>();
                    stylePart.Stylesheet = GenerateStylesheet();
                    stylePart.Stylesheet.Save();

                    uint sheetId = 1;
                    spreadsheetDoc.WorkbookPart.Workbook.Sheets = new Sheets();
                    Sheets sheets = spreadsheetDoc.WorkbookPart.Workbook.GetFirstChild<Sheets>();

                    foreach (DataTable table in tableSet.Tables)
                    {
                        WorksheetPart wSheetPart = wBookPart.AddNewPart<WorksheetPart>();
                        Sheet sheet = new Sheet() { Id = spreadsheetDoc.WorkbookPart.GetIdOfPart(wSheetPart), SheetId = sheetId, Name = table.TableName + "-" + sheetId };
                        sheets.Append(sheet);
                        SheetData sheetData = new SheetData();
                        wSheetPart.Worksheet = new Worksheet(sheetData);
                        if (table.TableName == "SourceUserLevel")
                        {
                            Row headerRow = new Row();
                            headerRow.Append(
                                  ConstructCell("SourceUrl", CellValues.String, 0),
                                  ConstructCell("SrcLibraryName", CellValues.String, 0),
                                  ConstructCell("FileRef", CellValues.String, 0),
                                  ConstructCell("FileName", CellValues.String, 0),
                                  ConstructCell("User/Group", CellValues.String, 0),
                                  ConstructCell("UserPrincipalName", CellValues.String, 0),
                                   ConstructCell("SrcPermissions", CellValues.String, 0),
                                   ConstructCell("HasUnique", CellValues.String, 0)
                                   );


                            sheetData.AppendChild(headerRow);
                            for (int i = 0; i < table.Rows.Count; i++)
                            {
                                Row row = new Row();
                                row.Append(ConstructCell(table.Rows[i]["SourceUrl"].ToString(), CellValues.String, 0),
                                            ConstructCell(table.Rows[i]["SrcLibraryName"].ToString(), CellValues.String, 0),
                                            ConstructCell(table.Rows[i]["FileRef"].ToString(), CellValues.String, 0),
                                            ConstructCell(table.Rows[i]["FileName"].ToString(), CellValues.String, 0),
                                            ConstructCell(table.Rows[i]["User/Group"].ToString(), CellValues.String, 0),
                                            ConstructCell(table.Rows[i]["UserPrincipalName"].ToString(), CellValues.String, 0),
                                            ConstructCell(table.Rows[i]["SrcPermissions"].ToString(), CellValues.String, 0),
                                            ConstructCell(table.Rows[i]["HasUnique"].ToString(), CellValues.String, 0)
                                            );
                                sheetData.AppendChild(row);
                            }
                        }
                        if (table.TableName == "TargetUserLevel")
                        {
                            Row headerRow = new Row();
                            headerRow.Append(
                                  ConstructCell("TargetUrl", CellValues.String, 0),
                                  ConstructCell("DesLibraryName", CellValues.String, 0),
                                  ConstructCell("FileRef", CellValues.String, 0),
                                  ConstructCell("FileName", CellValues.String, 0),
                                  ConstructCell("DesUsersGroups", CellValues.String, 0),
                                  ConstructCell("SAMAccountName", CellValues.String, 0),
                                   ConstructCell("DesPermissions", CellValues.String, 0),
                                   ConstructCell("HasUnique", CellValues.String, 0)
                                  );
                            sheetData.AppendChild(headerRow);

                            for (int i = 0; i < table.Rows.Count; i++)
                            {
                                Row row = new Row();
                                row.Append(ConstructCell(table.Rows[i]["TargetUrl"].ToString(), CellValues.String, 0),
                                            ConstructCell(table.Rows[i]["DesLibraryName"].ToString(), CellValues.String, 0),
                                            ConstructCell(table.Rows[i]["FileRef"].ToString(), CellValues.String, 0),
                                            ConstructCell(table.Rows[i]["FileName"].ToString(), CellValues.String, 0),
                                            ConstructCell(table.Rows[i]["DesUsersGroups"].ToString(), CellValues.String, 0),
                                            ConstructCell(table.Rows[i]["SAMAccountName"].ToString(), CellValues.String, 0),
                                            ConstructCell(table.Rows[i]["DesPermissions"].ToString(), CellValues.String, 0),
                                            ConstructCell(table.Rows[i]["HasUnique"].ToString(), CellValues.String, 0)
                                             );
                                sheetData.AppendChild(row);
                            }
                        }

                        if (table.TableName == "ItemLevelPermission")
                        {
                            Row headerRow = new Row();
                            headerRow.Append(
                                  ConstructCell("SourceUrl", CellValues.String, 0),
                                  ConstructCell("SrcLibraryName", CellValues.String, 0),
                                  ConstructCell("SrcFileRef", CellValues.String, 0),
                                  ConstructCell("SrcUser/Group", CellValues.String, 0),
                                   ConstructCell("UserPrincipalName", CellValues.String, 0),
                                  ConstructCell("SrcPermissions", CellValues.String, 0),


                                    ConstructCell("TargetUrl", CellValues.String, 0),
                                     ConstructCell("DesLibraryName", CellValues.String, 0),
                                      ConstructCell("DesFileRef", CellValues.String, 0),
                                       ConstructCell("DesUser/Group", CellValues.String, 0),
                                       ConstructCell("SAMAccountName", CellValues.String, 0),
                                        ConstructCell("DesPermissions", CellValues.String, 0)
                                        );

                            sheetData.AppendChild(headerRow);

                            for (int i = 0; i < table.Rows.Count; i++)
                            {
                                Row row = new Row();
                                if (string.IsNullOrEmpty(table.Rows[i]["DesUser/Group"].ToString()))
                                {
                                    row.Append(ConstructCell(table.Rows[i]["SourceUrl"].ToString(), CellValues.String, 0),
                                            ConstructCell(table.Rows[i]["SrcLibraryName"].ToString(), CellValues.String, 0),
                                            ConstructCell(table.Rows[i]["SrcFileRef"].ToString(), CellValues.String, 0),
                                            ConstructCell(table.Rows[i]["SrcUser/Group"].ToString(), CellValues.String, 0),
                                            ConstructCell(table.Rows[i]["UserPrincipalName"].ToString(), CellValues.String, 0),
                                            ConstructCell(table.Rows[i]["SrcPermissions"].ToString(), CellValues.String, 0),


                                             ConstructCell(table.Rows[i]["TargetUrl"].ToString(), CellValues.String, 2),
                                              ConstructCell(table.Rows[i]["DesLibraryName"].ToString(), CellValues.String, 2),
                                              ConstructCell(table.Rows[i]["DesFileRef"].ToString(), CellValues.String, 2),
                                               ConstructCell(table.Rows[i]["DesUser/Group"].ToString(), CellValues.String, 2),
                                               ConstructCell(table.Rows[i]["SAMAccountName"].ToString(), CellValues.String, 2),
                                               ConstructCell(table.Rows[i]["DesPermissions"].ToString(), CellValues.String, 2)
                                                );
                                }
                                else if (string.IsNullOrEmpty(table.Rows[i]["UserPrincipalName"].ToString()))
                                {
                                    row.Append(ConstructCell(table.Rows[i]["SourceUrl"].ToString(), CellValues.String, 2),
                                            ConstructCell(table.Rows[i]["SrcLibraryName"].ToString(), CellValues.String, 2),
                                            ConstructCell(table.Rows[i]["SrcFileRef"].ToString(), CellValues.String, 2),
                                            ConstructCell(table.Rows[i]["SrcUser/Group"].ToString(), CellValues.String, 2),
                                            ConstructCell(table.Rows[i]["UserPrincipalName"].ToString(), CellValues.String, 2),
                                            ConstructCell(table.Rows[i]["SrcPermissions"].ToString(), CellValues.String, 2),


                                             ConstructCell(table.Rows[i]["TargetUrl"].ToString(), CellValues.String, 0),
                                              ConstructCell(table.Rows[i]["DesLibraryName"].ToString(), CellValues.String, 0),
                                              ConstructCell(table.Rows[i]["DesFileRef"].ToString(), CellValues.String, 0),
                                               ConstructCell(table.Rows[i]["DesUser/Group"].ToString(), CellValues.String, 0),
                                                ConstructCell(table.Rows[i]["SAMAccountName"].ToString(), CellValues.String, 0),
                                               ConstructCell(table.Rows[i]["DesPermissions"].ToString(), CellValues.String, 0)
                                              );
                                }

                                sheetData.AppendChild(row);
                            }
                        }

                        sheetId++;
                    }


                }

            }
            catch (Exception ex)
            {
                _logger.ErrorFormat("Error Message: {0}", ex.Message.ToString());
            }
            return true;
        }
        public bool CreateExcelDocumentFormatingFeature(DataTable dtFeature, string xlsxFilePath)
        {
            tableSet = new DataSet();
            if (dtFeature != null)
            {
                dtFeature.TableName = "FeatureCmp";
                tableSet.Tables.Add(dtFeature);
            }

            WorkbookPart wBookPart = null;
            try
            {

                using (SpreadsheetDocument spreadsheetDoc = SpreadsheetDocument.Create(xlsxFilePath, SpreadsheetDocumentType.Workbook))
                {
                    wBookPart = spreadsheetDoc.AddWorkbookPart();
                    wBookPart.Workbook = new Workbook();

                    WorkbookStylesPart stylePart = wBookPart.AddNewPart<WorkbookStylesPart>();
                    stylePart.Stylesheet = GenerateStylesheet();
                    stylePart.Stylesheet.Save();

                    uint sheetId = 1;
                    spreadsheetDoc.WorkbookPart.Workbook.Sheets = new Sheets();
                    Sheets sheets = spreadsheetDoc.WorkbookPart.Workbook.GetFirstChild<Sheets>();

                    foreach (DataTable table in tableSet.Tables)
                    {
                        WorksheetPart wSheetPart = wBookPart.AddNewPart<WorksheetPart>();
                        Sheet sheet = new Sheet() { Id = spreadsheetDoc.WorkbookPart.GetIdOfPart(wSheetPart), SheetId = sheetId, Name = table.TableName + "-" + sheetId };
                        sheets.Append(sheet);
                        SheetData sheetData = new SheetData();
                        wSheetPart.Worksheet = new Worksheet(sheetData);


                        if (table.TableName == "FeatureCmp")
                        {
                            Row headerRow = new Row();
                            headerRow.Append(
                                  ConstructCell("Source", CellValues.String, 0),
                                  ConstructCell("Target", CellValues.String, 0),
                                  ConstructCell("Feature Name", CellValues.String, 0));

                            sheetData.AppendChild(headerRow);

                            for (int i = 0; i < table.Rows.Count; i++)
                            {
                                Row row = new Row();
                                if (string.IsNullOrEmpty(table.Rows[i]["Source"].ToString()))
                                {
                                    row.Append(ConstructCell(table.Rows[i]["Source"].ToString(), CellValues.String, 2),
                                           ConstructCell(table.Rows[i]["Target"].ToString(), CellValues.String, 0),
                                           ConstructCell(table.Rows[i]["Feature Name"].ToString(), CellValues.String, 0));
                                }
                                else if (string.IsNullOrEmpty(table.Rows[i]["Target"].ToString()))
                                {
                                    row.Append(ConstructCell(table.Rows[i]["Source"].ToString(), CellValues.String, 0),
                                           ConstructCell(table.Rows[i]["Target"].ToString(), CellValues.String, 2),
                                           ConstructCell(table.Rows[i]["Feature Name"].ToString(), CellValues.String, 0));
                                }
                                else if (string.IsNullOrEmpty(table.Rows[i]["Feature Name"].ToString()))
                                {
                                    row.Append(ConstructCell(table.Rows[i]["Source"].ToString(), CellValues.String, 0),
                                           ConstructCell(table.Rows[i]["Target"].ToString(), CellValues.String, 0),
                                           ConstructCell(table.Rows[i]["Feature Name"].ToString(), CellValues.String, 2));
                                }
                                else
                                {
                                    row.Append(ConstructCell(table.Rows[i]["Source"].ToString(), CellValues.String, 0),
                                           ConstructCell(table.Rows[i]["Target"].ToString(), CellValues.String, 0),
                                           ConstructCell(table.Rows[i]["Feature Name"].ToString(), CellValues.String, 0));
                                }


                                sheetData.AppendChild(row);
                            }
                        }
                        sheetId++;
                    }


                }

            }
            catch (Exception ex)
            {
                _logger.ErrorFormat("Error Message: {0}", ex.Message.ToString());
            }
            return true;
        }
        public bool CreateExcelDocumentFormatingDocumetVersion(DataTable dtdoc, string xlsxFilePath)
        {
            tableSet = new DataSet();
            if (dtdoc != null)
            {
                dtdoc.TableName = "DocumentVersion";
                tableSet.Tables.Add(dtdoc);
            }

            WorkbookPart wBookPart = null;
            try
            {

                using (SpreadsheetDocument spreadsheetDoc = SpreadsheetDocument.Create(xlsxFilePath, SpreadsheetDocumentType.Workbook))
                {
                    wBookPart = spreadsheetDoc.AddWorkbookPart();
                    wBookPart.Workbook = new Workbook();

                    WorkbookStylesPart stylePart = wBookPart.AddNewPart<WorkbookStylesPart>();
                    stylePart.Stylesheet = GenerateStylesheet();
                    stylePart.Stylesheet.Save();

                    uint sheetId = 1;
                    spreadsheetDoc.WorkbookPart.Workbook.Sheets = new Sheets();
                    Sheets sheets = spreadsheetDoc.WorkbookPart.Workbook.GetFirstChild<Sheets>();

                    foreach (DataTable table in tableSet.Tables)
                    {
                        WorksheetPart wSheetPart = wBookPart.AddNewPart<WorksheetPart>();
                        Sheet sheet = new Sheet() { Id = spreadsheetDoc.WorkbookPart.GetIdOfPart(wSheetPart), SheetId = sheetId, Name = table.TableName + "-" + sheetId };
                        sheets.Append(sheet);
                        SheetData sheetData = new SheetData();
                        wSheetPart.Worksheet = new Worksheet(sheetData);


                        if (table.TableName == "DocumentVersion")
                        {
                            Row headerRow = new Row();
                            headerRow.Append(
                                  ConstructCell("Site Name", CellValues.String, 0),
                                  ConstructCell("Source", CellValues.String, 0),
                                  ConstructCell("Destination", CellValues.String, 0));

                            sheetData.AppendChild(headerRow);

                            for (int i = 0; i < table.Rows.Count; i++)
                            {
                                Row row = new Row();
                                if (string.IsNullOrEmpty(table.Rows[i]["Source"].ToString()))
                                {
                                    row.Append(ConstructCell(table.Rows[i]["Site Name"].ToString(), CellValues.String, 0),
                                            ConstructCell(table.Rows[i]["Source"].ToString(), CellValues.String, 2),
                                            ConstructCell(table.Rows[i]["Destination"].ToString(), CellValues.String, 0));
                                }
                                else if (string.IsNullOrEmpty(table.Rows[i]["Destination"].ToString()))
                                {
                                    row.Append(ConstructCell(table.Rows[i]["Site Name"].ToString(), CellValues.String, 0),
                                          ConstructCell(table.Rows[i]["Source"].ToString(), CellValues.String, 0),
                                          ConstructCell(table.Rows[i]["Destination"].ToString(), CellValues.String, 2));
                                }
                                else
                                {
                                    row.Append(ConstructCell(table.Rows[i]["Site Name"].ToString(), CellValues.String, 0),
                                           ConstructCell(table.Rows[i]["Source"].ToString(), CellValues.String, 0),
                                           ConstructCell(table.Rows[i]["Destination"].ToString(), CellValues.String, 0));
                                }


                                sheetData.AppendChild(row);
                            }
                        }
                        sheetId++;
                    }


                }

            }
            catch (Exception ex)
            {
                _logger.ErrorFormat("Error Message: {0}", ex.Message.ToString());
            }
            return true;
        }
        public bool CreateExcelDocumentFormatinggrpsPermission(DataTable dtsource, DataTable dttarget, DataTable dtgrpssum, DataTable dtgrpsMissing, string xlsxFilePath)
        {
            tableSet = new DataSet();
            if (dtsource != null)
            {
                dtsource.TableName = "SourcegrpName";
                tableSet.Tables.Add(dtsource);
            }
            if (dttarget != null)
            {
                dttarget.TableName = "TargetgrpName";
                tableSet.Tables.Add(dttarget);
            }
            if (dtgrpssum != null)
            {
                dtgrpssum.TableName = "grpPermissionMissing";
                tableSet.Tables.Add(dtgrpssum);
            }
            if (dtgrpsMissing != null)
            {
                dtgrpsMissing.TableName = "groupsMissing";
                tableSet.Tables.Add(dtgrpsMissing);
            }
            WorkbookPart wBookPart = null;
            try
            {

                using (SpreadsheetDocument spreadsheetDoc = SpreadsheetDocument.Create(xlsxFilePath, SpreadsheetDocumentType.Workbook))
                {
                    wBookPart = spreadsheetDoc.AddWorkbookPart();
                    wBookPart.Workbook = new Workbook();

                    WorkbookStylesPart stylePart = wBookPart.AddNewPart<WorkbookStylesPart>();
                    stylePart.Stylesheet = GenerateStylesheet();
                    stylePart.Stylesheet.Save();

                    uint sheetId = 1;
                    spreadsheetDoc.WorkbookPart.Workbook.Sheets = new Sheets();
                    Sheets sheets = spreadsheetDoc.WorkbookPart.Workbook.GetFirstChild<Sheets>();

                    foreach (DataTable table in tableSet.Tables)
                    {
                        WorksheetPart wSheetPart = wBookPart.AddNewPart<WorksheetPart>();
                        Sheet sheet = new Sheet() { Id = spreadsheetDoc.WorkbookPart.GetIdOfPart(wSheetPart), SheetId = sheetId, Name = table.TableName + "-" + sheetId };
                        sheets.Append(sheet);
                        SheetData sheetData = new SheetData();
                        wSheetPart.Worksheet = new Worksheet(sheetData);
                        if (table.TableName == "SourcegrpName")
                        {
                            Row headerRow = new Row();
                            headerRow.Append(
                                  ConstructCell("SourceUrl", CellValues.String, 0),
                                  ConstructCell("srcgrpName", CellValues.String, 0),
                                  ConstructCell("srcgrppermission", CellValues.String, 0),
                                  ConstructCell("HasUniqueSitepermission", CellValues.String, 0));

                            sheetData.AppendChild(headerRow);
                            for (int i = 0; i < table.Rows.Count; i++)
                            {
                                Row row = new Row();
                                row.Append(ConstructCell(table.Rows[i]["SourceUrl"].ToString(), CellValues.String, 0),
                                            ConstructCell(table.Rows[i]["srcgrpName"].ToString(), CellValues.String, 0),
                                            ConstructCell(table.Rows[i]["srcgrppermission"].ToString(), CellValues.String, 0),
                                            ConstructCell(table.Rows[i]["HasUniqueSitepermission"].ToString(), CellValues.String, 0));
                                sheetData.AppendChild(row);
                            }
                        }
                        if (table.TableName == "TargetgrpName")
                        {
                            Row headerRow = new Row();
                            headerRow.Append(
                                  ConstructCell("TargetUrl", CellValues.String, 0),
                                  ConstructCell("DesgrpName", CellValues.String, 0),
                                  ConstructCell("Desgrppermission", CellValues.String, 0),
                                  ConstructCell("HasUniqueSiteppermission", CellValues.String, 0));

                            sheetData.AppendChild(headerRow);

                            for (int i = 0; i < table.Rows.Count; i++)
                            {
                                Row row = new Row();
                                row.Append(ConstructCell(table.Rows[i]["TargetUrl"].ToString(), CellValues.String, 0),
                                            ConstructCell(table.Rows[i]["DesgrpName"].ToString(), CellValues.String, 0),
                                            ConstructCell(table.Rows[i]["Desgrppermission"].ToString(), CellValues.String, 0),
                                            ConstructCell(table.Rows[i]["HasUniqueSiteppermission"].ToString(), CellValues.String, 0));
                                sheetData.AppendChild(row);
                            }
                        }
                        if (table.TableName == "grpPermissionMissing")
                        {
                            Row headerRow = new Row();
                            headerRow.Append(
                                  ConstructCell("SourceUrl", CellValues.String, 0),
                                  ConstructCell("srcgrpName", CellValues.String, 0),
                                  ConstructCell("srcgrppermission", CellValues.String, 0),
                                  ConstructCell("TargetUrl", CellValues.String, 0),
                                  ConstructCell("DesgrpName", CellValues.String, 0),
                                   ConstructCell("Desgrppermission", CellValues.String, 0));

                            sheetData.AppendChild(headerRow);

                            for (int i = 0; i < table.Rows.Count; i++)
                            {
                                Row row = new Row();
                                if (string.IsNullOrEmpty(table.Rows[i]["srcgrpName"].ToString()))
                                {
                                    row.Append(ConstructCell(table.Rows[i]["SourceUrl"].ToString(), CellValues.String, 2),
                                           ConstructCell(table.Rows[i]["srcgrpName"].ToString(), CellValues.String, 2),
                                           ConstructCell(table.Rows[i]["srcgrppermission"].ToString(), CellValues.String, 2),
                                           ConstructCell(table.Rows[i]["TargetUrl"].ToString(), CellValues.String, 0),
                                           ConstructCell(table.Rows[i]["DesgrpName"].ToString(), CellValues.String, 0),
                                           ConstructCell(table.Rows[i]["Desgrppermission"].ToString(), CellValues.String, 0));
                                }
                                else if (string.IsNullOrEmpty(table.Rows[i]["DesgrpName"].ToString()))
                                {
                                    row.Append(ConstructCell(table.Rows[i]["SourceUrl"].ToString(), CellValues.String, 0),
                                          ConstructCell(table.Rows[i]["srcgrpName"].ToString(), CellValues.String, 0),
                                          ConstructCell(table.Rows[i]["srcgrppermission"].ToString(), CellValues.String, 0),
                                          ConstructCell(table.Rows[i]["TargetUrl"].ToString(), CellValues.String, 2),
                                          ConstructCell(table.Rows[i]["DesgrpName"].ToString(), CellValues.String, 2),
                                          ConstructCell(table.Rows[i]["Desgrppermission"].ToString(), CellValues.String, 2));
                                }

                                sheetData.AppendChild(row);
                            }
                        }
                        if (table.TableName == "groupsMissing")
                        {
                            Row headerRow = new Row();
                            headerRow.Append(
                                  ConstructCell("SourceUrl", CellValues.String, 0),
                                  ConstructCell("srcgrpName", CellValues.String, 0),
                                  ConstructCell("srcgrppermission", CellValues.String, 0),
                                  ConstructCell("TargetUrl", CellValues.String, 0),
                                  ConstructCell("DesgrpName", CellValues.String, 0),
                                   ConstructCell("Desgrppermission", CellValues.String, 0));

                            sheetData.AppendChild(headerRow);

                            for (int i = 0; i < table.Rows.Count; i++)
                            {
                                Row row = new Row();
                                if (string.IsNullOrEmpty(table.Rows[i]["srcgrpName"].ToString()))
                                {
                                    row.Append(ConstructCell(table.Rows[i]["SourceUrl"].ToString(), CellValues.String, 2),
                                           ConstructCell(table.Rows[i]["srcgrpName"].ToString(), CellValues.String, 2),
                                           ConstructCell(table.Rows[i]["srcgrppermission"].ToString(), CellValues.String, 2),
                                           ConstructCell(table.Rows[i]["TargetUrl"].ToString(), CellValues.String, 0),
                                           ConstructCell(table.Rows[i]["DesgrpName"].ToString(), CellValues.String, 0),
                                           ConstructCell(table.Rows[i]["Desgrppermission"].ToString(), CellValues.String, 0));
                                }
                                else if (string.IsNullOrEmpty(table.Rows[i]["DesgrpName"].ToString()))
                                {
                                    row.Append(ConstructCell(table.Rows[i]["SourceUrl"].ToString(), CellValues.String, 0),
                                          ConstructCell(table.Rows[i]["srcgrpName"].ToString(), CellValues.String, 0),
                                          ConstructCell(table.Rows[i]["srcgrppermission"].ToString(), CellValues.String, 0),
                                          ConstructCell(table.Rows[i]["TargetUrl"].ToString(), CellValues.String, 2),
                                          ConstructCell(table.Rows[i]["DesgrpName"].ToString(), CellValues.String, 2),
                                          ConstructCell(table.Rows[i]["Desgrppermission"].ToString(), CellValues.String, 2));
                                }

                                sheetData.AppendChild(row);
                            }
                        }
                        sheetId++;
                    }


                }

            }
            catch (Exception ex)
            {
                _logger.ErrorFormat("Error Message: {0}", ex.Message.ToString());
            }
            return true;
        }

        public bool CreateExcelDocumentFormatingWrkflow(DataTable dtsource, DataTable dttarget, DataTable dtCmp, string xlsxFilePath)
        {
            tableSet = new DataSet();

            if (dtsource != null)
            {
                dtsource.TableName = "srcwrkflw";
                tableSet.Tables.Add(dtsource);
            }
            if (dttarget != null)
            {
                dttarget.TableName = "deswrkflw";
                tableSet.Tables.Add(dttarget);
            }
            if (dtCmp != null)
            {
                dtCmp.TableName = "cmpwrkflw";
                tableSet.Tables.Add(dtCmp);
            }
            WorkbookPart wBookPart = null;
            try
            {

                using (SpreadsheetDocument spreadsheetDoc = SpreadsheetDocument.Create(xlsxFilePath, SpreadsheetDocumentType.Workbook))
                {
                    wBookPart = spreadsheetDoc.AddWorkbookPart();
                    wBookPart.Workbook = new Workbook();

                    WorkbookStylesPart stylePart = wBookPart.AddNewPart<WorkbookStylesPart>();
                    stylePart.Stylesheet = GenerateStylesheet();
                    stylePart.Stylesheet.Save();

                    uint sheetId = 1;
                    spreadsheetDoc.WorkbookPart.Workbook.Sheets = new Sheets();
                    Sheets sheets = spreadsheetDoc.WorkbookPart.Workbook.GetFirstChild<Sheets>();

                    foreach (DataTable table in tableSet.Tables)
                    {
                        WorksheetPart wSheetPart = wBookPart.AddNewPart<WorksheetPart>();
                        Sheet sheet = new Sheet() { Id = spreadsheetDoc.WorkbookPart.GetIdOfPart(wSheetPart), SheetId = sheetId, Name = table.TableName + "-" + sheetId };
                        sheets.Append(sheet);
                        SheetData sheetData = new SheetData();
                        wSheetPart.Worksheet = new Worksheet(sheetData);
                        if (table.TableName == "srcwrkflw")
                        {
                            Row headerRow = new Row();
                            headerRow.Append(

                                  ConstructCell("SiteUrl", CellValues.String, 0),
                                  ConstructCell("ListName", CellValues.String, 0),
                                  ConstructCell("WorkflowName", CellValues.String, 0),
                                  ConstructCell("WrkflwID", CellValues.String, 0));

                            sheetData.AppendChild(headerRow);
                            for (int i = 0; i < table.Rows.Count; i++)
                            {
                                Row row = new Row();
                                row.Append(
                                            ConstructCell(table.Rows[i]["SiteUrl"].ToString(), CellValues.String, 0),
                                            ConstructCell(table.Rows[i]["ListName"].ToString(), CellValues.Number, 0),
                                            ConstructCell(table.Rows[i]["WorkflowName"].ToString(), CellValues.Number, 0),
                                            ConstructCell(table.Rows[i]["WrkflwID"].ToString(), CellValues.Number, 0));
                                sheetData.AppendChild(row);
                            }
                        }
                        if (table.TableName == "deswrkflw")
                        {
                            Row headerRow = new Row();
                            headerRow.Append(

                                  ConstructCell("SiteUrl", CellValues.String, 0),
                                  ConstructCell("ListName", CellValues.String, 0),
                                  ConstructCell("WorkflowName", CellValues.String, 0),
                                  ConstructCell("WrkflwID", CellValues.String, 0));
                            sheetData.AppendChild(headerRow);

                            for (int i = 0; i < table.Rows.Count; i++)
                            {
                                Row row = new Row();
                                row.Append(
                                            ConstructCell(table.Rows[i]["SiteUrl"].ToString(), CellValues.String, 0),
                                            ConstructCell(table.Rows[i]["ListName"].ToString(), CellValues.Number, 0),
                                            ConstructCell(table.Rows[i]["WorkflowName"].ToString(), CellValues.Number, 0),
                                            ConstructCell(table.Rows[i]["WrkflwID"].ToString(), CellValues.Number, 0));
                                sheetData.AppendChild(row);
                            }
                        }
                        if (table.TableName == "cmpwrkflw")
                        {
                            Row headerRow = new Row();
                            headerRow.Append(
                                  ConstructCell("SourceUrl", CellValues.Number, 0),
                                  ConstructCell("SrclistName", CellValues.String, 0),
                                  ConstructCell("SrcWrkflwName", CellValues.String, 0),
                                  ConstructCell("DesSiteUrl", CellValues.Number, 0),
                                  ConstructCell("DeslistName", CellValues.Number, 0),
                                  ConstructCell("DesWrkflwName", CellValues.Number, 0));
                            sheetData.AppendChild(headerRow);

                            for (int i = 0; i < table.Rows.Count; i++)
                            {
                                Row row = new Row();
                                if (string.IsNullOrEmpty(table.Rows[i]["SrcWrkflwName"].ToString()))
                                {
                                    row.Append(ConstructCell(table.Rows[i]["SourceUrl"].ToString(), CellValues.Number, 2),
                                           ConstructCell(table.Rows[i]["SrclistName"].ToString(), CellValues.String, 2),
                                           ConstructCell(table.Rows[i]["SrcWrkflwName"].ToString(), CellValues.String, 2),
                                           ConstructCell(table.Rows[i]["DesSiteUrl"].ToString(), CellValues.String, 0),
                                           ConstructCell(table.Rows[i]["DeslistName"].ToString(), CellValues.Number, 0),
                                           ConstructCell(table.Rows[i]["DesWrkflwName"].ToString(), CellValues.Number, 0));
                                }
                                else if (string.IsNullOrEmpty(table.Rows[i]["DesWrkflwName"].ToString()))
                                {
                                    row.Append(ConstructCell(table.Rows[i]["SourceUrl"].ToString(), CellValues.Number, 0),
                                          ConstructCell(table.Rows[i]["SrclistName"].ToString(), CellValues.String, 0),
                                          ConstructCell(table.Rows[i]["SrcWrkflwName"].ToString(), CellValues.String, 0),
                                          ConstructCell(table.Rows[i]["DesSiteUrl"].ToString(), CellValues.String, 2),
                                          ConstructCell(table.Rows[i]["DeslistName"].ToString(), CellValues.Number, 2),
                                          ConstructCell(table.Rows[i]["DesWrkflwName"].ToString(), CellValues.Number, 2));
                                }

                                sheetData.AppendChild(row);
                            }
                        }

                        sheetId++;
                    }


                }

            }
            catch (Exception ex)
            {
                _logger.ErrorFormat("Error Message: {0}", ex.Message.ToString());
            }
            return true;
        }
        public bool CreateExcelDocumentFormatingSiteUsersPermission(DataTable dtsource, DataTable dttarget, DataTable dtuserssum, string xlsxFilePath)
        {
            tableSet = new DataSet();

            if (dtsource != null)
            {
                dtsource.TableName = "SourceSiteUsers";
                tableSet.Tables.Add(dtsource);
            }
            if (dttarget != null)
            {
                dttarget.TableName = "TargetSitesUser";
                tableSet.Tables.Add(dttarget);
            }
            if (dtuserssum != null)
            {
                dtuserssum.TableName = "SiteLevelUserPermission";
                tableSet.Tables.Add(dtuserssum);
            }

            WorkbookPart wBookPart = null;
            try
            {

                using (SpreadsheetDocument spreadsheetDoc = SpreadsheetDocument.Create(xlsxFilePath, SpreadsheetDocumentType.Workbook))
                {
                    wBookPart = spreadsheetDoc.AddWorkbookPart();
                    wBookPart.Workbook = new Workbook();

                    WorkbookStylesPart stylePart = wBookPart.AddNewPart<WorkbookStylesPart>();
                    stylePart.Stylesheet = GenerateStylesheet();
                    stylePart.Stylesheet.Save();

                    uint sheetId = 1;
                    spreadsheetDoc.WorkbookPart.Workbook.Sheets = new Sheets();
                    Sheets sheets = spreadsheetDoc.WorkbookPart.Workbook.GetFirstChild<Sheets>();

                    foreach (DataTable table in tableSet.Tables)
                    {
                        WorksheetPart wSheetPart = wBookPart.AddNewPart<WorksheetPart>();
                        Sheet sheet = new Sheet() { Id = spreadsheetDoc.WorkbookPart.GetIdOfPart(wSheetPart), SheetId = sheetId, Name = table.TableName + "-" + sheetId };
                        sheets.Append(sheet);
                        SheetData sheetData = new SheetData();
                        wSheetPart.Worksheet = new Worksheet(sheetData);
                        if (table.TableName == "SourceSiteUsers")
                        {
                            Row headerRow = new Row();
                            headerRow.Append(
                                  ConstructCell("SiteUrl", CellValues.String, 0),
                                  ConstructCell("UserLoginName", CellValues.String, 0),
                                  ConstructCell("UserEmail", CellValues.String, 0),
                                  ConstructCell("Permission", CellValues.String, 0));

                            sheetData.AppendChild(headerRow);
                            for (int i = 0; i < table.Rows.Count; i++)
                            {
                                Row row = new Row();
                                row.Append(ConstructCell(table.Rows[i]["SiteUrl"].ToString(), CellValues.String, 0),
                                            ConstructCell(table.Rows[i]["UserLoginName"].ToString(), CellValues.String, 0),
                                            ConstructCell(table.Rows[i]["UserEmail"].ToString(), CellValues.String, 0),
                                            ConstructCell(table.Rows[i]["Permission"].ToString(), CellValues.String, 0));
                                sheetData.AppendChild(row);
                            }
                        }
                        if (table.TableName == "TargetSitesUser")
                        {
                            Row headerRow = new Row();
                            headerRow.Append(
                                  ConstructCell("SiteUrl", CellValues.String, 0),
                                  ConstructCell("UserLoginName", CellValues.String, 0),
                                   ConstructCell("UserEmail", CellValues.String, 0),
                                  ConstructCell("Permission", CellValues.String, 0));
                            sheetData.AppendChild(headerRow);

                            for (int i = 0; i < table.Rows.Count; i++)
                            {
                                Row row = new Row();
                                row.Append(ConstructCell(table.Rows[i]["SiteUrl"].ToString(), CellValues.String, 0),
                                            ConstructCell(table.Rows[i]["UserLoginName"].ToString(), CellValues.String, 0),
                                            ConstructCell(table.Rows[i]["UserEmail"].ToString(), CellValues.String, 0),
                                            ConstructCell(table.Rows[i]["Permission"].ToString(), CellValues.String, 0));
                                sheetData.AppendChild(row);
                            }
                        }
                        if (table.TableName == "SiteLevelUserPermission")
                        {
                            Row headerRow = new Row();
                            headerRow.Append(
                                  ConstructCell("SourceUrl", CellValues.String, 0),
                                  ConstructCell("sourceEmail", CellValues.String, 0),
                                  ConstructCell("SourcePermission", CellValues.String, 0),
                                  ConstructCell("TargeteUrl", CellValues.String, 0),
                                  ConstructCell("TargetEmail", CellValues.String, 0),
                                  ConstructCell("TargetPermission", CellValues.String, 0));

                            sheetData.AppendChild(headerRow);

                            for (int i = 0; i < table.Rows.Count; i++)
                            {
                                Row row = new Row();
                                if (string.IsNullOrEmpty(table.Rows[i]["TargetPermission"].ToString()))
                                {
                                    row.Append(ConstructCell(table.Rows[i]["SourceUrl"].ToString(), CellValues.String, 0),
                                            ConstructCell(table.Rows[i]["sourceEmail"].ToString(), CellValues.String, 0),
                                            ConstructCell(table.Rows[i]["SourcePermission"].ToString(), CellValues.String, 0),


                                             ConstructCell(table.Rows[i]["TargeteUrl"].ToString(), CellValues.String, 2),
                                              ConstructCell(table.Rows[i]["TargetEmail"].ToString(), CellValues.String, 2),
                                              ConstructCell(table.Rows[i]["TargetPermission"].ToString(), CellValues.String, 2));
                                }
                                else if (string.IsNullOrEmpty(table.Rows[i]["SourcePermission"].ToString()))
                                {
                                    row.Append(ConstructCell(table.Rows[i]["SourceUrl"].ToString(), CellValues.String, 2),
                                             ConstructCell(table.Rows[i]["sourceEmail"].ToString(), CellValues.String, 2),
                                             ConstructCell(table.Rows[i]["SourcePermission"].ToString(), CellValues.String, 2),


                                              ConstructCell(table.Rows[i]["TargeteUrl"].ToString(), CellValues.String, 0),
                                               ConstructCell(table.Rows[i]["TargetEmail"].ToString(), CellValues.String, 0),
                                               ConstructCell(table.Rows[i]["TargetPermission"].ToString(), CellValues.String, 0));
                                }

                                sheetData.AppendChild(row);
                            }
                        }

                        sheetId++;
                    }


                }

            }
            catch (Exception ex)
            {
                _logger.ErrorFormat("Error Message: {0}", ex.Message.ToString());
            }
            return true;
        }
        
        public bool CreateExcelDocumentFormatingListassociatedcontenttype(DataTable dtsource, DataTable dttarget, DataTable dtCmpCntType, string xlsxFilePath)
        {
            tableSet = new DataSet();

            if (dtsource != null)
            {
                dtsource.TableName = "SourceList";
                tableSet.Tables.Add(dtsource);
            }
            if (dttarget != null)
            {
                dttarget.TableName = "TargetList";
                tableSet.Tables.Add(dttarget);
            }
            //if (dtCmpCntType != null)
            //{
            //    dtCmpCntType.TableName = "CompareContentType";
            //    tableSet.Tables.Add(dtCmpCntType);
            //}
            WorkbookPart wBookPart = null;
            try
            {

                using (SpreadsheetDocument spreadsheetDoc = SpreadsheetDocument.Create(xlsxFilePath, SpreadsheetDocumentType.Workbook))
                {
                    wBookPart = spreadsheetDoc.AddWorkbookPart();
                    wBookPart.Workbook = new Workbook();

                    WorkbookStylesPart stylePart = wBookPart.AddNewPart<WorkbookStylesPart>();
                    stylePart.Stylesheet = GenerateStylesheet();
                    stylePart.Stylesheet.Save();

                    uint sheetId = 1;
                    spreadsheetDoc.WorkbookPart.Workbook.Sheets = new Sheets();
                    Sheets sheets = spreadsheetDoc.WorkbookPart.Workbook.GetFirstChild<Sheets>();

                    foreach (DataTable table in tableSet.Tables)
                    {
                        WorksheetPart wSheetPart = wBookPart.AddNewPart<WorksheetPart>();
                        Sheet sheet = new Sheet() { Id = spreadsheetDoc.WorkbookPart.GetIdOfPart(wSheetPart), SheetId = sheetId, Name = table.TableName + "-" + sheetId };
                        sheets.Append(sheet);
                        SheetData sheetData = new SheetData();
                        wSheetPart.Worksheet = new Worksheet(sheetData);
                        if (table.TableName == "SourceList")
                        {
                            Row headerRow = new Row();
                            headerRow.Append(
                                  ConstructCell("SiteUrl", CellValues.String, 0),
                                  ConstructCell("ListName", CellValues.String, 0),
                                  ConstructCell("ContentTypeName", CellValues.String, 0),
                                  ConstructCell("FieldName", CellValues.String, 0));

                            sheetData.AppendChild(headerRow);
                            for (int i = 0; i < table.Rows.Count; i++)
                            {
                                Row row = new Row();
                                row.Append(ConstructCell(table.Rows[i]["SiteUrl"].ToString(), CellValues.String, 0),
                                            ConstructCell(table.Rows[i]["ListName"].ToString(), CellValues.String, 0),
                                            ConstructCell(table.Rows[i]["ContentTypeName"].ToString(), CellValues.String, 0),
                                            ConstructCell(table.Rows[i]["FieldName"].ToString(), CellValues.String, 0));
                                sheetData.AppendChild(row);
                            }
                        }
                        if (table.TableName == "TargetList")
                        {
                            Row headerRow = new Row();
                            headerRow.Append(
                                  ConstructCell("SiteUrl", CellValues.String, 0),
                                  ConstructCell("ListName", CellValues.String, 0),
                                  ConstructCell("ContentTypeName", CellValues.String, 0),
                                  ConstructCell("FieldName", CellValues.String, 0));

                            sheetData.AppendChild(headerRow);
                            for (int i = 0; i < table.Rows.Count; i++)
                            {
                                Row row = new Row();
                                row.Append(ConstructCell(table.Rows[i]["SiteUrl"].ToString(), CellValues.String, 0),
                                            ConstructCell(table.Rows[i]["ListName"].ToString(), CellValues.String, 0),
                                            ConstructCell(table.Rows[i]["ContentTypeName"].ToString(), CellValues.String, 0),
                                            ConstructCell(table.Rows[i]["FieldName"].ToString(), CellValues.String, 0));
                                sheetData.AppendChild(row);
                            }
                        }
                        //if (table.TableName == "CompareContentType")
                        //{
                        //    Row headerRow = new Row();
                        //    headerRow.Append(
                        //          ConstructCell("SiteUrl", CellValues.String, 0),
                        //          ConstructCell("ListName", CellValues.String, 0),
                        //          ConstructCell("ContentTypeName", CellValues.String, 0),
                        //          ConstructCell("FieldName", CellValues.String, 0),
                        //          ConstructCell("DesSiteUrl", CellValues.String, 0),
                        //          ConstructCell("DesListName", CellValues.String, 0),
                        //          ConstructCell("DesContentTypeName", CellValues.String, 0),
                        //          ConstructCell("DesFieldName", CellValues.String, 0));
                        //    sheetData.AppendChild(headerRow);

                        //    for (int i = 0; i < table.Rows.Count; i++)
                        //    {
                        //        Row row = new Row();
                        //        if (string.IsNullOrEmpty(table.Rows[i]["FieldName"].ToString()))
                        //        {


                        //            row.Append(ConstructCell(table.Rows[i]["SiteUrl"].ToString(), CellValues.String, 2),
                        //              ConstructCell(table.Rows[i]["ListName"].ToString(), CellValues.String, 2),
                        //              ConstructCell(table.Rows[i]["ContentTypeName"].ToString(), CellValues.String, 2),
                        //              ConstructCell(table.Rows[i]["FieldName"].ToString(), CellValues.String, 2),
                        //              ConstructCell(table.Rows[i]["DesSiteUrl"].ToString(), CellValues.String, 0),
                        //               ConstructCell(table.Rows[i]["DesListName"].ToString(), CellValues.String, 0),
                        //                ConstructCell(table.Rows[i]["DesContentTypeName"].ToString(), CellValues.String, 0),
                        //                ConstructCell(table.Rows[i]["DesFieldName"].ToString(), CellValues.String, 0));


                        //        }
                        //        else if (string.IsNullOrEmpty(table.Rows[i]["DesFieldName"].ToString()))
                        //        {
                        //            row.Append(ConstructCell(table.Rows[i]["SiteUrl"].ToString(), CellValues.String, 0),
                        //               ConstructCell(table.Rows[i]["ListName"].ToString(), CellValues.String, 0),
                        //               ConstructCell(table.Rows[i]["ContentTypeName"].ToString(), CellValues.String, 0),
                        //               ConstructCell(table.Rows[i]["FieldName"].ToString(), CellValues.String, 0),
                        //               ConstructCell(table.Rows[i]["DesSiteUrl"].ToString(), CellValues.String, 2),
                        //                ConstructCell(table.Rows[i]["DesListName"].ToString(), CellValues.String, 2),
                        //                 ConstructCell(table.Rows[i]["DesContentTypeName"].ToString(), CellValues.String, 2),
                        //                 ConstructCell(table.Rows[i]["DesFieldName"].ToString(), CellValues.String, 2));
                        //        }

                        //        sheetData.AppendChild(row);
                        //    }
                        //}

                        sheetId++;
                    }


                }

            }
            catch (Exception ex)
            {
                _logger.ErrorFormat("Error Message: {0}", ex.Message.ToString());
            }
            return true;
        }


        public bool CreateExcelDocumentFormatingListPerm(DataTable dtsource, DataTable dttarget, DataTable dtCmpCntType, string xlsxFilePath)
        {
            tableSet = new DataSet();

            if (dtsource != null)
            {
                dtsource.TableName = "SourceListPermission";
                tableSet.Tables.Add(dtsource);
            }
            if (dttarget != null)
            {
                dttarget.TableName = "TargetListPermission";
                tableSet.Tables.Add(dttarget);
            }
            if (dtCmpCntType != null)
            {
                dtCmpCntType.TableName = "ListPermissionComparison";
                tableSet.Tables.Add(dtCmpCntType);
            }
            WorkbookPart wBookPart = null;
            try
            {

                using (SpreadsheetDocument spreadsheetDoc = SpreadsheetDocument.Create(xlsxFilePath, SpreadsheetDocumentType.Workbook))
                {
                    wBookPart = spreadsheetDoc.AddWorkbookPart();
                    wBookPart.Workbook = new Workbook();

                    WorkbookStylesPart stylePart = wBookPart.AddNewPart<WorkbookStylesPart>();
                    stylePart.Stylesheet = GenerateStylesheet();
                    stylePart.Stylesheet.Save();

                    uint sheetId = 1;
                    spreadsheetDoc.WorkbookPart.Workbook.Sheets = new Sheets();
                    Sheets sheets = spreadsheetDoc.WorkbookPart.Workbook.GetFirstChild<Sheets>();

                    foreach (DataTable table in tableSet.Tables)
                    {
                        WorksheetPart wSheetPart = wBookPart.AddNewPart<WorksheetPart>();
                        Sheet sheet = new Sheet() { Id = spreadsheetDoc.WorkbookPart.GetIdOfPart(wSheetPart), SheetId = sheetId, Name = table.TableName + "-" + sheetId };
                        sheets.Append(sheet);
                        SheetData sheetData = new SheetData();
                        wSheetPart.Worksheet = new Worksheet(sheetData);
                        if (table.TableName == "SourceListPermission")
                        {
                            Row headerRow = new Row();
                            headerRow.Append(
                                  ConstructCell("SiteUrl", CellValues.String, 0),
                                  ConstructCell("ListName", CellValues.String, 0),
                                  ConstructCell("ListPermission", CellValues.String, 0),
                                  ConstructCell("Users/Group", CellValues.String, 0));

                            sheetData.AppendChild(headerRow);
                            for (int i = 0; i < table.Rows.Count; i++)
                            {
                                Row row = new Row();
                                row.Append(ConstructCell(table.Rows[i]["SiteUrl"].ToString(), CellValues.String, 0),
                                            ConstructCell(table.Rows[i]["ListName"].ToString(), CellValues.String, 0),
                                            ConstructCell(table.Rows[i]["ListPermission"].ToString(), CellValues.String, 0),
                                            ConstructCell(table.Rows[i]["Users/Group"].ToString(), CellValues.String, 0));
                                sheetData.AppendChild(row);
                            }
                        }
                        if (table.TableName == "TargetListPermission")
                        {
                            Row headerRow = new Row();
                            headerRow.Append(
                                  ConstructCell("SiteUrl", CellValues.String, 0),
                                  ConstructCell("ListName", CellValues.String, 0),
                                  ConstructCell("ListPermission", CellValues.String, 0),
                                  ConstructCell("Users/Group", CellValues.String, 0));

                            sheetData.AppendChild(headerRow);
                            for (int i = 0; i < table.Rows.Count; i++)
                            {
                                Row row = new Row();
                                row.Append(ConstructCell(table.Rows[i]["SiteUrl"].ToString(), CellValues.String, 0),
                                            ConstructCell(table.Rows[i]["ListName"].ToString(), CellValues.String, 0),
                                            ConstructCell(table.Rows[i]["ListPermission"].ToString(), CellValues.String, 0),
                                            ConstructCell(table.Rows[i]["Users/Group"].ToString(), CellValues.String, 0));
                                sheetData.AppendChild(row);
                            }
                        }
                        if (table.TableName == "ListPermissionComparison")
                        {
                            Row headerRow = new Row();
                            headerRow.Append(
                                  ConstructCell("SiteUrl", CellValues.String, 0),
                                  ConstructCell("ListName", CellValues.String, 0),
                                  ConstructCell("ListPermission", CellValues.String, 0),
                                  ConstructCell("Users/Group", CellValues.String, 0),
                                  ConstructCell("DesSiteUrl", CellValues.String, 0),
                                  ConstructCell("DesListName", CellValues.String, 0),
                                  ConstructCell("DesListPermission", CellValues.String, 0),
                                   ConstructCell("DesUsers/Group", CellValues.String, 0));
                            sheetData.AppendChild(headerRow);

                            for (int i = 0; i < table.Rows.Count; i++)
                            {
                                Row row = new Row();
                                if (string.IsNullOrEmpty(table.Rows[i]["Users/Group"].ToString()))
                                {
                                   
                                        row.Append(ConstructCell(table.Rows[i]["SiteUrl"].ToString(), CellValues.String, 2),
                                          ConstructCell(table.Rows[i]["ListName"].ToString(), CellValues.String, 2),
                                          ConstructCell(table.Rows[i]["ListPermission"].ToString(), CellValues.String, 2),
                                          ConstructCell(table.Rows[i]["Users/Group"].ToString(), CellValues.String, 2),
                                           ConstructCell(table.Rows[i]["DesSiteUrl"].ToString(), CellValues.String, 0),
                                            ConstructCell(table.Rows[i]["DesListName"].ToString(), CellValues.String, 0),
                                            ConstructCell(table.Rows[i]["DesListPermission"].ToString(), CellValues.String, 0),
                                            ConstructCell(table.Rows[i]["DesUsers/Group"].ToString(), CellValues.String, 0));
                                    

                                }
                                else if (string.IsNullOrEmpty(table.Rows[i]["DesUsers/Group"].ToString()))
                                {
                                    row.Append(ConstructCell(table.Rows[i]["SiteUrl"].ToString(), CellValues.String, 0),
                                           ConstructCell(table.Rows[i]["ListName"].ToString(), CellValues.String, 0),
                                           ConstructCell(table.Rows[i]["ListPermission"].ToString(), CellValues.String, 0),
                                           ConstructCell(table.Rows[i]["Users/Group"].ToString(), CellValues.String, 0),
                                            ConstructCell(table.Rows[i]["DesSiteUrl"].ToString(), CellValues.String, 2),
                                             ConstructCell(table.Rows[i]["DesListName"].ToString(), CellValues.String, 2),
                                             ConstructCell(table.Rows[i]["DesListPermission"].ToString(), CellValues.String, 2),
                                             ConstructCell(table.Rows[i]["DesUsers/Group"].ToString(), CellValues.String, 2));
                                }

                                sheetData.AppendChild(row);
                            }
                        }

                        sheetId++;
                    }


                }

            }
            catch (Exception ex)
            {
                _logger.ErrorFormat("Error Message: {0}", ex.Message.ToString());
            }
            return true;
        }

        private Stylesheet GenerateStylesheet()
        {
            Stylesheet styleSheet = null;

            Fills fills = new Fills(
                  new Fill(new PatternFill() { PatternType = PatternValues.None }), // Index 0 - default
                  new Fill(new PatternFill() { PatternType = PatternValues.Gray125 }), // Index 1 - default
                  new Fill(new PatternFill(new ForegroundColor { Rgb = new HexBinaryValue() { Value = "FFFFFF00" } }) { PatternType = PatternValues.Solid }), // Index 2- header 
                  new Fill(new PatternFill(new ForegroundColor { Rgb = new HexBinaryValue() { Value = "FFFA4FFF" } }) { PatternType = PatternValues.Solid }) // Index 3- header              
              );

            Fonts fonts = new Fonts(
                new Font( // Index 0 - default
                    new FontSize() { Val = 10 }

                ),
                new Font( // Index 1 - header
                    new FontSize() { Val = 10 },
                    new Bold(),
                    new Color() { Rgb = "FFFA4FFF" }

                ));

            Borders borders = new Borders(
                    new Border(), // index 0 default
                    new Border( // index 1 black border
                        new LeftBorder(new Color() { Auto = true }) { Style = BorderStyleValues.Thin },
                        new RightBorder(new Color() { Auto = true }) { Style = BorderStyleValues.Thin },
                        new TopBorder(new Color() { Auto = true }) { Style = BorderStyleValues.Thin },
                        new BottomBorder(new Color() { Auto = true }) { Style = BorderStyleValues.Thin },
                        new DiagonalBorder())
                );

            CellFormats cellFormats = new CellFormats(
                    new CellFormat(), // default
                    new CellFormat { FontId = 0, BorderId = 1, ApplyBorder = true }, // body
                    new CellFormat { FontId = 1, FillId = 2, BorderId = 1, ApplyFill = true }, // header
                    new CellFormat { FontId = 0, FillId = 2, BorderId = 1, ApplyFill = true }
                );

            styleSheet = new Stylesheet(fonts, fills, borders, cellFormats);

            return styleSheet;
        }
        private Cell ConstructCell(string value, CellValues dataType, uint styleIndex = 0)
        {

            return new Cell()
            {
                CellValue = new CellValue(value),
                DataType = new EnumValue<CellValues>(dataType),
                StyleIndex = styleIndex
            };
        }


    }
}
