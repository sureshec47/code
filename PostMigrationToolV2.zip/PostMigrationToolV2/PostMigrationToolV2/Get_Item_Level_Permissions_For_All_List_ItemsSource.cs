﻿
using Microsoft.SharePoint.Client;
using Microsoft.VisualBasic.FileIO;
using Newtonsoft.Json;
using PostMigrationToolV2.nJLibrarys;
using PostMigrationToolV2.nJLibrarysRole;
using PostMigrationToolV2.nJSubwebs;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Net.Http;
using System.Security;
using System.Text;
using System.Threading.Tasks;

namespace PostMigrationToolV2
{
    public class Get_Item_Level_Permissions_For_All_List_ItemsSource
    {
        DataTable dtsrc = new DataTable();
        DataTable dtdes = new DataTable();
        DataTable dtuserssum = new DataTable();
        DataTable dtFldsum = new DataTable();
        ExporttoExcel objExporttoExcel = new ExporttoExcel();
        Connection objConnection = new Connection();
        int srcCount = 0;
        int DesCount = 0;
        public string ContentsPath = "";
        private static readonly log4net.ILog _logger = log4net.LogManager.GetLogger(typeof(Program));
        public void getItemLevelComparison(string sourceUrl, string destUrl, string filepath, bool isFlag, string ListName,bool IsrootSite)
        {
            string url = string.Empty;
            UtliClass util = new UtliClass();
            SecureString securePassword = new SecureString();
            StringBuilder stringBuilder = new StringBuilder();
            DataTable DtDoc = new DataTable();
            try
            {
                dtsrc = new DataTable();
                dtsrc.Columns.Add("SourceUrl", typeof(string));
                dtsrc.Columns.Add("SrcLibraryName", typeof(string));
                dtsrc.Columns.Add("FileRef", typeof(string));
                dtsrc.Columns.Add("FileName", typeof(string));
                dtsrc.Columns.Add("User/Group", typeof(string));
                dtsrc.Columns.Add("UserPrincipalName", typeof(string));
                dtsrc.Columns.Add("SrcPermissions", typeof(string));
                dtsrc.Columns.Add("HasUnique", typeof(string));


                dtdes = new DataTable();
                dtdes.Columns.Add("TargetUrl", typeof(string));
                dtdes.Columns.Add("DesLibraryName", typeof(string));
                dtdes.Columns.Add("FileRef", typeof(string));
                dtdes.Columns.Add("FileName", typeof(string));
                dtdes.Columns.Add("DesUsersGroups", typeof(string));
                dtdes.Columns.Add("SAMAccountName", typeof(string));
                dtdes.Columns.Add("DesPermissions", typeof(string));
                dtdes.Columns.Add("HasUnique", typeof(string));



                util.UserName = ConfigurationSettings.AppSettings["domain"].ToString() + "\\" + ConfigurationSettings.AppSettings["SRCUserName"].ToString();
                util.Password = ConfigurationSettings.AppSettings["SRCPassword"].ToString();
                util.SPOuserName = ConfigurationSettings.AppSettings["OnlineUserName"].ToString();
                string SPOpassword = ConfigurationSettings.AppSettings["password"].ToString();
                foreach (var c in SPOpassword) securePassword.AppendChar(c);
                util.SPOpassword = securePassword;
                util.stringBuilder = stringBuilder;
                util.stringBuilder.AppendLine("Site Name,Source,Destination");
                url = "{0}/_api/web?&$select=Title";
                string jsonResponse = GetRestResult(string.Format(url, sourceUrl), util.SourcehttpClientHandler).Result;
                Newtonsoft.Json.Linq.JObject o = Newtonsoft.Json.Linq.JObject.Parse(jsonResponse);
                string siteName = Convert.ToString(o.SelectToken("d").SelectToken("Title"));
                util.stringBuilder.AppendLine(string.Format("{0},{1},{2}", siteName, sourceUrl, destUrl));
                try
                {

                    Console.WriteLine("Current Site Url:-{0},{1}", sourceUrl.ToString(), destUrl);
                    _logger.InfoFormat("Current Site Url:-{0},{1}", sourceUrl.ToString(), destUrl);
                    if (isFlag == true)
                    {
                        DocLibDiffReporter(util, sourceUrl, destUrl);
                        if (IsrootSite==false)
                        {
                            SubwebsDiffReporter(util, sourceUrl, destUrl);
                        }
                       
                        DataTable dtmlslog = new DataTable();
                        dtmlslog = GetValuesDataTabletFromCSVFile();

                        foreach (DataRow rowMasterItems in dtsrc.Rows)
                        {
                            string val = rowMasterItems["User/Group"].ToString().ToLower();
                            try
                            {
                                var results = (from row in dtmlslog.AsEnumerable()
                                               where row.Field<string>("SAMAccountName").ToString().ToLower() == val
                                               select row.Field<string>("UserPrincipalName"));
                                if (results.ToArray().Length > 0)
                                {
                                    rowMasterItems["UserPrincipalName"] = results.ToArray()[0].ToString().ToLower();
                                    rowMasterItems.AcceptChanges();
                                }
                                else
                                {
                                    rowMasterItems["UserPrincipalName"] = "not present in MLS Log Files";
                                    rowMasterItems.AcceptChanges();
                                }

                            }
                            catch (Exception ex)
                            {

                                _logger.ErrorFormat("Error in Item Level :{0},StackeTrace:{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
                                Console.WriteLine("Error in Item Level :{0},StackeTrace:{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
                            }
                        }
                        foreach (DataRow rowMasterItems in dtdes.Rows)
                        {
                            string val = rowMasterItems["DesUsersGroups"].ToString().ToLower();
                            try
                            {
                                var results = (from row in dtmlslog.AsEnumerable()
                                               where row.Field<string>("UserPrincipalName").ToString().ToLower() == val
                                               select row.Field<string>("SAMAccountName"));
                                if (results.ToArray().Length > 0)
                                {
                                    rowMasterItems["SAMAccountName"] = results.ToArray()[0].ToString().ToLower();
                                    rowMasterItems.AcceptChanges();
                                }
                                else
                                {
                                    rowMasterItems["SAMAccountName"] = "not present in MLS Log Files";
                                    rowMasterItems.AcceptChanges();
                                }

                            }
                            catch (Exception ex)
                            {

                                _logger.ErrorFormat("Error in Item Level :{0},StackeTrace:{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
                                Console.WriteLine("Error in Item Level :{0},StackeTrace:{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
                            }
                        }
                        CompareUserPermission();
                        objExporttoExcel.CreateExcelDocumentFormatingItemlLevelPermission(dtsrc, dtdes, dtuserssum, filepath);
                    }
                    if (!string.IsNullOrEmpty(ListName))
                    {
                        ItemLevelPermissionforListOnly(util, sourceUrl, destUrl, ListName);
                        DataTable dtmlslog = new DataTable();
                        dtmlslog = GetValuesDataTabletFromCSVFile();
                        string UserPrincipalName = string.Empty;

                        foreach (DataRow rowMasterItems in dtsrc.Rows)
                        {
                            string val = rowMasterItems["User/Group"].ToString().ToLower();
                            try
                            {
                                var results = (from row in dtmlslog.AsEnumerable()
                                               where row.Field<string>("SAMAccountName").ToString().ToLower() == val
                                               select row.Field<string>("UserPrincipalName"));
                                if (results.ToArray().Length > 0)
                                {
                                    rowMasterItems["UserPrincipalName"] = results.ToArray()[0].ToString().ToLower();
                                    rowMasterItems.AcceptChanges();
                                }
                                else
                                {
                                    rowMasterItems["UserPrincipalName"] = "not present in MLS Log Files";
                                    rowMasterItems.AcceptChanges();
                                }
                            }
                            catch (Exception ex)
                            {

                                _logger.ErrorFormat("Error in Item Level :{0},StackeTrace:{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
                                Console.WriteLine("Error in Item Level :{0},StackeTrace:{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
                            }
                        }
                        foreach (DataRow rowMasterItems in dtdes.Rows)
                        {
                            string val = rowMasterItems["DesUsersGroups"].ToString().ToLower();
                            try
                            {
                                var results = (from row in dtmlslog.AsEnumerable()
                                               where row.Field<string>("UserPrincipalName").ToString().ToLower() == val
                                               select row.Field<string>("SAMAccountName"));
                                if (results.ToArray().Length > 0)
                                {
                                    rowMasterItems["SAMAccountName"] = results.ToArray()[0].ToString().ToLower();
                                    rowMasterItems.AcceptChanges();
                                }
                                else
                                {
                                    rowMasterItems["SAMAccountName"] = "not present in MLS Log Files";
                                    rowMasterItems.AcceptChanges();
                                }

                            }
                            catch (Exception ex)
                            {

                                _logger.ErrorFormat("Error in Item Level :{0},StackeTrace:{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
                                Console.WriteLine("Error in Item Level :{0},StackeTrace:{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
                            }
                        }

                        CompareUserPermission();
                        objExporttoExcel.CreateExcelDocumentFormatingItemlLevelPermission(dtsrc, dtdes, dtuserssum, filepath);
                    }


                }
                catch (Exception ex)
                {
                    _logger.ErrorFormat("Error in Item Level :{0},StackeTrace:{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
                    Console.WriteLine("Error in Item Level :{0},StackeTrace:{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
                }

            }
            catch (Exception ex)
            {
                _logger.ErrorFormat("Error Message: {0}", ex.Message.ToString());
                Console.WriteLine("Error in Item Level :{0},StackeTrace:{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
            }
            // return DtDoc;
        }
        public DataTable GetValuesDataTabletFromCSVFile()
        {
            ContentsPath = ConfigurationSettings.AppSettings["MLSLogFile"];
            DataTable csvData = new DataTable();
            try
            {

                using (TextFieldParser csvReader = new TextFieldParser(ContentsPath))
                {
                    csvReader.SetDelimiters(new string[] { "," });
                    csvReader.HasFieldsEnclosedInQuotes = true;
                    //read column names
                    string[] colFields = csvReader.ReadFields();
                    foreach (string column in colFields)
                    {
                        DataColumn datecolumn = new DataColumn(column);
                        datecolumn.AllowDBNull = true;
                        csvData.Columns.Add(datecolumn);
                    }
                    while (!csvReader.EndOfData)
                    {
                        string[] fieldData = csvReader.ReadFields();
                        //Making empty value as null
                        for (int i = 0; i < fieldData.Length; i++)
                        {
                            if (fieldData[i] == "")
                            {
                                fieldData[i] = null;
                            }
                        }
                        csvData.Rows.Add(fieldData);
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.ErrorFormat("Error Message: {0}", ex.Message.ToString());
            }
            return csvData;
        }
        public void CompareUserPermission()
        {
            #region
            DataTable dtMisMatchSource =new DataTable();
            DataTable dtMisMatchTarget = new DataTable();
            try
            {
                dtMisMatchSource = (from r in dtsrc.AsEnumerable()
                                    where !dtdes.AsEnumerable().Any(r2 => r["User/Group"].ToString().Trim().ToLower() == r2["SAMAccountName"].ToString().Trim().ToLower()
                                        && r["SrcPermissions"].ToString().Trim().ToLower() == r2["DesPermissions"].ToString().Trim().ToLower()
                                        && r["FileName"].ToString().Trim().ToLower() == r2["FileName"].ToString().Trim().ToLower())
                                    select r).CopyToDataTable();



               
            }
            catch (Exception ex)
            {

                _logger.ErrorFormat("Error Message: {0}", ex.Message.ToString());

            }

            try
            {
                dtMisMatchTarget = (from r in dtdes.AsEnumerable()
                                    where !dtsrc.AsEnumerable().Any(r2 => r["SAMAccountName"].ToString().Trim().ToLower() == r2["User/Group"].ToString().Trim().ToLower()
                                        && r["DesPermissions"].ToString().Trim().ToLower() == r2["SrcPermissions"].ToString().Trim().ToLower()
                                        && r["FileName"].ToString().Trim().ToLower() == r2["FileName"].ToString().Trim().ToLower())
                                    select r).CopyToDataTable();
            }
            catch (Exception ex)
            {

                _logger.ErrorFormat("Error Message: {0}", ex.Message.ToString());
            }
           

            try
            {
               

                dtuserssum = new DataTable();
                dtuserssum.Columns.Add("SourceUrl", typeof(string));
                dtuserssum.Columns.Add("SrcLibraryName", typeof(string));
                dtuserssum.Columns.Add("SrcFileRef", typeof(string));
                dtuserssum.Columns.Add("SrcUser/Group", typeof(string));
                dtuserssum.Columns.Add("UserPrincipalName", typeof(string));
                dtuserssum.Columns.Add("SrcPermissions", typeof(string));


                dtuserssum.Columns.Add("TargetUrl", typeof(string));
                dtuserssum.Columns.Add("DesLibraryName", typeof(string));
                dtuserssum.Columns.Add("DesFileRef", typeof(string));
                dtuserssum.Columns.Add("DesUser/Group", typeof(string));
                dtuserssum.Columns.Add("SAMAccountName", typeof(string));
                dtuserssum.Columns.Add("DesPermissions", typeof(string));
                // dtuserssum.Columns.Add("HasUnique", typeof(string));


                if (dtMisMatchSource.Rows.Count > 0)
                {

                    for (int i = 0; i < dtMisMatchSource.Rows.Count; i++)
                    {

                        if (dtMisMatchSource.Rows[i]["UserPrincipalName"].ToString().ToLower() != "i:0#.f|membership|svc-SPO-MigAdmin11@firstdata.onmicrosoft.com".ToString().ToLower())
                        {
                            DataRow row = dtuserssum.NewRow();
                            row["SourceUrl"] = dtMisMatchSource.Rows[i]["SourceUrl"];
                            row["SrcLibraryName"] = dtMisMatchSource.Rows[i]["SrcLibraryName"];
                            row["SrcFileRef"] = dtMisMatchSource.Rows[i]["FileRef"];
                            row["SrcUser/Group"] = dtMisMatchSource.Rows[i]["User/Group"];
                            row["SrcPermissions"] = dtMisMatchSource.Rows[i]["SrcPermissions"];
                            row["UserPrincipalName"] = dtMisMatchSource.Rows[i]["UserPrincipalName"];
                            dtuserssum.Rows.Add(row);
                        }

                    }
                }

                if (dtMisMatchTarget.Rows.Count > 0)
                {
                    for (int i = 0; i < dtMisMatchTarget.Rows.Count; i++)
                    {
                        if (dtMisMatchTarget.Rows[i]["DesUsersGroups"].ToString().ToLower() != "i:0#.f|membership|svc-SPO-MigAdmin11@firstdata.onmicrosoft.com".ToString().ToLower())
                        {
                            DataRow row = dtuserssum.NewRow();
                            row["TargetUrl"] = dtMisMatchTarget.Rows[i]["TargetUrl"];
                            row["DesLibraryName"] = dtMisMatchTarget.Rows[i]["DesLibraryName"];
                            row["DesFileRef"] = dtMisMatchTarget.Rows[i]["FileRef"];
                            row["DesUser/Group"] = dtMisMatchTarget.Rows[i]["DesUsersGroups"];
                            row["DesPermissions"] = dtMisMatchTarget.Rows[i]["DesPermissions"];
                            row["SAMAccountName"] = dtMisMatchTarget.Rows[i]["SAMAccountName"];
                            dtuserssum.Rows.Add(row);
                        }
                    }
                }


            }
            catch (Exception ex)
            {
                _logger.ErrorFormat("Error in Item Level :{0},StackeTrace:{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
                //Console.WriteLine("Error in Item Level :{0},StackeTrace:{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
            }
            #endregion

        }
        private void SubwebsDiffReporter(UtliClass util, string sourceUrl, string destUrl)
        {
            try
            {
                string url = "{0}/_api/web/Webs?$select=Title,Url,ServerRelativeUrl";
                string temp = string.Empty;
                string jsonResponse = GetRestResult(string.Format(url, sourceUrl), util.SourcehttpClientHandler).Result;
                JSubwebs subwebsS = JsonConvert.DeserializeObject<JSubwebs>(jsonResponse);
                jsonResponse = GetRestResult(string.Format(url, destUrl), GetSPOClientHandler(string.Format(url, destUrl), util)).Result;
                JSubwebs subwebsD = JsonConvert.DeserializeObject<JSubwebs>(jsonResponse);
                IEnumerable<nJSubwebs.Result> diffsubwebs = subwebsS.d.results.Where(s => !subwebsD.d.results.Any(d => s.Title == d.Title));
                if (subwebsS.d.results.Length > 0 || subwebsD.d.results.Length > 0)
                    util.stringBuilder.AppendLine("Sub Sites,,");

                diffsubwebs = subwebsD.d.results.Where(s => !subwebsS.d.results.Any(d => s.Title == d.Title));

                diffsubwebs = subwebsS.d.results.Where(s => subwebsD.d.results.Any(d => s.Title == d.Title));
                foreach (nJSubwebs.Result result in diffsubwebs.ToArray())
                {
                    temp = result.ServerRelativeUrl.Split('/')[result.ServerRelativeUrl.Split('/').Length - 1];

                    DocLibDiffReporter(util, string.Format("{0}/{1}", sourceUrl, temp), string.Format("{0}/{1}", destUrl, temp));
                    SubwebsDiffReporter(util, string.Format("{0}/{1}", sourceUrl, temp), string.Format("{0}/{1}", destUrl, temp));
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error in Item Level :{0},StackeTrace:{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
                _logger.ErrorFormat("Error in Item Level :{0},StackeTrace:{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
            }

        }

        private void DocLibDiffReporter(UtliClass util, string sourceUrl, string destUrl)
        {
            try
            {
                util.stringBuilder.AppendLine("Document Library,,");
                string url = "{0}/_api/web/lists?$select=Title,EntityTypeName,ItemCount,id&$filter=BaseTemplate eq 101 or BaseTemplate eq 851 or BaseTemplate eq 109 or BaseTemplate eq 110 or BaseTemplate eq 130 or BaseTemplate eq 850 or BaseTemplate eq 433";
                string jsonResponse = GetRestResult(string.Format(url, sourceUrl), util.SourcehttpClientHandler).Result;
                JLibrarys jLibs = JsonConvert.DeserializeObject<JLibrarys>(jsonResponse);
                jsonResponse = GetRestResult(string.Format(url, destUrl), GetSPOClientHandler(string.Format(url, destUrl), util)).Result;
                JLibrarys jLibsd = JsonConvert.DeserializeObject<JLibrarys>(jsonResponse);
                IEnumerable<nJLibrarys.Result> diffdocLib = jLibs.d.results.Where(s => !jLibsd.d.results.Any(des => s.EntityTypeName == des.EntityTypeName));

                diffdocLib = jLibsd.d.results.Where(s => !jLibs.d.results.Any(des => s.EntityTypeName == des.EntityTypeName));

                diffdocLib = jLibsd.d.results.Where(s => jLibs.d.results.Any(des => s.EntityTypeName == des.EntityTypeName));
                foreach (nJLibrarys.Result result in diffdocLib.ToArray())
                {

                    if (int.Parse(result.ItemCount) > 0)
                    {

                        ItemLevelComparison(util, sourceUrl, destUrl, result, jLibs.d.results.Where(des => des.EntityTypeName == result.EntityTypeName).First());
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error in Item Level :{0},StackeTrace:{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
                _logger.ErrorFormat("Error in Item Level :{0},StackeTrace:{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
            }


        }

        private void ItemLevelPermissionforListOnly(UtliClass util, string sourceUrl, string destUrl, string ListName)
        {
            try
            {
                int PAGESIZE = 300;
                string temp = string.Empty;



                Console.WriteLine("Working on this List:-{0}", ListName);
                _logger.InfoFormat("Working on this List:-{0}", ListName);
                string url = "{0}/_api/web/lists/GetByTitle('{1}')/items?&$skiptoken=Paged=TRUE&$top={2}&$expand=File,RoleAssignments/Member,RoleAssignments/Member/Users,RoleAssignments/RoleDefinitionBindings&$select=RoleAssignments/Member/LoginName,RoleAssignments/RoleDefinitionBindings/Name,RoleAssignments/Member/Users,RoleAssignments/Member/Groups,HasUniqueRoleAssignments,File/ServerRelativeUrl,File/Name";
                string jsonResponse = GetRestResult(string.Format(url, sourceUrl, ListName, PAGESIZE), util.SourcehttpClientHandler).Result;
                JDocLibRole jDocS = JsonConvert.DeserializeObject<JDocLibRole>(jsonResponse);
                jDocS.d.results = jDocS.d.results.Where(s => s.File.Name != null).ToArray();
                jDocS.d.results = jDocS.d.results.Where(s => s.RoleAssignments != null).ToArray();

                foreach (var role in jDocS.d.results)
                {
                    string useremail = string.Empty;
                    if (role.HasUniqueRoleAssignments == true)
                    {
                        try
                        {
                            foreach (var rolmemb in role.RoleAssignments.results)
                            {


                                if (rolmemb.Member.Users != null)
                                {
                                    foreach (var User in rolmemb.Member.Users.results)
                                    {

                                        if (User.LoginName.Contains("|"))
                                        {
                                            useremail = User.LoginName.ToString().Split('|')[1].ToString();
                                        }
                                        else
                                        {
                                            useremail = User.LoginName.ToString();
                                        }

                                        if (!string.IsNullOrEmpty(useremail))
                                        {

                                            foreach (var roldef in rolmemb.RoleDefinitionBindings.results)
                                            {
                                                DataRow row = dtsrc.NewRow();
                                                string roldefperm = roldef.Name.ToString();
                                                row["SourceUrl"] = sourceUrl;
                                                row["SrcLibraryName"] = ListName;
                                                row["FileRef"] = role.File.ServerRelativeUrl.ToString();
                                                row["FileName"] = role.File.Name.ToString();
                                                row["User/Group"] = useremail.ToString().Trim();
                                                row["SrcPermissions"] = roldef.Name.ToString();
                                                dtsrc.Rows.Add(row);
                                                srcCount++;

                                            }
                                        }
                                    }

                                }
                                else
                                {
                                    if (rolmemb.Member.LoginName.Contains("|"))
                                    {
                                        useremail = rolmemb.Member.LoginName.Split('|')[1].ToString();
                                    }
                                    else
                                    {
                                        useremail = rolmemb.Member.LoginName;
                                    }
                                    foreach (var roldef in rolmemb.RoleDefinitionBindings.results)
                                    {
                                        DataRow row = dtsrc.NewRow();
                                        string roldefperm = roldef.Name.ToString();
                                        row["SourceUrl"] = sourceUrl;
                                        row["SrcLibraryName"] = ListName;
                                        row["FileRef"] = role.File.ServerRelativeUrl.ToString();
                                        row["FileName"] = role.File.Name.ToString();
                                        row["User/Group"] = useremail.ToString().Trim();
                                        row["SrcPermissions"] = roldef.Name.ToString();
                                        dtsrc.Rows.Add(row);
                                        srcCount++;

                                    }
                                }


                            }
                        }
                        catch (Exception ex)
                        {

                            Console.WriteLine("Error in Item Level :{0},StackeTrace:{1},File Url:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), role.File.ServerRelativeUrl.ToString());
                            _logger.ErrorFormat("Error in Item Level :{0},StackeTrace:{1},File Url:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), role.File.ServerRelativeUrl.ToString());
                        }

                    }


                }

                temp = string.Format(url, destUrl, ListName, PAGESIZE);
                jsonResponse = string.Empty;
                jsonResponse = GetRestResult(temp, GetSPOClientHandler(temp, util)).Result;
                JDocLibRole jDocdes = JsonConvert.DeserializeObject<JDocLibRole>(jsonResponse);
                jDocdes.d.results = jDocdes.d.results.Where(s => s.File.Name != null).ToArray();
                jDocdes.d.results = jDocdes.d.results.Where(s => s.RoleAssignments != null).ToArray();
                foreach (var role in jDocdes.d.results)
                {
                    string useremail = string.Empty;
                    string filereleative = role.File.ServerRelativeUrl.ToString();
                    if (role.HasUniqueRoleAssignments == true)
                    {
                        try
                        {
                            foreach (var rolmemb in role.RoleAssignments.results)
                            {

                                if (rolmemb.Member.Users != null)
                                {
                                    foreach (var User in rolmemb.Member.Users.results)
                                    {
                                        if (!string.IsNullOrEmpty(User.LoginName.ToString()))
                                        {
                                            if (User.LoginName.Contains("i:0#.f|membership|"))
                                            {
                                                useremail = User.LoginName.ToString();
                                            }
                                            else if (User.LoginName.Contains("c:0-.f|"))
                                            {
                                                useremail = User.LoginName.ToString();
                                            }
                                            else
                                            {
                                                useremail = "i:0#.f|membership|" + User.LoginName.ToString();
                                            }

                                        }


                                        if (!string.IsNullOrEmpty(useremail))
                                        {
                                            // useremail = rolmemb.Member.LoginName;
                                            foreach (var roldef in rolmemb.RoleDefinitionBindings.results)
                                            {
                                                DataRow row = dtdes.NewRow();
                                                string roldefperm = roldef.Name.ToString();
                                                row["TargetUrl"] = destUrl;
                                                row["DesLibraryName"] = ListName;
                                                row["FileRef"] = role.File.ServerRelativeUrl.ToString();
                                                row["FileName"] = role.File.Name.ToString();
                                                row["DesUsersGroups"] = useremail.ToString().Trim();
                                                row["DesPermissions"] = roldef.Name.ToString();
                                                dtdes.Rows.Add(row);
                                                DesCount++;
                                            }
                                        }

                                    }

                                }
                                else
                                {
                                    if (!string.IsNullOrEmpty(rolmemb.Member.LoginName.ToString()))
                                    {
                                        if (rolmemb.Member.LoginName.Contains("i:0#.f|membership|"))
                                        {
                                            useremail = rolmemb.Member.LoginName.ToString();
                                        }
                                        else if (rolmemb.Member.LoginName.Contains("c:0-.f|"))
                                        {
                                            useremail = rolmemb.Member.LoginName.ToString();
                                        }
                                        else
                                        {
                                            useremail = "i:0#.f|membership|" + rolmemb.Member.LoginName.ToString();
                                        }

                                    }

                                    foreach (var roldef in rolmemb.RoleDefinitionBindings.results)
                                    {
                                        DataRow row = dtdes.NewRow();
                                        string roldefperm = roldef.Name.ToString();
                                        row["TargetUrl"] = destUrl;
                                        row["DesLibraryName"] = ListName;
                                        row["FileRef"] = role.File.ServerRelativeUrl.ToString();
                                        row["FileName"] = role.File.Name.ToString();
                                        row["DesUsersGroups"] = useremail.ToString().Trim();
                                        row["DesPermissions"] = roldef.Name.ToString();
                                        dtdes.Rows.Add(row);
                                        DesCount++;
                                    }
                                }

                            }
                        }
                        catch (Exception ex)
                        {

                            Console.WriteLine("Error in Item Level :{0},StackeTrace:{1},File Url:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), role.File.ServerRelativeUrl.ToString());
                            _logger.ErrorFormat("Error in Item Level :{0},StackeTrace:{1},File Url:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), role.File.ServerRelativeUrl.ToString());
                        }

                    }

                }
            }
            catch (Exception ex)
            {

                Console.WriteLine("Error in Item Level :{0},StackeTrace:{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
                _logger.ErrorFormat("Error in Item Level :{0},StackeTrace:{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
            }
        }
        private void ItemLevelComparison(UtliClass util, string sourceUrl, string destUrl, nJLibrarys.Result result, nJLibrarys.Result socresult)
        {
            try
            {
                srcCount = 0;
                DesCount = 0;
                int PAGESIZE = 5000;
                string temp = string.Empty;
                string ItemCount = result.ItemCount;
                Console.WriteLine("\n");
                Console.WriteLine("Working on this List:-{0},Total Items Count:{1}", result.Title, result.ItemCount);
                _logger.InfoFormat("Working on this List:-{0},Total Items Count:{1}", result.Title, result.ItemCount);
                string url = string.Empty;
                if (Convert.ToInt32(ItemCount) > 5000)
                {
                    PAGESIZE = 1000;
                    url = "{0}/_api/web/lists/getbyid('{1}')/items?&$skiptoken=Paged=TRUE&$top={2}&$expand=File,RoleAssignments/Member,RoleAssignments/Member/Users,RoleAssignments/RoleDefinitionBindings&$select=RoleAssignments/Member/LoginName,RoleAssignments/RoleDefinitionBindings/Name,RoleAssignments/Member/Users,RoleAssignments/Member/Groups,HasUniqueRoleAssignments,File/ServerRelativeUrl,File/Name";
                }
                else
                {
                    url = "{0}/_api/web/lists/getbyid('{1}')/items?&$skiptoken=Paged=TRUE&$top={2}&$expand=File,RoleAssignments/Member,RoleAssignments/Member/Users,RoleAssignments/RoleDefinitionBindings&$select=RoleAssignments/Member/LoginName,RoleAssignments/RoleDefinitionBindings/Name,RoleAssignments/Member/Users,RoleAssignments/Member/Groups,HasUniqueRoleAssignments,File/ServerRelativeUrl,File/Name";
                }

                string jsonResponse = GetRestResult(string.Format(url, sourceUrl, socresult.Id, PAGESIZE), util.SourcehttpClientHandler).Result;
                JDocLibRole jDocS = JsonConvert.DeserializeObject<JDocLibRole>(jsonResponse);
                jDocS.d.results = jDocS.d.results.Where(s => s.File.Name != null).ToArray();
                jDocS.d.results = jDocS.d.results.Where(s => s.RoleAssignments != null).ToArray();

                foreach (var role in jDocS.d.results)
                {
                    string useremail = string.Empty;
                    if (role.HasUniqueRoleAssignments == true)
                    {
                        try
                        {
                            foreach (var rolmemb in role.RoleAssignments.results)
                            {


                                if (rolmemb.Member.Users != null)
                                {
                                    foreach (var User in rolmemb.Member.Users.results)
                                    {

                                        if (User.LoginName.Contains("|"))
                                        {
                                            useremail = User.LoginName.ToString().Split('|')[1].ToString();
                                        }
                                        else
                                        {
                                            useremail = User.LoginName.ToString();
                                        }

                                        if (!string.IsNullOrEmpty(useremail))
                                        {

                                            foreach (var roldef in rolmemb.RoleDefinitionBindings.results)
                                            {
                                                DataRow row = dtsrc.NewRow();
                                                string roldefperm = roldef.Name.ToString();
                                                row["SourceUrl"] = sourceUrl;
                                                row["SrcLibraryName"] = result.Title;
                                                row["FileRef"] = role.File.ServerRelativeUrl.ToString();
                                                row["FileName"] = role.File.Name.ToString();
                                                row["User/Group"] = useremail.ToString().Trim();
                                                row["SrcPermissions"] = roldef.Name.ToString();
                                                dtsrc.Rows.Add(row);
                                                srcCount++;

                                            }
                                        }
                                    }

                                }
                                else
                                {
                                    if (rolmemb.Member.LoginName.Contains("|"))
                                    {
                                        useremail = rolmemb.Member.LoginName.Split('|')[1].ToString();
                                    }
                                    else
                                    {
                                        useremail = rolmemb.Member.LoginName;
                                    }
                                    foreach (var roldef in rolmemb.RoleDefinitionBindings.results)
                                    {
                                        DataRow row = dtsrc.NewRow();
                                        string roldefperm = roldef.Name.ToString();
                                        row["SourceUrl"] = sourceUrl;
                                        row["SrcLibraryName"] = result.Title;
                                        row["FileRef"] = role.File.ServerRelativeUrl.ToString();
                                        row["FileName"] = role.File.Name.ToString();
                                        row["User/Group"] = useremail.ToString().Trim();
                                        row["SrcPermissions"] = roldef.Name.ToString();
                                        dtsrc.Rows.Add(row);
                                        srcCount++;

                                    }
                                }


                            }
                        }
                        catch (Exception ex)
                        {

                            Console.WriteLine("Error in Item Level :{0},StackeTrace:{1},File Url:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), role.File.ServerRelativeUrl.ToString());
                            _logger.ErrorFormat("Error in Item Level :{0},StackeTrace:{1},File Url:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), role.File.ServerRelativeUrl.ToString());
                        }

                    }


                }

                temp = string.Format(url, destUrl, result.Id, PAGESIZE);
                jsonResponse = string.Empty;

                jsonResponse = GetRestResult(temp, GetSPOClientHandler(temp, util)).Result;

                JDocLibRole jDocdes = JsonConvert.DeserializeObject<JDocLibRole>(jsonResponse);
                jDocdes.d.results = jDocdes.d.results.Where(s => s.File.Name != null).ToArray();
                jDocdes.d.results = jDocdes.d.results.Where(s => s.RoleAssignments != null).ToArray();
                foreach (var role in jDocdes.d.results)
                {
                    string useremail = string.Empty;
                    string filereleative = role.File.ServerRelativeUrl.ToString();
                    if (role.HasUniqueRoleAssignments == true)
                    {
                        try
                        {
                            foreach (var rolmemb in role.RoleAssignments.results)
                            {

                                if (rolmemb.Member.Users != null)
                                {
                                    foreach (var User in rolmemb.Member.Users.results)
                                    {
                                        if (!string.IsNullOrEmpty(User.LoginName.ToString()))
                                        {
                                            if (User.LoginName.Contains("i:0#.f|membership|"))
                                            {
                                                useremail = User.LoginName.ToString();
                                            }
                                            else if (User.LoginName.Contains("c:0-.f|"))
                                            {
                                                useremail = User.LoginName.ToString();
                                            }
                                            else
                                            {
                                                useremail = "i:0#.f|membership|" + User.LoginName.ToString();
                                            }

                                        }


                                        if (!string.IsNullOrEmpty(useremail))
                                        {
                                            // useremail = rolmemb.Member.LoginName;
                                            foreach (var roldef in rolmemb.RoleDefinitionBindings.results)
                                            {
                                                DataRow row = dtdes.NewRow();
                                                string roldefperm = roldef.Name.ToString();
                                                row["TargetUrl"] = destUrl;
                                                row["DesLibraryName"] = result.Title;
                                                row["FileRef"] = role.File.ServerRelativeUrl.ToString();
                                                row["FileName"] = role.File.Name.ToString();
                                                row["DesUsersGroups"] = useremail.ToString().Trim();
                                                row["DesPermissions"] = roldef.Name.ToString();
                                                dtdes.Rows.Add(row);
                                                DesCount++;
                                            }
                                        }

                                    }

                                }
                                else
                                {
                                    if (!string.IsNullOrEmpty(rolmemb.Member.LoginName.ToString()))
                                    {
                                        if (rolmemb.Member.LoginName.Contains("i:0#.f|membership|"))
                                        {
                                            useremail = rolmemb.Member.LoginName.ToString();
                                        }
                                        else if (rolmemb.Member.LoginName.Contains("c:0-.f|"))
                                        {
                                            useremail = rolmemb.Member.LoginName.ToString();
                                        }
                                        else
                                        {
                                            useremail = "i:0#.f|membership|" + rolmemb.Member.LoginName.ToString();
                                        }

                                    }

                                    foreach (var roldef in rolmemb.RoleDefinitionBindings.results)
                                    {
                                        DataRow row = dtdes.NewRow();
                                        string roldefperm = roldef.Name.ToString();
                                        row["TargetUrl"] = destUrl;
                                        row["DesLibraryName"] = result.Title;
                                        row["FileRef"] = role.File.ServerRelativeUrl.ToString();
                                        row["FileName"] = role.File.Name.ToString();
                                        row["DesUsersGroups"] = useremail.ToString().Trim();
                                        row["DesPermissions"] = roldef.Name.ToString();
                                        dtdes.Rows.Add(row);
                                        DesCount++;
                                    }
                                }

                            }
                        }
                        catch (Exception ex)
                        {

                            Console.WriteLine("Error in Item Level :{0},StackeTrace:{1},File Url:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), role.File.ServerRelativeUrl.ToString());
                            _logger.ErrorFormat("Error in Item Level :{0},StackeTrace:{1},File Url:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), role.File.ServerRelativeUrl.ToString());
                        }

                    }

                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error in Item Level :{0},StackeTrace:{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
                _logger.ErrorFormat("Error in Item Level :{0},StackeTrace:{1},Method Name:{2}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString());
            }
            if (srcCount == 0 & DesCount == 0)
            {

                Console.WriteLine("not found any item level permission for this List:-{0}", result.Title);
            }
            else
            {

                Console.WriteLine("HasUniqueRoleAssignments for Source List:{0},Items Count:{1}", result.Title, srcCount);
                Console.WriteLine("HasUniqueRoleAssignments for Target List:{0},Items Count:{1}", result.Title, DesCount);
                _logger.InfoFormat("HasUniqueRoleAssignments for Source List:{0},Items Count:{1}", result.Title, srcCount);
                _logger.InfoFormat("HasUniqueRoleAssignments for Target List:{0},Items Count:{1}", result.Title, DesCount);
            }


        }

        private async Task<string> GetRestResult(string webUrl, HttpClientHandler handler)
        {
            string jsonData = string.Empty;
            using (var client = new HttpClient(handler))
            {
                try
                {
                    client.Timeout = TimeSpan.FromSeconds(3000);
                    client.DefaultRequestHeaders.Clear();
                    client.DefaultRequestHeaders.Add("Accept", "application/json;odata=verbose");
                    client.DefaultRequestHeaders.Add("ContentType", "application/json");

                    HttpResponseMessage response = await client.GetAsync(webUrl).ConfigureAwait(false);

                    response.EnsureSuccessStatusCode();
                    jsonData = await response.Content.ReadAsStringAsync();
                }
                catch (Exception ex)
                {
                    Console.ResetColor();
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Error in Item Level :{0},StackeTrace:{1},Method Name:{2},Rest API URL:{3}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString(), webUrl);
                    _logger.ErrorFormat("Error in Item Level :{0},StackeTrace:{1},Method Name:{2},Rest API URL:{3}", ex.Message.ToString(), ex.StackTrace.ToString(), ex.TargetSite.ToString(), webUrl);

                    Console.ResetColor();
                    Console.BackgroundColor = ConsoleColor.Blue;
                    Console.ForegroundColor = ConsoleColor.White;
                }

                return jsonData;
            }



        }

        private HttpClientHandler GetSPOClientHandler(string spSiteUrl, UtliClass utli)
        {
            var credential = new SharePointOnlineCredentials(utli.SPOuserName, utli.SPOpassword);
            HttpClientHandler handler = new HttpClientHandler() { Credentials = credential };
            //Getting authentication cookies
            Uri uri = new Uri(spSiteUrl);
            handler.CookieContainer.SetCookies(uri, credential.GetAuthenticationCookie(uri));
            return handler;
        }
    }

    class UtliClass
    {
        public string UserName { get; set; }
        public string Password { get; set; }
        public string SPOuserName { get; set; }
        public SecureString SPOpassword { get; set; }
        public StringBuilder stringBuilder { get; set; }
        public HttpClientHandler SourcehttpClientHandler
        {
            get
            {
                var credential = new System.Net.NetworkCredential(UserName, Password);
                HttpClientHandler handler = new HttpClientHandler() { Credentials = credential };
                return handler;
            }
        }
    }
}
