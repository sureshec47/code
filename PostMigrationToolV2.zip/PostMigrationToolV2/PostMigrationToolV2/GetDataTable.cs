﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PostMigrationToolV2
{
   public class GetDataTable
    {
        public DataTable objDt = new DataTable();
        
        public DataTable getwebpartsrc()
        {
            objDt = new DataTable();
            
            objDt.Columns.Add("SourceUrl", typeof(string));
            objDt.Columns.Add("srcWebpartName", typeof(string));
            objDt.Columns.Add("WebpartUrl", typeof(string));
            objDt.Columns.Add("WebpartIsClosed", typeof(string));
            return objDt;
        }
        public DataTable getwebpartDes()
        {
            objDt = new DataTable();

            objDt.Columns.Add("TargeteUrl", typeof(string));
            objDt.Columns.Add("desWebpartName", typeof(string));
            objDt.Columns.Add("WebpartUrl", typeof(string));
            objDt.Columns.Add("WebpartIsClosed", typeof(string));
            return objDt;
        }
        public DataTable getDataTableWrksrc()
        {
            objDt = new DataTable();
            objDt.Columns.Add("SiteUrl", typeof(string));
            objDt.Columns.Add("ListName", typeof(string));
            objDt.Columns.Add("WorkflowName", typeof(string));
            objDt.Columns.Add("WrkflwID", typeof(string));
            return objDt;
        }
        public DataTable getDataTableWrkDes()
        {
            objDt = new DataTable();
            objDt.Columns.Add("SiteUrl", typeof(string));
            objDt.Columns.Add("ListName", typeof(string));
            objDt.Columns.Add("WorkflowName", typeof(string));
            objDt.Columns.Add("WrkflwID", typeof(string));
            return objDt;
        }

        public DataTable getDataTableListContentTypes()
        {
            objDt = new DataTable();
            objDt.Columns.Add("SiteUrl", typeof(string));
            objDt.Columns.Add("ListName", typeof(string));
            objDt.Columns.Add("ContentTypeName", typeof(string));
            objDt.Columns.Add("FieldName", typeof(string));

            return objDt;
        }
       
        public DataTable getDataTableListContentTypesDes()
        {
            objDt = new DataTable();
            objDt.Columns.Add("SiteUrl", typeof(string));
            objDt.Columns.Add("ListName", typeof(string));
            objDt.Columns.Add("ContentTypeName", typeof(string));
            objDt.Columns.Add("FieldName", typeof(string));

            return objDt;
        }

        public DataTable getDataTableListPersrc()
        {
            objDt = new DataTable();
            objDt.Columns.Add("SiteUrl", typeof(string));
            objDt.Columns.Add("ListName", typeof(string));
            objDt.Columns.Add("ListPermission", typeof(string));
            objDt.Columns.Add("Users/Group", typeof(string));

            return objDt;
        }

        public DataTable getDataTableListPerDes()
        {
            objDt = new DataTable();
            objDt.Columns.Add("SiteUrl", typeof(string));
            objDt.Columns.Add("ListName", typeof(string));
            objDt.Columns.Add("ListPermission", typeof(string));
            objDt.Columns.Add("Users/Group", typeof(string));

            return objDt;
        }

        public DataTable getDataTableListPerCompare()
        {
            objDt = new DataTable();
            objDt.Columns.Add("SiteUrl", typeof(string));
            objDt.Columns.Add("ListName", typeof(string));
            objDt.Columns.Add("ListPermission", typeof(string));
            objDt.Columns.Add("Users/Group", typeof(string));

            objDt.Columns.Add("DesSiteUrl", typeof(string));
            objDt.Columns.Add("DesListName", typeof(string));
            objDt.Columns.Add("DesListPermission", typeof(string));
            objDt.Columns.Add("DesUsers/Group", typeof(string));

            return objDt;
        }
    }
}
