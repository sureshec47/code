﻿namespace PostMigrationToolV2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnExit = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnExport = new System.Windows.Forms.Button();
            this.txtExport = new System.Windows.Forms.TextBox();
            this.lblExportPath = new System.Windows.Forms.Label();
            this.btnURLFile = new System.Windows.Forms.Button();
            this.txtURLFile = new System.Windows.Forms.TextBox();
            this.lblURLFile = new System.Windows.Forms.Label();
            this.btnMultipleSites = new System.Windows.Forms.RadioButton();
            this.txtDestinationURL = new System.Windows.Forms.TextBox();
            this.lblDestinationURL = new System.Windows.Forms.Label();
            this.txtSourceURL = new System.Windows.Forms.TextBox();
            this.lblSourceURL = new System.Windows.Forms.Label();
            this.btnsingleSite = new System.Windows.Forms.RadioButton();
            this.btnGenerate = new System.Windows.Forms.Button();
            this.chkContentType = new System.Windows.Forms.CheckBox();
            this.chkWebpart = new System.Windows.Forms.CheckBox();
            this.chkgrpper = new System.Windows.Forms.CheckBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.chkListPerm = new System.Windows.Forms.CheckBox();
            this.chkListFields = new System.Windows.Forms.CheckBox();
            this.chkItemLevelLists = new System.Windows.Forms.CheckBox();
            this.chkWrkflw = new System.Windows.Forms.CheckBox();
            this.chkfldlevel = new System.Windows.Forms.CheckBox();
            this.ChkAll = new System.Windows.Forms.CheckBox();
            this.chkDocument = new System.Windows.Forms.CheckBox();
            this.chkFeatureComparsion = new System.Windows.Forms.CheckBox();
            this.chkItemLevelPermission = new System.Windows.Forms.CheckBox();
            this.grpSinglesite = new System.Windows.Forms.GroupBox();
            this.chkRootWeb = new System.Windows.Forms.CheckBox();
            this.chckMultiple = new System.Windows.Forms.GroupBox();
            this.grpreport = new System.Windows.Forms.GroupBox();
            this.fbdExport = new System.Windows.Forms.FolderBrowserDialog();
            this.groupBox1.SuspendLayout();
            this.grpSinglesite.SuspendLayout();
            this.chckMultiple.SuspendLayout();
            this.grpreport.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnExit
            // 
            this.btnExit.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(515, 71);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(75, 23);
            this.btnExit.TabIndex = 29;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancel.Location = new System.Drawing.Point(276, 71);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(89, 23);
            this.btnCancel.TabIndex = 28;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnExport
            // 
            this.btnExport.Enabled = false;
            this.btnExport.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExport.Location = new System.Drawing.Point(670, 44);
            this.btnExport.Name = "btnExport";
            this.btnExport.Size = new System.Drawing.Size(71, 22);
            this.btnExport.TabIndex = 27;
            this.btnExport.Text = "Browse";
            this.btnExport.UseVisualStyleBackColor = true;
            this.btnExport.Visible = false;
            this.btnExport.Click += new System.EventHandler(this.btnExport_Click);
            // 
            // txtExport
            // 
            this.txtExport.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtExport.Location = new System.Drawing.Point(72, 17);
            this.txtExport.Name = "txtExport";
            this.txtExport.Size = new System.Drawing.Size(579, 23);
            this.txtExport.TabIndex = 26;
            this.txtExport.Text = "D:\\Reports";
            // 
            // lblExportPath
            // 
            this.lblExportPath.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblExportPath.Location = new System.Drawing.Point(6, 20);
            this.lblExportPath.Name = "lblExportPath";
            this.lblExportPath.Size = new System.Drawing.Size(69, 22);
            this.lblExportPath.TabIndex = 25;
            this.lblExportPath.Text = "Export";
            // 
            // btnURLFile
            // 
            this.btnURLFile.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnURLFile.Location = new System.Drawing.Point(657, 17);
            this.btnURLFile.Name = "btnURLFile";
            this.btnURLFile.Size = new System.Drawing.Size(71, 21);
            this.btnURLFile.TabIndex = 24;
            this.btnURLFile.Text = "Browse";
            this.btnURLFile.UseVisualStyleBackColor = true;
            this.btnURLFile.Click += new System.EventHandler(this.btnURLFile_Click);
            // 
            // txtURLFile
            // 
            this.txtURLFile.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtURLFile.Location = new System.Drawing.Point(130, 43);
            this.txtURLFile.Name = "txtURLFile";
            this.txtURLFile.Size = new System.Drawing.Size(534, 23);
            this.txtURLFile.TabIndex = 23;
            this.txtURLFile.TextChanged += new System.EventHandler(this.txtURLFile_TextChanged);
            // 
            // lblURLFile
            // 
            this.lblURLFile.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblURLFile.Location = new System.Drawing.Point(20, 46);
            this.lblURLFile.Name = "lblURLFile";
            this.lblURLFile.Size = new System.Drawing.Size(79, 20);
            this.lblURLFile.TabIndex = 22;
            this.lblURLFile.Text = "URL File";
            // 
            // btnMultipleSites
            // 
            this.btnMultipleSites.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMultipleSites.Location = new System.Drawing.Point(9, 19);
            this.btnMultipleSites.Name = "btnMultipleSites";
            this.btnMultipleSites.Size = new System.Drawing.Size(181, 24);
            this.btnMultipleSites.TabIndex = 21;
            this.btnMultipleSites.Text = "Compare Multiple Sites";
            this.btnMultipleSites.UseVisualStyleBackColor = true;
            this.btnMultipleSites.CheckedChanged += new System.EventHandler(this.btnMultipleSites_CheckedChanged);
            // 
            // txtDestinationURL
            // 
            this.txtDestinationURL.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDestinationURL.Location = new System.Drawing.Point(152, 92);
            this.txtDestinationURL.Name = "txtDestinationURL";
            this.txtDestinationURL.Size = new System.Drawing.Size(589, 23);
            this.txtDestinationURL.TabIndex = 20;
            this.txtDestinationURL.Text = "https://firstdata.sharepoint.com/sites/TestMigration";
            this.txtDestinationURL.TextChanged += new System.EventHandler(this.txtDestinationURL_TextChanged);
            // 
            // lblDestinationURL
            // 
            this.lblDestinationURL.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDestinationURL.Location = new System.Drawing.Point(13, 97);
            this.lblDestinationURL.Name = "lblDestinationURL";
            this.lblDestinationURL.Size = new System.Drawing.Size(117, 21);
            this.lblDestinationURL.TabIndex = 19;
            this.lblDestinationURL.Text = "Destination Site URL";
            // 
            // txtSourceURL
            // 
            this.txtSourceURL.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSourceURL.Location = new System.Drawing.Point(152, 55);
            this.txtSourceURL.Name = "txtSourceURL";
            this.txtSourceURL.Size = new System.Drawing.Size(589, 23);
            this.txtSourceURL.TabIndex = 18;
            this.txtSourceURL.Text = "http://solutionmaps.1dc.com/sites/SPOMigration";
            this.txtSourceURL.TextChanged += new System.EventHandler(this.txtSourceURL_TextChanged);
            // 
            // lblSourceURL
            // 
            this.lblSourceURL.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSourceURL.Location = new System.Drawing.Point(8, 59);
            this.lblSourceURL.Name = "lblSourceURL";
            this.lblSourceURL.Size = new System.Drawing.Size(122, 23);
            this.lblSourceURL.TabIndex = 17;
            this.lblSourceURL.Text = "Source Site URL";
            // 
            // btnsingleSite
            // 
            this.btnsingleSite.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsingleSite.Location = new System.Drawing.Point(11, 19);
            this.btnsingleSite.Name = "btnsingleSite";
            this.btnsingleSite.Size = new System.Drawing.Size(172, 24);
            this.btnsingleSite.TabIndex = 16;
            this.btnsingleSite.TabStop = true;
            this.btnsingleSite.Text = "Compare Single Site";
            this.btnsingleSite.UseVisualStyleBackColor = true;
            this.btnsingleSite.CheckedChanged += new System.EventHandler(this.btnsingleSite_CheckedChanged);
            // 
            // btnGenerate
            // 
            this.btnGenerate.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGenerate.Location = new System.Drawing.Point(72, 71);
            this.btnGenerate.Name = "btnGenerate";
            this.btnGenerate.Size = new System.Drawing.Size(75, 23);
            this.btnGenerate.TabIndex = 15;
            this.btnGenerate.Text = "Generate";
            this.btnGenerate.UseVisualStyleBackColor = true;
            this.btnGenerate.Click += new System.EventHandler(this.btnGenerate_Click);
            // 
            // chkContentType
            // 
            this.chkContentType.AutoSize = true;
            this.chkContentType.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkContentType.Location = new System.Drawing.Point(13, 45);
            this.chkContentType.Name = "chkContentType";
            this.chkContentType.Size = new System.Drawing.Size(177, 20);
            this.chkContentType.TabIndex = 30;
            this.chkContentType.Text = "ContentTypeComparsion";
            this.chkContentType.UseVisualStyleBackColor = true;
            // 
            // chkWebpart
            // 
            this.chkWebpart.AutoSize = true;
            this.chkWebpart.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkWebpart.Location = new System.Drawing.Point(14, 67);
            this.chkWebpart.Name = "chkWebpart";
            this.chkWebpart.Size = new System.Drawing.Size(156, 20);
            this.chkWebpart.TabIndex = 31;
            this.chkWebpart.Text = "WebPart Comparsion";
            this.chkWebpart.UseVisualStyleBackColor = true;
            // 
            // chkgrpper
            // 
            this.chkgrpper.AutoSize = true;
            this.chkgrpper.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkgrpper.Location = new System.Drawing.Point(206, 41);
            this.chkgrpper.Name = "chkgrpper";
            this.chkgrpper.Size = new System.Drawing.Size(268, 20);
            this.chkgrpper.TabIndex = 33;
            this.chkgrpper.Text = "Site permission and Groups  Permission ";
            this.chkgrpper.UseMnemonic = false;
            this.chkgrpper.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.groupBox1.Controls.Add(this.chkListPerm);
            this.groupBox1.Controls.Add(this.chkListFields);
            this.groupBox1.Controls.Add(this.chkItemLevelLists);
            this.groupBox1.Controls.Add(this.chkWrkflw);
            this.groupBox1.Controls.Add(this.chkfldlevel);
            this.groupBox1.Controls.Add(this.ChkAll);
            this.groupBox1.Controls.Add(this.chkDocument);
            this.groupBox1.Controls.Add(this.chkFeatureComparsion);
            this.groupBox1.Controls.Add(this.chkItemLevelPermission);
            this.groupBox1.Controls.Add(this.chkContentType);
            this.groupBox1.Controls.Add(this.chkgrpper);
            this.groupBox1.Controls.Add(this.chkWebpart);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(33, 256);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1074, 175);
            this.groupBox1.TabIndex = 34;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Select AnyOne Check box";
            // 
            // chkListPerm
            // 
            this.chkListPerm.AutoSize = true;
            this.chkListPerm.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkListPerm.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.chkListPerm.Location = new System.Drawing.Point(643, 95);
            this.chkListPerm.Name = "chkListPerm";
            this.chkListPerm.Size = new System.Drawing.Size(280, 20);
            this.chkListPerm.TabIndex = 44;
            this.chkListPerm.Text = "List/ Library Level Permission  Comparsion";
            this.chkListPerm.UseVisualStyleBackColor = true;
            // 
            // chkListFields
            // 
            this.chkListFields.AutoSize = true;
            this.chkListFields.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkListFields.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.chkListFields.Location = new System.Drawing.Point(363, 95);
            this.chkListFields.Name = "chkListFields";
            this.chkListFields.Size = new System.Drawing.Size(274, 20);
            this.chkListFields.TabIndex = 43;
            this.chkListFields.Text = "List fields and the associated content type";
            this.chkListFields.UseVisualStyleBackColor = true;
            // 
            // chkItemLevelLists
            // 
            this.chkItemLevelLists.AutoSize = true;
            this.chkItemLevelLists.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkItemLevelLists.Location = new System.Drawing.Point(14, 92);
            this.chkItemLevelLists.Name = "chkItemLevelLists";
            this.chkItemLevelLists.Size = new System.Drawing.Size(343, 20);
            this.chkItemLevelLists.TabIndex = 42;
            this.chkItemLevelLists.Text = "Get_Item_Level_Permissions_Specify_Lists/Libraries";
            this.chkItemLevelLists.UseVisualStyleBackColor = true;
            // 
            // chkWrkflw
            // 
            this.chkWrkflw.AutoSize = true;
            this.chkWrkflw.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkWrkflw.Location = new System.Drawing.Point(733, 41);
            this.chkWrkflw.Name = "chkWrkflw";
            this.chkWrkflw.Size = new System.Drawing.Size(124, 20);
            this.chkWrkflw.TabIndex = 40;
            this.chkWrkflw.Text = "WorkflowDetails";
            this.chkWrkflw.UseMnemonic = false;
            this.chkWrkflw.UseVisualStyleBackColor = true;
            // 
            // chkfldlevel
            // 
            this.chkfldlevel.AutoSize = true;
            this.chkfldlevel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkfldlevel.Location = new System.Drawing.Point(723, 67);
            this.chkfldlevel.Name = "chkfldlevel";
            this.chkfldlevel.Size = new System.Drawing.Size(166, 20);
            this.chkfldlevel.TabIndex = 39;
            this.chkfldlevel.Text = "FolderLevelPermission";
            this.chkfldlevel.UseMnemonic = false;
            this.chkfldlevel.UseVisualStyleBackColor = true;
            // 
            // ChkAll
            // 
            this.ChkAll.AutoSize = true;
            this.ChkAll.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ChkAll.Location = new System.Drawing.Point(15, 19);
            this.ChkAll.Name = "ChkAll";
            this.ChkAll.Size = new System.Drawing.Size(86, 20);
            this.ChkAll.TabIndex = 37;
            this.ChkAll.Text = "Select All ";
            this.ChkAll.UseVisualStyleBackColor = true;
            this.ChkAll.CheckedChanged += new System.EventHandler(this.ChkAll_CheckedChanged);
            // 
            // chkDocument
            // 
            this.chkDocument.AutoSize = true;
            this.chkDocument.Enabled = false;
            this.chkDocument.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkDocument.Location = new System.Drawing.Point(504, 67);
            this.chkDocument.Name = "chkDocument";
            this.chkDocument.Size = new System.Drawing.Size(213, 20);
            this.chkDocument.TabIndex = 36;
            this.chkDocument.Text = "Document Version Comparsion";
            this.chkDocument.UseMnemonic = false;
            this.chkDocument.UseVisualStyleBackColor = true;
            // 
            // chkFeatureComparsion
            // 
            this.chkFeatureComparsion.AutoSize = true;
            this.chkFeatureComparsion.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkFeatureComparsion.Location = new System.Drawing.Point(504, 41);
            this.chkFeatureComparsion.Name = "chkFeatureComparsion";
            this.chkFeatureComparsion.Size = new System.Drawing.Size(149, 20);
            this.chkFeatureComparsion.TabIndex = 35;
            this.chkFeatureComparsion.Text = "Feature Comparsion";
            this.chkFeatureComparsion.UseMnemonic = false;
            this.chkFeatureComparsion.UseVisualStyleBackColor = true;
            // 
            // chkItemLevelPermission
            // 
            this.chkItemLevelPermission.AutoSize = true;
            this.chkItemLevelPermission.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkItemLevelPermission.Location = new System.Drawing.Point(206, 67);
            this.chkItemLevelPermission.Name = "chkItemLevelPermission";
            this.chkItemLevelPermission.Size = new System.Drawing.Size(277, 20);
            this.chkItemLevelPermission.TabIndex = 34;
            this.chkItemLevelPermission.Text = "Get_Item_Level_Permissions_For_All_List";
            this.chkItemLevelPermission.UseMnemonic = false;
            this.chkItemLevelPermission.UseVisualStyleBackColor = true;
            // 
            // grpSinglesite
            // 
            this.grpSinglesite.BackColor = System.Drawing.Color.LightGray;
            this.grpSinglesite.Controls.Add(this.chkRootWeb);
            this.grpSinglesite.Controls.Add(this.btnsingleSite);
            this.grpSinglesite.Controls.Add(this.lblSourceURL);
            this.grpSinglesite.Controls.Add(this.txtSourceURL);
            this.grpSinglesite.Controls.Add(this.lblDestinationURL);
            this.grpSinglesite.Controls.Add(this.txtDestinationURL);
            this.grpSinglesite.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpSinglesite.Location = new System.Drawing.Point(33, 12);
            this.grpSinglesite.Name = "grpSinglesite";
            this.grpSinglesite.Size = new System.Drawing.Size(1074, 134);
            this.grpSinglesite.TabIndex = 35;
            this.grpSinglesite.TabStop = false;
            this.grpSinglesite.Text = "Single-Site-Comparsion";
            // 
            // chkRootWeb
            // 
            this.chkRootWeb.AutoSize = true;
            this.chkRootWeb.Location = new System.Drawing.Point(161, 24);
            this.chkRootWeb.Name = "chkRootWeb";
            this.chkRootWeb.Size = new System.Drawing.Size(104, 17);
            this.chkRootWeb.TabIndex = 21;
            this.chkRootWeb.Text = "RootWebOnly";
            this.chkRootWeb.UseVisualStyleBackColor = true;
            // 
            // chckMultiple
            // 
            this.chckMultiple.BackColor = System.Drawing.Color.LightGray;
            this.chckMultiple.Controls.Add(this.btnMultipleSites);
            this.chckMultiple.Controls.Add(this.lblURLFile);
            this.chckMultiple.Controls.Add(this.txtURLFile);
            this.chckMultiple.Controls.Add(this.btnExport);
            this.chckMultiple.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chckMultiple.Location = new System.Drawing.Point(33, 152);
            this.chckMultiple.Name = "chckMultiple";
            this.chckMultiple.Size = new System.Drawing.Size(1074, 98);
            this.chckMultiple.TabIndex = 21;
            this.chckMultiple.TabStop = false;
            this.chckMultiple.Text = "Compare Multiple Sites";
            // 
            // grpreport
            // 
            this.grpreport.Controls.Add(this.lblExportPath);
            this.grpreport.Controls.Add(this.txtExport);
            this.grpreport.Controls.Add(this.btnURLFile);
            this.grpreport.Controls.Add(this.btnGenerate);
            this.grpreport.Controls.Add(this.btnExit);
            this.grpreport.Controls.Add(this.btnCancel);
            this.grpreport.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpreport.Location = new System.Drawing.Point(33, 452);
            this.grpreport.Name = "grpreport";
            this.grpreport.Size = new System.Drawing.Size(1074, 100);
            this.grpreport.TabIndex = 36;
            this.grpreport.TabStop = false;
            this.grpreport.Text = "Report Generation";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightGray;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ClientSize = new System.Drawing.Size(1113, 564);
            this.Controls.Add(this.grpreport);
            this.Controls.Add(this.chckMultiple);
            this.Controls.Add(this.grpSinglesite);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.grpSinglesite.ResumeLayout(false);
            this.grpSinglesite.PerformLayout();
            this.chckMultiple.ResumeLayout(false);
            this.chckMultiple.PerformLayout();
            this.grpreport.ResumeLayout(false);
            this.grpreport.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnExport;
        private System.Windows.Forms.TextBox txtExport;
        private System.Windows.Forms.Label lblExportPath;
        private System.Windows.Forms.Button btnURLFile;
        private System.Windows.Forms.TextBox txtURLFile;
        private System.Windows.Forms.Label lblURLFile;
        private System.Windows.Forms.RadioButton btnMultipleSites;
        private System.Windows.Forms.TextBox txtDestinationURL;
        private System.Windows.Forms.Label lblDestinationURL;
        private System.Windows.Forms.TextBox txtSourceURL;
        private System.Windows.Forms.Label lblSourceURL;
        private System.Windows.Forms.RadioButton btnsingleSite;
        private System.Windows.Forms.Button btnGenerate;
        private System.Windows.Forms.CheckBox chkContentType;
        private System.Windows.Forms.CheckBox chkWebpart;
        private System.Windows.Forms.CheckBox chkgrpper;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.CheckBox chkItemLevelPermission;
        private System.Windows.Forms.CheckBox chkDocument;
        private System.Windows.Forms.CheckBox chkFeatureComparsion;
        private System.Windows.Forms.GroupBox grpSinglesite;
        private System.Windows.Forms.GroupBox chckMultiple;
        private System.Windows.Forms.GroupBox grpreport;
        private System.Windows.Forms.CheckBox ChkAll;
        private System.Windows.Forms.CheckBox chkfldlevel;
        private System.Windows.Forms.CheckBox chkWrkflw;
        private System.Windows.Forms.FolderBrowserDialog fbdExport;
        private System.Windows.Forms.CheckBox chkItemLevelLists;
        private System.Windows.Forms.CheckBox chkListFields;
        private System.Windows.Forms.CheckBox chkListPerm;
        private System.Windows.Forms.CheckBox chkRootWeb;
    }
}

